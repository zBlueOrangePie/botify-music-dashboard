/* Botify v5 — Frontend JS */
// ── Page loader ──────────────────────────────────────────────────────────────
window.addEventListener('load', function () {
  var loader = document.getElementById('page-loader');
  if (loader) {
    setTimeout(function () {
      loader.classList.add('fade');
      setTimeout(function () { loader.remove(); }, 400);
    }, 250);
  }
});
// ── Toast ────────────────────────────────────────────────────────────────────
function toast(msg, type) {
  type = type || 'info';
  var wrap = document.querySelector('.toast-wrap') || (function () {
    var el = document.createElement('div'); el.className = 'toast-wrap';
    document.body.appendChild(el); return el;
  })();
  var icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  var t = document.createElement('div');
  t.className = 'toast toast-' + type;
  t.innerHTML = '<span>' + (icons[type] || 'ℹ️') + '</span><span>' + msg + '</span>';
  wrap.appendChild(t);
  setTimeout(function () {
    t.classList.add('out');
    setTimeout(function () { t.remove(); }, 250);
  }, 3500);
}
// ── API fetch ────────────────────────────────────────────────────────────────
async function apiFetch(url, opts) {
  opts = opts || {};
  if (!opts.headers) opts.headers = {};
  opts.headers['Content-Type'] = 'application/json';
  var res  = await fetch(url, opts);
  var data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
// ── Sidebar panels ───────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {
  // Sidebar navigation
  document.querySelectorAll('.sidebar-item[data-panel]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = btn.dataset.panel;
      document.querySelectorAll('.sidebar-item').forEach(function (b) { b.classList.remove('active'); });
      document.querySelectorAll('.dash-panel').forEach(function (p) { p.classList.remove('active'); });
      btn.classList.add('active');
      var panel = document.getElementById('panel-' + target);
      if (panel) panel.classList.add('active');
    });
  });
  // Tab navigation
  document.querySelectorAll('.tab-btn[data-tab]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = btn.dataset.tab;
      var group  = btn.closest('[data-tab-group]') || document;
      group.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
      group.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('active'); });
      btn.classList.add('active');
      var panel = group.querySelector('[data-panel="' + target + '"]');
      if (panel) panel.classList.add('active');
    });
  });
});
window.toast     = toast;
window.apiFetch  = apiFetch;
