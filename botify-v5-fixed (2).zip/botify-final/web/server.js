require('dotenv').config();
const express      = require('express');
const session      = require('express-session');
const MongoStore   = require('connect-mongo');
const passport     = require('passport');
const OAuth2       = require('passport-oauth2');
const axios        = require('axios');
const helmet       = require('helmet');
const cors         = require('cors');
const compression  = require('compression');
const rateLimit    = require('express-rate-limit');
const path         = require('path');
const bodyParser   = require('body-parser');
const cookieParser = require('cookie-parser');
const app  = express();
const PORT = process.env.PORT || 3000;
// ─── OAuth2 Strategy (FIXED: correct 4-arg signature, no 'params') ───────────
passport.use('discord', new OAuth2({
  authorizationURL: 'https://discord.com/api/oauth2/authorize',
  tokenURL:         'https://discord.com/api/oauth2/token',
  clientID:         process.env.CLIENT_ID,
  clientSecret:     process.env.CLIENT_SECRET,
  callbackURL:      process.env.CALLBACK_URL,
  scope:            ['identify', 'guilds', 'email'],
  scopeSeparator:   ' ',
  // passport-oauth2 calls verify with (accessToken, refreshToken, profile, done)
  // profile is empty {} because Discord doesn't use a profile URL — we fetch it ourselves
}, async (accessToken, refreshToken, _profile, done) => {
  try {
    const headers = { Authorization: `Bearer ${accessToken}` };
    const [userRes, guildsRes] = await Promise.all([
      axios.get('https://discord.com/api/v10/users/@me',        { headers }),
      axios.get('https://discord.com/api/v10/users/@me/guilds', { headers })
    ]);
    return done(null, {
      id:            userRes.data.id,
      username:      userRes.data.username,
      discriminator: userRes.data.discriminator,
      avatar:        userRes.data.avatar,
      email:         userRes.data.email,
      verified:      userRes.data.verified,
      locale:        userRes.data.locale,
      mfa_enabled:   userRes.data.mfa_enabled,
      premium_type:  userRes.data.premium_type || 0,
      public_flags:  userRes.data.public_flags || 0,
      guilds:        guildsRes.data || [],
      accessToken,
      refreshToken,
    });
  } catch (err) {
    console.error('[OAuth2] failed:', err.response?.data || err.message);
    return done(err);
  }
}));
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj,  done) => done(null, obj));
// ─── Sessions (persistent, 14-day cookies) ───────────────────────────────────
const sessionOptions = {
  secret:            process.env.SESSION_SECRET || 'botify-change-me-in-env',
  resave:            false,
  saveUninitialized: false,
  rolling:           true,
  cookie: {
    maxAge:   14 * 24 * 60 * 60 * 1000,
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
  }
};
if (process.env.MONGODB_URI) {
  sessionOptions.store = MongoStore.create({
    mongoUrl:       process.env.MONGODB_URI,
    touchAfter:     24 * 3600,
    dbName:         'botify',
    collectionName: 'sessions',
  });
}
// ─── Middleware (order matters) ───────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(cors({ origin: process.env.DOMAIN || `http://localhost:${PORT}`, credentials: true }));
app.use(compression());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 500, standardHeaders: true, legacyHeaders: false }));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session(sessionOptions));
app.use(passport.initialize());
app.use(passport.session());
// ─── View Engine ──────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// ─── Locals for every view ────────────────────────────────────────────────────
app.use((req, res, next) => {
  res.locals.user      = req.user  || null;
  res.locals.botName   = process.env.BOT_NAME || 'Botify';
  res.locals.clientId  = process.env.CLIENT_ID || '';
  res.locals.domain    = process.env.DOMAIN || `http://localhost:${PORT}`;
  res.locals.req       = req; // needed for dev panel session info
  next();
});
// ─── Guards ───────────────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  req.session.returnTo = req.originalUrl;
  res.redirect('/login');
}
function requireDev(req, res, next) {
  if (req.session && req.session.devLoggedIn) return next();
  res.redirect('/dev/login');
}
// ─── Public routes ────────────────────────────────────────────────────────────
app.get('/',        (req, res) => res.render('index'));
app.get('/commands',(req, res) => res.render('commands', { commands: getCommandList() }));
app.get('/status',  (req, res) => res.render('status',  { bot: getBotStatus() }));
app.get('/docs',    (req, res) => res.render('docs'));
app.get('/tos',     (req, res) => res.render('tos'));
app.get('/privacy', (req, res) => res.render('privacy'));
// ─── OAuth2 (FIXED) ───────────────────────────────────────────────────────────
app.get('/login', (req, res) => {
  if (req.isAuthenticated()) return res.redirect('/dashboard');
  res.render('login');
});
// CRITICAL: do NOT pass scope here — it's already in the strategy options.
// Passing scope as a separate option causes passport-oauth2 to re-encode it
// incorrectly, resulting in Discord rejecting the request and redirecting back.
app.get('/auth/discord', passport.authenticate('discord'));
app.get('/auth/callback',
  passport.authenticate('discord', { failureRedirect: '/login?error=auth' }),
  (req, res) => {
    const dest = req.session.returnTo || '/dashboard';
    delete req.session.returnTo;
    res.redirect(dest);
  }
);
app.get('/logout', (req, res) => {
  req.logout(err => {
    if (err) console.error(err);
    req.session.destroy(() => res.redirect('/'));
  });
});
// ─── Dashboard ────────────────────────────────────────────────────────────────
app.get('/dashboard', requireAuth, (req, res) => {
  const bot = global.botClient;
  const botGuildIds = bot ? bot.guilds.cache.map(g => g.id) : [];
  res.render('dashboard/home', { botGuildIds });
});
app.get('/dashboard/:guildId', requireAuth, async (req, res) => {
  try {
    const GuildSettings = require('../bot/models/GuildSettings');
    const bot     = global.botClient;
    const guildId = req.params.guildId;
    // Verify user has access
    const userGuild = (req.user.guilds || []).find(g => g.id === guildId);
    if (!userGuild) return res.redirect('/dashboard?error=access');
    let guildInfo = { id: guildId, name: userGuild.name, icon: userGuild.icon };
    let channels  = [], roles = [];
    if (bot) {
      const g = bot.guilds.cache.get(guildId);
      if (g) {
        guildInfo = { id: g.id, name: g.name, icon: g.icon };
        channels  = g.channels.cache
          .filter(c => [0, 2, 5].includes(c.type))
          .map(c => ({ id: c.id, name: c.name, type: c.type }))
          .sort((a, b) => a.name.localeCompare(b.name));
        roles = g.roles.cache
          .filter(r => r.id !== guildId)
          .map(r => ({ id: r.id, name: r.name, color: r.hexColor || '#99aab5' }))
          .sort((a, b) => b.rawPosition - a.rawPosition);
      }
    }
    const settings = await GuildSettings.findOne({ guildId }).lean() || {};
    res.render('dashboard/guild', { guild: guildInfo, channels, roles, settings });
  } catch (e) {
    console.error('[Dashboard Guild]', e);
    res.status(500).render('error', { message: e.message });
  }
});
// ─── Leaderboard / Rankings routes ──────────────────────────────────────────

// Top Servers
app.get('/leaderboard', async (req, res) => {
  try {
    const bot = global.botClient;
    const GuildSettings = require('../bot/models/GuildSettings');
    const allSettings = await GuildSettings.find({}).lean().catch(() => []);
    const settingsMap = {};
    for (const s of allSettings) settingsMap[s.guildId] = s;
    const servers = bot ? [...bot.guilds.cache.values()].map(g => {
      const cfg = settingsMap[g.id] || {};
      return {
        id:          g.id,
        name:        g.name,
        icon:        g.iconURL({ size: 64 }),
        memberCount: g.memberCount,
        addedAt:     g.joinedAt,
      };
    }).sort((a, b) => b.memberCount - a.memberCount).slice(0, 50) : [];
    res.render('leaderboard/servers', { servers, tab: 'servers' });
  } catch(e) {
    console.error('[Rankings servers]', e);
    res.render('leaderboard/servers', { servers: [], tab: 'servers' });
  }
});

app.get('/leaderboard/servers', (req, res) => res.redirect('/leaderboard'));

// Top Users (Economy — based on XP + messages)
app.get('/leaderboard/economy', async (req, res) => {
  try {
    const Leveling = require('../bot/models/Leveling');
    const bot = global.botClient;
    const top = await Leveling.find({}).sort({ totalXp: -1 }).limit(50).lean().catch(() => []);
    const entries = top.map(d => {
      const guild  = bot?.guilds.cache.get(d.guildId);
      const member = guild?.members.cache.get(d.userId);
      return {
        userId:    d.userId,
        guildName: guild?.name || 'Unknown Server',
        username:  member?.user?.username || `User#${d.userId.slice(-4)}`,
        avatar:    member?.user?.displayAvatarURL({ size: 64 }) || null,
        level:     d.level,
        totalXp:   d.totalXp,
        messages:  d.messages || 0,
        coins:     Math.floor((d.messages || 0) * 2.5 + (d.totalXp || 0) * 0.1),
      };
    });
    res.render('leaderboard/economy', { entries, tab: 'economy' });
  } catch(e) {
    console.error('[Rankings economy]', e);
    res.render('leaderboard/economy', { entries: [], tab: 'economy' });
  }
});

// Tic-Tac-Toe Records (fastest wins)
app.get('/leaderboard/tictactoe', async (req, res) => {
  try {
    const TicTacToe = require('../bot/models/TicTacToe');
    const topWins    = await TicTacToe.find({ wins: { $gt: 0 } }).sort({ wins: -1 }).limit(50).lean().catch(() => []);
    const topFastest = await TicTacToe.find({ fastestWin: { $ne: null } }).sort({ fastestWin: 1 }).limit(20).lean().catch(() => []);
    res.render('leaderboard/tictactoe', { topWins, topFastest, tab: 'tictactoe' });
  } catch(e) {
    console.error('[Rankings tictactoe]', e);
    res.render('leaderboard/tictactoe', { topWins: [], topFastest: [], tab: 'tictactoe' });
  }
});

app.get('/profile', requireAuth, async (req, res) => {
  try {
    const Leveling = require('../bot/models/Leveling');
    const bot      = global.botClient;
    const mutualGuilds = [];
    if (bot) {
      for (const g of bot.guilds.cache.values()) {
        try {
          const m = await g.members.fetch(req.user.id).catch(() => null);
          if (m) {
            mutualGuilds.push({
              id:    g.id,
              name:  g.name,
              icon:  g.icon,
              roles: m.roles.cache
                .filter(r => r.id !== g.id)
                .sort((a, b) => b.rawPosition - a.rawPosition)
                .map(r => ({ name: r.name, color: r.hexColor || '#99aab5' }))
            });
          }
        } catch {}
      }
    }
    const levels = await Leveling.find({ userId: req.user.id }).lean().catch(() => []);
    res.render('profile', { mutualGuilds, levels });
  } catch (e) {
    console.error('[Profile]', e);
    res.status(500).render('error', { message: e.message });
  }
});
// ─── Developer Panel ──────────────────────────────────────────────────────────
app.get('/dev/login', (req, res) => {
  if (req.session && req.session.devLoggedIn) return res.redirect('/dev');
  const errorMsg = req.query.error === '1' ? 'Invalid credentials. Please try again.' : null;
  res.render('dev/login', { error: errorMsg });
});
app.post('/dev/login', (req, res) => {
  const { userid, password } = req.body;
  // Build list of allowed dev users from env
  // Format in .env:  DEV_USERS=id1:password1,id2:password2
  const users = [];
  if (process.env.DEV_USERS) {
    for (const entry of process.env.DEV_USERS.split(',')) {
      const colonIdx = entry.trim().indexOf(':');
      if (colonIdx > 0) {
        users.push({
          id:       entry.trim().slice(0, colonIdx).trim(),
          password: entry.trim().slice(colonIdx + 1).trim()
        });
      }
    }
  }
  // Legacy single-user fallback
  if (process.env.DEV_USER_ID && process.env.DEV_PASSWORD) {
    users.push({ id: process.env.DEV_USER_ID, password: process.env.DEV_PASSWORD });
  }
  if (!users.length) {
    return res.render('dev/login', {
      error: 'No developer credentials configured. Add DEV_USERS=yourId:yourPassword to .env'
    });
  }
  if (users.find(u => u.id === userid && u.password === password)) {
    req.session.devLoggedIn = true;
    req.session.devLoginAt  = new Date().toISOString();
    req.session.devUserId   = userid;
    return res.redirect('/dev');
  }
  return res.redirect('/dev/login?error=1');
});
app.post('/dev/logout', (req, res) => {
  req.session.devLoggedIn = false;
  req.session.devUserId   = null;
  res.redirect('/dev/login');
});
app.get('/dev', requireDev, (req, res) => {
  res.render('dev/dashboard', { stats: getDevStats(), devUserId: req.session.devUserId });
});
// ─── Dev API (no auth required for these — only accessible from panel) ────────
app.get('/dev/api/live', requireDev, (req, res) => {
  const c = global.botClient;
  const m = process.memoryUsage();
  res.json({
    ping:     c ? c.ws.ping : -1,
    guilds:   c ? c.guilds.cache.size : 0,
    uptime:   c ? c.uptime : 0,
    mem:      Math.round(m.heapUsed / 1024 / 1024),
    heapPct:  Math.round((m.heapUsed / m.heapTotal) * 100),
    status:   c ? 'online' : 'offline',
  });
});
// ─── API ─────────────────────────────────────────────────────────────────────
app.use('/api', require('./routes/api'));
// ─── 404 / Error ─────────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).render('404'));
app.use((err, req, res, _next) => {
  console.error('[Express Error]', err);
  res.status(500).render('error', { message: err.message || 'Internal server error' });
});
// ─── Helpers ──────────────────────────────────────────────────────────────────
function getBotStatus() {
  const c = global.botClient;
  if (!c || !c.isReady()) return { online: false };
  return {
    online:   true,
    ping:     c.ws.ping,
    guilds:   c.guilds.cache.size,
    uptime:   c.uptime,
    username: c.user?.username,
    tag:      c.user?.tag,
  };
}
function getDevStats() {
  const c = global.botClient;
  const commandList = [];
  if (c) {
    c.commands.forEach(cmd => {
      commandList.push({
        name:        cmd.data.name,
        category:    cmd.category || 'misc',
        description: cmd.data.description || '',
      });
    });
  }
  const mem = process.memoryUsage();
  return {
    online:       c ? c.isReady() : false,
    ping:         c ? c.ws.ping : -1,
    guilds:       c ? c.guilds.cache.size : 0,
    users:        c ? c.guilds.cache.reduce((a, g) => a + g.memberCount, 0) : 0,
    uptime:       c ? c.uptime : 0,
    commandCount: commandList.length,
    commandList,
    nodeVersion:  process.version,
    platform:     process.platform,
    arch:         process.arch,
    pid:          process.pid,
    memUsage:     mem,
    memMB:        Math.round(mem.heapUsed / 1024 / 1024),
    heapPct:      Math.round((mem.heapUsed / mem.heapTotal) * 100),
  };
}
function getCommandList() {
  const c = global.botClient;
  const out = {};
  if (!c) return out;
  c.commands.forEach(cmd => {
    const cat = cmd.category || 'misc';
    if (!out[cat]) out[cat] = [];
    out[cat].push({ name: cmd.data.name, description: cmd.data.description || '' });
  });
  return out;
}
// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ Web Dashboard: ${process.env.DOMAIN || `http://localhost:${PORT}`}`);
  console.log(`🔒 Sessions: ${process.env.MONGODB_URI ? 'MongoDB (persistent)' : 'Memory (dev only)'}`);
  console.log(`🔑 Dev users configured: ${process.env.DEV_USERS ? process.env.DEV_USERS.split(',').length : 0}`);
});
module.exports = app;
