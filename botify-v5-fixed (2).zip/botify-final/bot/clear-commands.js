#!/usr/bin/env node
/**
 * clear-commands.js
 * Wipes ALL registered slash commands (global + optionally a guild).
 * Use this to remove old commands from a previous bot before re-deploying.
 *
 * Usage:
 *   node bot/clear-commands.js            → clears global commands
 *   node bot/clear-commands.js --guild    → clears guild commands too
 */
require('dotenv').config();
const { REST, Routes } = require('@discordjs/rest');
const token    = process.env.BOT_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId  = process.env.GUILD_ID;
const clearGuild = process.argv.includes('--guild');
if (!token || !clientId) {
  console.error('❌  BOT_TOKEN and CLIENT_ID must be set in .env');
  process.exit(1);
}
const rest = new REST({ version: '10' }).setToken(token);
(async () => {
  try {
    console.log('\n🧹 Clearing slash commands…\n');
    // Always clear globals
    await rest.put(Routes.applicationCommands(clientId), { body: [] });
    console.log('✅ Global slash commands cleared');
    // Clear guild commands if flag is set
    if (clearGuild && guildId) {
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: [] });
      console.log(`✅ Guild (${guildId}) slash commands cleared`);
    } else if (clearGuild && !guildId) {
      console.warn('⚠️  --guild flag used but GUILD_ID not set in .env — skipping guild clear');
    }
    console.log('\n✅ Done! Commands will disappear from Discord within 1 hour (global) or instantly (guild).');
    console.log('   Run "npm run deploy" to register fresh commands.\n');
  } catch (err) {
    console.error('❌ Clear failed:', err);
    process.exit(1);
  }
})();
