const { Player } = require('discord-player');
const { YoutubeiExtractor } = require('@discord-player/extractor');
function initializeMusicPlayer(client) {
  console.log('🎵 Initializing Discord Player...');
  
  // Create player instance
  const player = new Player(client, {
    ytdlOptions: {
      quality: 'highestaudio',
      highWaterMark: 1 << 25
    }
  });
  // Register extractors
  player.extractors.register(YoutubeiExtractor, {});
  
  // Load default extractors
  player.extractors.loadDefault((ext) => !['YouTubeExtractor'].includes(ext));
  // Event listeners
  player.events.on('playerStart', (queue, track) => {
    const channel = queue.metadata.channel;
    channel.send(`🎵 Now playing: **${track.title}** by **${track.author}**`);
  });
  player.events.on('audioTrackAdd', (queue, track) => {
    const channel = queue.metadata.channel;
    channel.send(`✅ Added to queue: **${track.title}**`);
  });
  player.events.on('audioTracksAdd', (queue, tracks) => {
    const channel = queue.metadata.channel;
    channel.send(`✅ Added **${tracks.length}** tracks to queue`);
  });
  player.events.on('playerSkip', (queue, track) => {
    const channel = queue.metadata.channel;
    channel.send(`⏭️ Skipped: **${track.title}**`);
  });
  player.events.on('disconnect', (queue) => {
    const channel = queue.metadata.channel;
    channel.send('👋 Disconnected from voice channel');
  });
  player.events.on('emptyChannel', (queue) => {
    const channel = queue.metadata.channel;
    channel.send('⏹️ Nobody is in the voice channel, leaving...');
  });
  player.events.on('emptyQueue', (queue) => {
    const channel = queue.metadata.channel;
    channel.send('✅ Queue finished!');
  });
  player.events.on('error', (queue, error) => {
    console.error('Player error:', error);
    const channel = queue.metadata.channel;
    channel.send(`❌ An error occurred: ${error.message}`);
  });
  player.events.on('playerError', (queue, error) => {
    console.error('Player error:', error);
    const channel = queue.metadata.channel;
    channel.send(`❌ An error occurred while playing: ${error.message}`);
  });
  client.player = player;
  console.log('✅ Discord Player initialized successfully\n');
  
  return player;
}
module.exports = { initializeMusicPlayer };
