const { ActivityType } = require('discord.js');
module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`\n✅ Logged in as ${client.user.tag}`);
    console.log(`📊 Serving ${client.guilds.cache.size} guilds`);
    console.log(`⚡ Slash: ${client.commands.size} | Prefix: ${client.prefixCommands.size} commands\n`);
    // Set bot presence
    const activities = [
      { name: `${client.guilds.cache.size} servers`, type: ActivityType.Watching },
      { name: '/help for commands', type: ActivityType.Playing },
      { name: 'your commands', type: ActivityType.Listening },
    ];
    let i = 0;
    const cycle = () => {
      const a = activities[i % activities.length];
      client.user.setActivity(a.name, { type: a.type });
      i++;
    };
    cycle();
    setInterval(cycle, 30000);
  }
};
