const GuildSettings = require('../models/GuildSettings');
const Leveling = require('../models/Leveling');
module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;
    let settings;
    try { settings = await GuildSettings.findOne({ guildId: message.guild.id }).lean(); } catch { settings = null; }
    // ── AutoMod ──────────────────────────────────────────────
    if (settings?.automodEnabled) {
      const content = message.content.toLowerCase();
      // Banned words
      const banned = (settings.bannedWords || []).map(w => w.toLowerCase());
      if (banned.some(w => content.includes(w))) {
        await message.delete().catch(() => {});
        const warn = await message.channel.send(`⚠️ ${message.author}, that word is not allowed here.`);
        setTimeout(() => warn.delete().catch(() => {}), 4000);
        return;
      }
      // Invite links
      if (settings.automodNoInvites && /discord\.gg\//i.test(content)) {
        await message.delete().catch(() => {});
        const warn = await message.channel.send(`⚠️ ${message.author}, invite links are not allowed.`);
        setTimeout(() => warn.delete().catch(() => {}), 4000);
        return;
      }
      // Spam / duplicate messages (simple version)
      if (settings.automodAntiSpam) {
        const key = `${message.guild.id}:${message.author.id}`;
        if (!client._spamMap) client._spamMap = new Map();
        const now = Date.now();
        const recent = (client._spamMap.get(key) || []).filter(t => now - t < 5000);
        recent.push(now);
        client._spamMap.set(key, recent);
        if (recent.length >= 6) {
          await message.delete().catch(() => {});
          return;
        }
      }
    }
    // ── Leveling ─────────────────────────────────────────────
    if (settings?.levelingEnabled) {
      await processXP(message, client, settings).catch(() => {});
    }
    // ── Prefix Commands ───────────────────────────────────────
    const prefix = settings?.prefix || client.prefix || '!';
    if (!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const commandName = args.shift()?.toLowerCase();
    if (!commandName) return;
    const command = client.prefixCommands.get(commandName);
    if (!command) return;
    try {
      await command.execute(message, args, client);
    } catch (error) {
      console.error(`Prefix command error [${commandName}]:`, error);
      message.reply('❌ An error occurred.').catch(() => {});
    }
  }
};
async function processXP(message, client, settings) {
  const cooldownMs = (settings.levelingCooldown || 60) * 1000;
  const key = `${message.guild.id}:${message.author.id}`;
  if (!client._xpCooldown) client._xpCooldown = new Map();
  const last = client._xpCooldown.get(key) || 0;
  if (Date.now() - last < cooldownMs) return;
  client._xpCooldown.set(key, Date.now());
  const min = settings.levelingXpMin || 15;
  const max = settings.levelingXpMax || 25;
  const xpGain = Math.floor(Math.random() * (max - min + 1)) + min;
  let data = await Leveling.findOne({ guildId: message.guild.id, userId: message.author.id });
  if (!data) data = new Leveling({ guildId: message.guild.id, userId: message.author.id });
  data.xp += xpGain;
  data.totalXp += xpGain;
  data.messages = (data.messages || 0) + 1;
  const required = 5 * data.level * data.level + 50 * data.level + 100;
  if (data.xp >= required) {
    data.level++;
    data.xp -= required;
    const ch = settings.levelingChannel
      ? message.guild.channels.cache.get(settings.levelingChannel) || message.channel
      : message.channel;
    const msg = (settings.levelingMessage || '🎉 {mention} reached **level {level}**!')
      .replace('{mention}', message.author.toString())
      .replace('{user}', message.author.username)
      .replace('{level}', data.level)
      .replace('{xp}', data.xp);
    ch.send(msg).catch(() => {});
  }
  await data.save().catch(() => {});
}
