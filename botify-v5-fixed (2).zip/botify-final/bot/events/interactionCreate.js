const { EmbedBuilder, InteractionType } = require('discord.js');
module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    // Slash commands
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) {
        return interaction.reply({ content: '❌ Command not found.', ephemeral: true });
      }
      try {
        await command.execute(interaction, client);
      } catch (error) {
        console.error(`Error in /${interaction.commandName}:`, error);
        const errMsg = { content: '❌ An error occurred executing this command.', ephemeral: true };
        if (interaction.deferred || interaction.replied) {
          interaction.editReply(errMsg).catch(() => {});
        } else {
          interaction.reply(errMsg).catch(() => {});
        }
      }
    }
    // Autocomplete
    if (interaction.isAutocomplete()) {
      const command = client.commands.get(interaction.commandName);
      if (command?.autocomplete) {
        try { await command.autocomplete(interaction, client); } catch {}
      }
    }
    // Buttons
    if (interaction.isButton()) {
      const [action] = interaction.customId.split(':');
      // Handle ticket, verify, etc.
      if (action === 'close_ticket') {
        const ch = interaction.channel;
        if (!ch) return;
        await interaction.reply({ content: '🔒 Closing ticket in 5 seconds…', ephemeral: true });
        setTimeout(() => ch.delete().catch(() => {}), 5000);
      }
    }
  }
};
