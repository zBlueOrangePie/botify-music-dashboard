const { EmbedBuilder } = require('discord.js');
const GuildSettings = require('../models/GuildSettings');
module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    let settings;
    try { settings = await GuildSettings.findOne({ guildId: member.guild.id }).lean(); } catch { return; }
    if (!settings) return;
    // ── Welcome message ───────────────────────────────────────
    if (settings.welcomeEnabled && settings.welcomeChannel) {
      const ch = member.guild.channels.cache.get(settings.welcomeChannel);
      if (ch) {
        const msg = (settings.welcomeMessage || 'Welcome {mention} to **{server}**!')
          .replace('{mention}', member.toString())
          .replace('{user}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{count}', member.guild.memberCount);
        if (settings.welcomeEmbed) {
          const embed = new EmbedBuilder()
            .setColor(settings.welcomeColor || '#5865f2')
            .setTitle(`Welcome to ${member.guild.name}!`)
            .setDescription(msg)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();
          ch.send({ embeds: [embed] }).catch(() => {});
        } else {
          ch.send(msg).catch(() => {});
        }
      }
    }
    // ── Auto Roles ────────────────────────────────────────────
    if (settings.autoRoles?.length) {
      const delay = (settings.autoRoleDelay || 0) * 1000;
      setTimeout(async () => {
        for (const roleId of settings.autoRoles) {
          const role = member.guild.roles.cache.get(roleId);
          if (role) await member.roles.add(role).catch(() => {});
        }
      }, delay);
    }
  }
};
