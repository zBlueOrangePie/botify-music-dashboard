#!/usr/bin/env node
require('dotenv').config();
const { REST, Routes } = require('@discordjs/rest');
const fs   = require('fs');
const path = require('path');
const token    = process.env.BOT_TOKEN;
const clientId = process.env.CLIENT_ID;
const guildId  = process.env.GUILD_ID; // Optional: deploy to single guild (faster, for testing)
if (!token || !clientId) {
  console.error('❌ BOT_TOKEN and CLIENT_ID must be set in .env');
  process.exit(1);
}
const commands = [];
const slashPath = path.join(__dirname, 'commands', 'slash');
function loadCommands(dir) {
  const items = fs.readdirSync(dir);
  for (const item of items) {
    const full = path.join(dir, item);
    if (fs.statSync(full).isDirectory()) {
      loadCommands(full);
    } else if (item.endsWith('.js') && !item.startsWith('_')) {
      try {
        const cmd = require(full);
        // Could be a direct module or an object of commands
        if (cmd.data) {
          commands.push(cmd.data.toJSON());
          console.log(`  ✅ ${cmd.data.name}`);
        } else {
          // Object of commands (like music/_all.js exports, but we only load individual files)
          for (const [, c] of Object.entries(cmd)) {
            if (c?.data) {
              commands.push(c.data.toJSON());
              console.log(`  ✅ ${c.data.name}`);
            }
          }
        }
      } catch (err) {
        console.warn(`  ⚠️  ${item}: ${err.message}`);
      }
    }
  }
}
console.log('\n📂 Collecting commands…');
loadCommands(slashPath);
console.log(`\n📦 Total: ${commands.length} commands\n`);
const rest = new REST({ version: '10' }).setToken(token);
(async () => {
  try {
    console.log('🚀 Deploying to Discord…');
    let data;
    if (guildId) {
      // Guild deploy — instant
      data = await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`✅ Deployed ${data.length} commands to guild ${guildId}`);
    } else {
      // Global deploy — up to 1h to propagate
      data = await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log(`✅ Deployed ${data.length} commands globally (may take ~1 hour to show)`);
    }
  } catch (err) {
    console.error('❌ Deploy failed:', err);
    process.exit(1);
  }
})();
