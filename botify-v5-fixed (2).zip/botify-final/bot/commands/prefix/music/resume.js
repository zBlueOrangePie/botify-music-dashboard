const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'resume', aliases: ['unpause'], category: 'music', description: 'Resume playback', usage: '!resume',
  async execute(message) {
    const queue = useQueue(message.guild.id);
    if (!queue) return message.reply('❌ Nothing is queued!');
    if (!queue.node.isPaused()) return message.reply('❌ Not paused. Use `!pause` first.');
    queue.node.resume();
    await message.reply({ embeds: [new EmbedBuilder().setColor('#3ba55d').setTitle('▶️ Resumed').setDescription(`Resumed **${queue.currentTrack?.title}**`).setTimestamp()] });
  }
};
