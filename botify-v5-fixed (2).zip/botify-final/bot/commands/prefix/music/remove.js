const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'remove', aliases: ['rm'], category: 'music', description: 'Remove a track from the queue', usage: '!remove [position]',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const pos = parseInt(args[0]) - 1;
    const tracks = queue.tracks.toArray();
    if (isNaN(pos)||pos<0||pos>=tracks.length) return message.reply(`❌ Invalid position. Queue has **${tracks.length}** tracks.`);
    const removed = tracks[pos];
    queue.node.remove(pos);
    await message.reply({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('🗑️ Track Removed').setDescription(`Removed **${removed.title}** from the queue.`).setTimestamp()] });
  }
};
