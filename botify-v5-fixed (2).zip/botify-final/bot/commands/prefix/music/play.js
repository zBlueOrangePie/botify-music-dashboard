const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'play', aliases: ['p'], category: 'music',
  description: 'Play a song from YouTube/Spotify/SoundCloud', usage: '!play [song name or URL]',
  async execute(message, args, client) {
    if (!message.member.voice.channel)
      return message.reply('❌ You must be in a voice channel!');
    const query = args.join(' ');
    if (!query) return message.reply('❌ Provide a song name or URL. Usage: `!play never gonna give you up`');
    const player = client.player;
    if (!player) return message.reply('❌ Music player not initialized.');
    try {
      const result = await player.search(query, { requestedBy: message.author });
      if (!result?.tracks?.length) return message.reply(`❌ No results found for **${query}**.`);
      const { track } = await player.play(message.member.voice.channel, result, {
        nodeOptions: { metadata: { channel: message.channel, requestedBy: message.author }, volume: 80, selfDeaf: true, leaveOnEmpty: true, leaveOnEnd: true }
      });
      await message.reply({ embeds: [new EmbedBuilder().setColor('#3ba55d')
        .setTitle(result.playlist ? '📋 Playlist Added' : '🎵 Added to Queue')
        .setDescription(result.playlist ? `**${result.playlist.title}** — ${result.tracks.length} tracks` : `**${track.title}** by ${track.author}`)
        .setThumbnail(track.thumbnail).addFields({ name:'⏱️ Duration', value:track.duration||'Live', inline:true })
        .setFooter({ text:`Requested by ${message.author.tag}` }).setTimestamp()] });
    } catch (err) { await message.reply(`❌ Error: ${err.message}`); }
  }
};
