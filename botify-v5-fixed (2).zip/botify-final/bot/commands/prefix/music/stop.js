const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'stop', aliases: ['leave', 'disconnect', 'dc'], category: 'music',
  description: 'Stop music and clear the queue', usage: '!stop',
  async execute(message) {
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const queue = useQueue(message.guild.id);
    if (!queue) return message.reply('❌ Nothing is playing!');
    queue.delete();
    await message.reply({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('⏹️ Stopped').setDescription('Music stopped and queue cleared.').setTimestamp()] });
  }
};
