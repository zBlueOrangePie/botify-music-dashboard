const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');

const filterMap = {
  bassboost: 'bass=g=15',
  nightcore: 'asetrate=44100*1.3,aresample=44100',
  vaporwave: 'asetrate=44100*0.8,aresample=44100',
  '8d':      'apulsator=hz=0.08',
  karaoke:   'pan=stereo|c0=c0|c1=c1,volume=2,stereotools=mlev=0.1',
  vibrato:   'vibrato=f=7:d=0.5',
  tremolo:   'tremolo=f=5:d=0.5',
};
const labels = { bassboost:'🔊 Bass Boost', nightcore:'🌙 Nightcore', vaporwave:'🌊 Vaporwave', '8d':'🎧 8D Audio', karaoke:'🎤 Karaoke', vibrato:'〰️ Vibrato', tremolo:'🔉 Tremolo' };

module.exports = {
  name: 'filter', aliases: ['eq','fx'], category: 'music',
  usage: '!filter <bassboost|nightcore|vaporwave|8d|karaoke|vibrato|tremolo|clear>', description: 'Apply an audio filter',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const effect = args[0]?.toLowerCase();
    if (!effect) return message.reply(`❌ Provide a filter: \`${Object.keys(filterMap).join(' | ')}\` | \`clear\``);
    if (effect === 'clear') {
      await queue.filters.ffmpeg.setInputAudioFilters([]).catch(()=>{});
      return message.reply({ embeds:[new EmbedBuilder().setColor('#5865f2').setTitle('🎵 Filters Cleared').setTimestamp()] });
    }
    if (!filterMap[effect]) return message.reply(`❌ Unknown filter. Valid: \`${Object.keys(filterMap).join(' | ')}\``);
    await queue.filters.ffmpeg.setInputAudioFilters([filterMap[effect]]).catch(()=>{});
    await message.reply({ embeds:[new EmbedBuilder().setColor('#5865f2').setTitle(`${labels[effect]} Applied`).setDescription(`Filter **${labels[effect]}** is now active.\nUse \`!filter clear\` to remove.`).setTimestamp()] });
  }
};
