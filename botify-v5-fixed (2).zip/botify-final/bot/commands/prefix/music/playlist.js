const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'playlist', aliases: ['pl'], category: 'music',
  usage: '!playlist <url>', description: 'Load and play a playlist by URL',
  async execute(message, args) {
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const player = message.client.player;
    if (!player) return message.reply('❌ Music player not initialized.');
    const url = args[0];
    if (!url) return message.reply('❌ Provide a playlist URL.\n**Usage:** `!playlist <url>`');
    const loading = await message.reply('⏳ Loading playlist...');
    try {
      const result = await player.search(url, { requestedBy: message.author });
      if (!result?.tracks?.length) return loading.edit('❌ No tracks found. Make sure the playlist is public.');
      if (!result.playlist) return loading.edit('❌ That does not look like a playlist. Use `!play` for single songs.');
      const { track: first } = await player.play(message.member.voice.channel, result, {
        nodeOptions: { metadata:{ channel:message.channel, requestedBy:message.author }, volume:80, selfDeaf:true, leaveOnEmpty:true, leaveOnEnd:true }
      });
      await loading.edit({ content:null, embeds:[new EmbedBuilder()
        .setColor('#3ba55d').setTitle('📋 Playlist Loaded').setDescription(`**${result.playlist.title}**`)
        .setThumbnail(first.thumbnail)
        .addFields({ name:'🎵 Tracks', value:String(result.tracks.length), inline:true },{ name:'▶️ Now Playing', value:first.title, inline:true })
        .setFooter({text:`Requested by ${message.author.tag}`}).setTimestamp()
      ]});
    } catch(err) { await loading.edit(`❌ Failed: ${err.message}`); }
  }
};
