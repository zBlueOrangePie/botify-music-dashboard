const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'volume', aliases: ['vol', 'v'], category: 'music', description: 'Set playback volume (1-100)', usage: '!volume [1-100]',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const level = parseInt(args[0]);
    if (isNaN(level)||level<1||level>100) return message.reply('❌ Provide a volume between 1 and 100. Usage: `!volume 80`');
    queue.node.setVolume(level);
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`🔊 Volume: ${level}%`).setDescription(`Volume set to **${level}%**`).setTimestamp()] });
  }
};
