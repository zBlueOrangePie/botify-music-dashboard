const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'nowplaying', aliases: ['np', 'current'], category: 'music', description: 'Show current track', usage: '!nowplaying',
  async execute(message) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const t = queue.currentTrack;
    if (!t) return message.reply('❌ No track info available.');
    const progress = queue.node.getTimestamp();
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('🎵 Now Playing')
      .setDescription(`**[${t.title}](${t.url})**`).setThumbnail(t.thumbnail)
      .addFields(
        { name:'🎤 Artist', value:t.author||'Unknown', inline:true },
        { name:'⏱️ Duration', value:t.duration||'Live', inline:true },
        { name:'📍 Progress', value:progress?`${progress.current.label} / ${progress.total.label}`:'—', inline:true },
        { name:'👤 Requested By', value:t.requestedBy?.tag||'Unknown', inline:true }
      ).setTimestamp()] });
  }
};
