const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'skip', aliases: ['s', 'next'], category: 'music',
  description: 'Skip the current song', usage: '!skip',
  async execute(message) {
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const track = queue.currentTrack;
    queue.node.skip();
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('⏭️ Skipped').setDescription(`Skipped **${track?.title||'current track'}**`).setTimestamp()] });
  }
};
