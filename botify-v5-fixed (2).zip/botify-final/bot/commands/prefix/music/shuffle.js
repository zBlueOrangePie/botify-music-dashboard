const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'shuffle', aliases: ['mix'], category: 'music', description: 'Shuffle the queue', usage: '!shuffle',
  async execute(message) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    if (queue.tracks.size < 2) return message.reply('❌ Need at least 2 songs in queue to shuffle.');
    queue.tracks.shuffle();
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('🔀 Queue Shuffled').setDescription(`Shuffled **${queue.tracks.size}** tracks!`).setTimestamp()] });
  }
};
