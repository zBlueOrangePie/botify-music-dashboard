const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'queue', aliases: ['q'], category: 'music', description: 'View the music queue', usage: '!queue',
  async execute(message) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const current = queue.currentTrack;
    const tracks  = queue.tracks.toArray().slice(0, 10);
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('📋 Music Queue')
      .addFields(
        { name:'▶️ Now Playing', value: current?`[${current.title}](${current.url}) by ${current.author}`:'Nothing' },
        { name:`📜 Up Next (${tracks.length})`, value: tracks.length?tracks.map((t,i)=>`\`${i+1}.\` ${t.title}`).join('\n'):'Queue is empty' }
      ).setThumbnail(current?.thumbnail).setFooter({ text:`${queue.tracks.size} track(s) in queue` }).setTimestamp()] });
  }
};
