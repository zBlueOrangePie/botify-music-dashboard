const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');

module.exports = {
  name: 'skipto', aliases: ['goto','st'], category: 'music',
  usage: '!skipto <position>', description: 'Jump to a position in the queue',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const pos = parseInt(args[0]) - 1;
    if (isNaN(pos)||pos<0) return message.reply('❌ Provide a valid position number.\n**Usage:** `!skipto <number>`');
    const tracks = queue.tracks.toArray();
    if (pos>=tracks.length) return message.reply(`❌ Position out of range. Queue has **${tracks.length}** tracks.`);
    const target = tracks[pos];
    for (let i=0;i<pos;i++) queue.node.remove(0);
    queue.node.skip();
    await message.reply({ embeds:[new EmbedBuilder().setColor('#5865f2').setTitle('⏭️ Skipped To Track')
      .setDescription(`Now playing **${target.title}** by **${target.author}**`).setThumbnail(target.thumbnail).setTimestamp()] });
  }
};
