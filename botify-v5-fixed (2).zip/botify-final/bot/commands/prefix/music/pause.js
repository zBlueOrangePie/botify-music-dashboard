const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'pause', category: 'music', description: 'Pause playback', usage: '!pause',
  async execute(message) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    if (queue.node.isPaused()) return message.reply('❌ Already paused. Use `!resume`');
    queue.node.pause();
    await message.reply({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle('⏸️ Paused').setDescription(`Paused **${queue.currentTrack?.title}**`).setTimestamp()] });
  }
};
