const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
  name: 'search', aliases: ['find','sr'], category: 'music',
  usage: '!search <query>', description: 'Search for a song and pick from results',
  async execute(message, args) {
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const player = message.client.player;
    if (!player) return message.reply('❌ Music player not initialized.');
    const query = args.join(' ');
    if (!query) return message.reply('❌ Provide a search query.\n**Usage:** `!search <song name>`');
    const loading = await message.reply(`🔍 Searching for **${query}**...`);
    const results = await player.search(query, { requestedBy: message.author }).catch(()=>null);
    if (!results?.tracks?.length) return loading.edit(`❌ No results for **${query}**.`);
    const tracks = results.tracks.slice(0,10);
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`search_${message.author.id}`)
      .setPlaceholder('Choose a song...')
      .addOptions(tracks.map((t,i)=>({ label:t.title.slice(0,100), description:`${t.author} · ${t.duration}`.slice(0,100), value:String(i), emoji:'🎵' })));
    const embed = new EmbedBuilder().setColor('#5865f2').setTitle(`🔍 Results for: ${query}`)
      .setDescription(tracks.map((t,i)=>`\`${i+1}.\` **${t.title}** by ${t.author} · \`${t.duration}\``).join('\n'))
      .setFooter({text:'Select below — expires in 30s'}).setTimestamp();
    const msg = await loading.edit({ content:null, embeds:[embed], components:[new ActionRowBuilder().addComponents(menu)] });
    const collector = msg.createMessageComponentCollector({ time:30000 });
    collector.on('collect', async sel => {
      if (sel.user.id!==message.author.id) return sel.reply({content:'❌ Not your search!',ephemeral:true});
      const track = tracks[parseInt(sel.values[0])];
      try {
        await player.play(message.member.voice.channel, track, {
          nodeOptions:{ metadata:{channel:message.channel,requestedBy:message.author}, volume:80, selfDeaf:true }
        });
        await sel.update({ embeds:[new EmbedBuilder().setColor('#3ba55d').setTitle('🎵 Added to Queue')
          .setDescription(`**${track.title}** by **${track.author}**`).setThumbnail(track.thumbnail)
          .addFields({name:'⏱️ Duration',value:track.duration||'Live',inline:true}).setTimestamp()
        ], components:[] });
      } catch(err) { await sel.update({ content:`❌ ${err.message}`, components:[] }); }
      collector.stop();
    });
    collector.on('end',(_,r)=>{ if(r==='time') msg.edit({components:[]}).catch(()=>{}); });
  }
};
