const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'seek', category: 'music', description: 'Seek to a position in current track', usage: '!seek [1:30 or 90]',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const input = args[0];
    if (!input) return message.reply('❌ Provide a time. Usage: `!seek 1:30` or `!seek 90`');
    let ms;
    if (input.includes(':')) { const p=input.split(':').map(Number); ms=p.length===2?(p[0]*60+p[1])*1000:(p[0]*3600+p[1]*60+p[2])*1000; }
    else { ms=parseInt(input)*1000; }
    if (isNaN(ms)||ms<0) return message.reply('❌ Invalid time. Use `1:30` or `90` (seconds).');
    try {
      await queue.node.seek(ms);
      await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('⏩ Seeked').setDescription(`Jumped to position in **${queue.currentTrack.title}**`).setTimestamp()] });
    } catch { await message.reply('❌ Could not seek in this track.'); }
  }
};
