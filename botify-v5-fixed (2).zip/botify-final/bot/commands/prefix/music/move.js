const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');

module.exports = {
  name: 'move', aliases: ['mv'], category: 'music',
  usage: '!move <from> <to>', description: 'Move a track in the queue',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    if (!message.member.voice.channel) return message.reply('❌ Join a voice channel first!');
    const from = parseInt(args[0]) - 1;
    const to   = parseInt(args[1]) - 1;
    if (isNaN(from)||isNaN(to)) return message.reply('❌ Provide two positions.\n**Usage:** `!move <from> <to>`');
    const tracks = queue.tracks.toArray();
    if (from<0||from>=tracks.length||to<0||to>=tracks.length) return message.reply(`❌ Positions must be between 1 and ${tracks.length}.`);
    if (from===to) return message.reply('❌ Same position!');
    const [moved] = tracks.splice(from,1);
    tracks.splice(to,0,moved);
    queue.tracks.clear();
    for (const t of tracks) queue.tracks.push(t);
    await message.reply({ embeds:[new EmbedBuilder().setColor('#5865f2').setTitle('↕️ Track Moved')
      .setDescription(`**${moved.title}** moved from #${from+1} to #${to+1}.`).setTimestamp()] });
  }
};
