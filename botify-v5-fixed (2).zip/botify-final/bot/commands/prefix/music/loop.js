const { EmbedBuilder } = require('discord.js');
const { useQueue, QueueRepeatMode } = require('discord-player');
module.exports = {
  name: 'loop', aliases: ['repeat'], category: 'music', description: 'Set loop mode', usage: '!loop [off/track/queue]',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    if (!queue?.isPlaying()) return message.reply('❌ Nothing is playing!');
    const mode = args[0]?.toLowerCase() || 'off';
    const map = { off: QueueRepeatMode.OFF, track: QueueRepeatMode.TRACK, queue: QueueRepeatMode.QUEUE, autoplay: QueueRepeatMode.AUTOPLAY };
    const labels = { off:'🚫 Off', track:'🔂 Track', queue:'🔁 Queue', autoplay:'🔃 Autoplay' };
    if (!map.hasOwnProperty(mode)) return message.reply('❌ Valid modes: `off`, `track`, `queue`, `autoplay`');
    queue.setRepeatMode(map[mode]);
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('🔁 Loop Mode').setDescription(`Loop set to **${labels[mode]}**`).setTimestamp()] });
  }
};
