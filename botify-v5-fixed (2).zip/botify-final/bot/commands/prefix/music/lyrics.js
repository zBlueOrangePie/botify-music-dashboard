const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  name: 'lyrics', aliases: ['ly'], category: 'music', description: 'Get lyrics for a song', usage: '!lyrics [song name]',
  async execute(message, args) {
    const queue = useQueue(message.guild.id);
    const query = args.join(' ') || queue?.currentTrack?.title;
    if (!query) return message.reply('❌ No song playing and no song name provided.');
    try {
      const { lyricsExtractor } = require('@discord-player/extractor');
      const genius = lyricsExtractor();
      const result = await genius.search(query);
      if (!result) return message.reply(`❌ No lyrics found for **${query}**.`);
      const lyrics = result.lyrics.length>3900 ? result.lyrics.substring(0,3900)+'...\n*(truncated)*' : result.lyrics;
      await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`🎵 ${result.title}`).setDescription(lyrics).setThumbnail(result.thumbnail).setFooter({ text:`Artist: ${result.artist.name}` }).setTimestamp()] });
    } catch {
      await message.reply({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle(`🎵 Lyrics: ${query}`).setDescription('Lyrics not available. Try [Genius](https://genius.com).').setTimestamp()] });
    }
  }
};
