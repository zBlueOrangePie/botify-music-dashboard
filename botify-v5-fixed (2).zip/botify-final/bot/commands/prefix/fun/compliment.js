const { EmbedBuilder } = require('discord.js');
const COMPLIMENTS = [
  "You light up every room you walk into ✨","Your kindness is like a superpower 💙",
  "The world is genuinely a better place with you in it 🌍","You have an incredible ability to make people smile 😄",
  "Your creativity knows absolutely no bounds 🎨","You're stronger than you think 💪",
];
module.exports = {
  name: 'compliment', aliases: ['nice', 'comp'], category: 'fun',
  description: 'Send a wholesome compliment', usage: '!compliment @user',
  async execute(message) {
    const target = message.mentions.users.first() || message.author;
    const line = COMPLIMENTS[Math.floor(Math.random()*COMPLIMENTS.length)];
    await message.reply({ embeds: [new EmbedBuilder().setColor('#ff69b4').setTitle('💙 A Compliment For You!')
      .setDescription(`${target}, **${line}**`).setThumbnail(target.displayAvatarURL())
      .setFooter({ text:`Sent with ❤️ by ${message.author.tag}` }).setTimestamp()] });
  }
};
