const { EmbedBuilder } = require('discord.js');
const JOKES = [
  { setup:"Why don't scientists trust atoms?", punchline:"Because they make up everything!" },
  { setup:"Why did the JavaScript developer go broke?", punchline:"Because he used up all his cache!" },
  { setup:"Why do programmers prefer dark mode?", punchline:"Because light attracts bugs!" },
  { setup:"A SQL query walks into a bar...", punchline:"...and asks: 'Can I join you?'" },
  { setup:"Why was the JavaScript developer sad?", punchline:"Because he didn't Node how to Express himself!" },
  { setup:"What do you call a sleeping dinosaur?", punchline:"A dino-snore!" },
  { setup:"Why did the scarecrow win an award?", punchline:"Because he was outstanding in his field!" },
  { setup:"What did the ocean say to the beach?", punchline:"Nothing, it just waved." },
];
module.exports = {
  name: 'joke', aliases: ['j'], category: 'fun',
  description: 'Get a random joke', usage: '!joke',
  async execute(message) {
    const joke = JOKES[Math.floor(Math.random() * JOKES.length)];
    await message.reply({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle('😂 Random Joke')
      .addFields({ name:'❓ Setup', value:joke.setup }, { name:'💬 Punchline', value:`||${joke.punchline}||` })
      .setFooter({ text:'Click the spoiler to reveal!' }).setTimestamp()] });
  }
};
