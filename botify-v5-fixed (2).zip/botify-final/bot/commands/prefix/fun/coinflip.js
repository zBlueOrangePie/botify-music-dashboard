const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'coinflip', aliases: ['flip', 'coin'], category: 'fun',
  description: 'Flip a coin', usage: '!coinflip',
  async execute(message) {
    const result = Math.random() > 0.5 ? 'Heads' : 'Tails';
    await message.reply({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle(`🪙 ${result}!`)
      .setDescription(`The coin landed on **${result}**!`).setFooter({ text: `Flipped by ${message.author.tag}` }).setTimestamp()] });
  }
};
