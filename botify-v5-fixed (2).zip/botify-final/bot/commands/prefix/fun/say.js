const { PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'say', category: 'fun', usage: '!say [#channel] <message>', description: 'Make the bot say something',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages))
      return message.reply('❌ You need **Manage Messages** permission.');
    const channel = message.mentions.channels.first() || message.channel;
    const text = args.filter(a => !a.startsWith('<#')).join(' ');
    if (!text) return message.reply('❌ Provide a message.\n**Usage:** `!say <message>`');
    await channel.send(text).catch(() => {});
    await message.delete().catch(() => {});
  }
};
