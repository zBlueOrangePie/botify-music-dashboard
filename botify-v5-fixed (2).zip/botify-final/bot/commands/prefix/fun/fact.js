const { EmbedBuilder } = require('discord.js');
const https = require('https');
const FALLBACK = ["Honey never expires — archaeologists found 3000-year-old honey in Egypt still edible.","Octopuses have three hearts and blue blood.","A day on Venus is longer than a year on Venus.","Wombat poop is cube-shaped — the only animal to produce cube feces.","Bananas are technically berries, but strawberries are not."];
function fetchJson(url){return new Promise((r,e)=>{https.get(url,{headers:{'User-Agent':'Botify/5.0'}},res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{try{r(JSON.parse(d));}catch{e();}});}).on('error',e);});}
module.exports = {
  name: 'fact', aliases: ['funfact'], category: 'fun',
  description: 'Get a random interesting fact', usage: '!fact',
  async execute(message) {
    try {
      const data = await fetchJson('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en');
      const fact = data?.text || FALLBACK[Math.floor(Math.random()*FALLBACK.length)];
      await message.reply({ embeds: [new EmbedBuilder().setColor('#00d9b0').setTitle('🤓 Random Fact').setDescription(`**${fact}**`).setTimestamp()] });
    } catch {
      const fact = FALLBACK[Math.floor(Math.random()*FALLBACK.length)];
      await message.reply({ embeds: [new EmbedBuilder().setColor('#00d9b0').setTitle('🤓 Random Fact').setDescription(`**${fact}**`).setTimestamp()] });
    }
  }
};
