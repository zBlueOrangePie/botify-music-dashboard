const { EmbedBuilder } = require('discord.js');
const https = require('https');
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers:{ 'User-Agent':'Botify/5.0' } }, res => {
      let d=''; res.on('data', c=>d+=c); res.on('end', ()=>{ try{resolve(JSON.parse(d));}catch{reject();} });
    }).on('error', reject);
  });
}
const SUBS = ['memes','dankmemes','wholesomememes','programmerhumor'];
module.exports = {
  name: 'meme', aliases: ['m'], category: 'fun',
  description: 'Random Reddit meme', usage: '!meme [subreddit]',
  async execute(message, args) {
    const sub = args[0] || SUBS[Math.floor(Math.random()*SUBS.length)];
    try {
      const data = await fetchJson(`https://www.reddit.com/r/${sub}/random.json?limit=1`);
      const post = data?.[0]?.data?.children?.[0]?.data;
      if (!post || post.over_18) return message.reply('❌ Could not fetch a meme. Try again!');
      await message.reply({ embeds: [new EmbedBuilder().setColor('#ff4500')
        .setTitle(post.title.length>250?post.title.substring(0,247)+'...':post.title)
        .setURL(`https://reddit.com${post.permalink}`).setImage(post.url)
        .setFooter({ text:`👍 ${post.ups.toLocaleString()} · r/${sub}` }).setTimestamp()] });
    } catch { await message.reply('❌ Could not reach Reddit right now.'); }
  }
};
