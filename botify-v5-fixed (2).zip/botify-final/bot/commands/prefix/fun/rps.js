const { EmbedBuilder } = require('discord.js');
const CHOICES = ['rock','paper','scissors'];
const EMOJIS  = { rock:'🪨', paper:'📄', scissors:'✂️' };
module.exports = {
  name: 'rps', aliases: ['rockpaperscissors'], category: 'fun',
  description: 'Rock, Paper, Scissors vs bot', usage: '!rps [rock/paper/scissors]',
  async execute(message, args) {
    const player = args[0]?.toLowerCase();
    if (!CHOICES.includes(player)) return message.reply('❌ Choose rock, paper, or scissors. Usage: `!rps rock`');
    const bot = CHOICES[Math.floor(Math.random() * 3)];
    let result, color;
    if (player===bot){result="It's a tie! 🤝";color='#faa61a';}
    else if((player==='rock'&&bot==='scissors')||(player==='paper'&&bot==='rock')||(player==='scissors'&&bot==='paper')){result='You win! 🎉';color='#3ba55d';}
    else{result='Bot wins! 🤖';color='#ed4245';}
    await message.reply({ embeds: [new EmbedBuilder().setColor(color).setTitle('Rock, Paper, Scissors!')
      .addFields({ name:'Your Choice', value:`${EMOJIS[player]} ${player}`, inline:true }, { name:"Bot's Choice", value:`${EMOJIS[bot]} ${bot}`, inline:true }, { name:'Result', value:`**${result}**` }).setTimestamp()] });
  }
};
