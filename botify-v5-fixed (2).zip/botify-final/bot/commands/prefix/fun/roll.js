const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'roll', aliases: ['dice', 'r'], category: 'fun',
  description: 'Roll dice', usage: '!roll [NdS] e.g. 2d6',
  async execute(message, args) {
    let sides = 6, count = 1;
    if (args[0]) {
      if (args[0].includes('d')) { const p = args[0].split('d'); count = parseInt(p[0])||1; sides = parseInt(p[1])||6; }
      else { sides = parseInt(args[0]) || 6; }
    }
    count = Math.min(count, 10); sides = Math.min(sides, 1000);
    const rolls = Array.from({ length: count }, () => Math.ceil(Math.random() * sides));
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`🎲 Dice Roll (${count}d${sides})`)
      .addFields({ name: '🎲 Rolls', value: rolls.map(r=>`\`${r}\``).join(' + '), inline: true }, { name: '💯 Total', value: `**${rolls.reduce((a,b)=>a+b,0)}**`, inline: true }).setTimestamp()] });
  }
};
