const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'ship', aliases: ['love'], category: 'fun',
  description: 'Ship two users together', usage: '!ship @user1 @user2',
  async execute(message) {
    const users = message.mentions.users;
    if (users.size < 2) return message.reply('❌ Mention two users! Usage: `!ship @user1 @user2`');
    const [u1, u2] = users.values();
    const rate = Math.floor(Math.random()*101);
    const bar  = '❤️'.repeat(Math.floor(rate/10)) + '🖤'.repeat(10-Math.floor(rate/10));
    const name = u1.username.slice(0,Math.ceil(u1.username.length/2)) + u2.username.slice(Math.floor(u2.username.length/2));
    const msg  = rate>=80?'💞 A perfect match!':rate>=50?'💕 There\'s potential!':rate>=25?'💛 Just friends... for now.':'💔 Not meant to be.';
    await message.reply({ embeds: [new EmbedBuilder().setColor('#ff69b4').setTitle('💘 Shipping!')
      .setDescription(`**${u1.username}** + **${u2.username}** = **${name}**`)
      .addFields({ name:'❤️ Compatibility', value:`${bar} **${rate}%**` }, { name:'💬 Verdict', value:msg }).setTimestamp()] });
  }
};
