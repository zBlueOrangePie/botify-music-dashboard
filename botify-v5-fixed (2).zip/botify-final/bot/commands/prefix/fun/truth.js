const { EmbedBuilder } = require('discord.js');
const TRUTHS=["What's the most embarrassing thing you've ever done?","Have you ever lied to get out of trouble?","What is your biggest secret?","Have you ever ghosted someone?","What's the weirdest thing you've Googled?","Have you ever cheated on a test?","What's the most childish thing you still do?"];
const DARES=["Send a voice message of you singing a random song.","Change your nickname to whatever the next person says for an hour.","Write a poem about the last person who messaged you.","React to the last 5 messages with the weirdest emoji you can find.","Let the next person who messages you change your status."];
module.exports = {
  name: 'truth', aliases: ['dare', 'tod'], category: 'fun',
  description: 'Truth or Dare prompt', usage: '!truth OR !dare',
  async execute(message, args, client, type) {
    const isTruth = message.content.slice(1).split(' ')[0].toLowerCase() !== 'dare';
    const list = isTruth ? TRUTHS : DARES;
    const pick = list[Math.floor(Math.random()*list.length)];
    await message.reply({ embeds: [new EmbedBuilder().setColor(isTruth?'#5865f2':'#ed4245')
      .setTitle(isTruth?'😇 TRUTH':'😈 DARE').setDescription(`**${pick}**`)
      .setFooter({ text:`For ${message.author.tag}` }).setTimestamp()] });
  }
};
