const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const https = require('https');

function fetchJson(url) {
  return new Promise((res, rej) => {
    https.get(url, r => { let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try{ res(JSON.parse(d)); }catch{ rej(); } }); }).on('error',rej);
  });
}
function decode(s) { return s.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#039;/g,"'"); }

module.exports = {
  name: 'trivia', aliases: ['quiz'], category: 'fun',
  usage: '!trivia', description: 'Answer a random trivia question',
  async execute(message) {
    let q;
    try {
      const data = await fetchJson('https://opentdb.com/api.php?amount=1&type=multiple');
      q = data.results?.[0];
    } catch { return message.reply('❌ Could not fetch a trivia question right now. Try again later.'); }
    if (!q) return message.reply('❌ No question received.');
    const correct = decode(q.correct_answer);
    const answers = [...q.incorrect_answers.map(decode), correct].sort(() => Math.random() - 0.5);
    const labels  = ['A','B','C','D'];
    const correctIdx = answers.indexOf(correct);
    const row = new ActionRowBuilder().addComponents(
      answers.map((a,i) => new ButtonBuilder().setCustomId(`triv_${i}`).setLabel(`${labels[i]}. ${a}`).setStyle(ButtonStyle.Secondary))
    );
    const embed = new EmbedBuilder()
      .setColor('#5865f2').setTitle('🧠 Trivia Question')
      .addFields(
        { name: '❓ Question',   value: decode(q.question) },
        { name: '📚 Category',   value: decode(q.category), inline: true },
        { name: '⚡ Difficulty', value: q.difficulty, inline: true }
      ).setFooter({ text: 'You have 30 seconds!' }).setTimestamp();
    const msg = await message.reply({ embeds: [embed], components: [row] });
    const collector = msg.createMessageComponentCollector({ time: 30000 });
    collector.on('collect', async btn => {
      if (btn.user.id !== message.author.id) return btn.reply({ content:'❌ Not your question!', ephemeral:true });
      const chosen = parseInt(btn.customId.replace('triv_',''));
      const won = chosen === correctIdx;
      await btn.update({ embeds:[new EmbedBuilder()
        .setColor(won?'#3ba55d':'#ed4245')
        .setTitle(won?'✅ Correct!':'❌ Wrong!')
        .addFields(
          { name:'Question', value:decode(q.question) },
          { name:'Your Answer', value:answers[chosen], inline:true },
          { name:'Correct Answer', value:correct, inline:true }
        ).setTimestamp()
      ], components:[] });
      collector.stop();
    });
    collector.on('end',(_,r)=>{ if(r==='time') msg.edit({ embeds:[new EmbedBuilder().setColor('#faa61a').setTitle('⏰ Time\'s Up!').addFields({name:'Correct Answer',value:correct}).setTimestamp()], components:[] }).catch(()=>{}); });
  }
};
