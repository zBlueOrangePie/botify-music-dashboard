const { EmbedBuilder } = require('discord.js');
const QUESTIONS=[["be able to fly","be invisible"],["never use social media again","never watch another movie/TV show again"],["be the funniest person in the room","be the smartest person in the room"],["be famous but broke","be rich but anonymous"],["fight 100 duck-sized horses","fight 1 horse-sized duck"],["live in a world without colours","live in a world without music"]];
module.exports = {
  name: 'wyr', aliases: ['wouldyourather'], category: 'fun',
  description: 'Would You Rather dilemma', usage: '!wyr',
  async execute(message) {
    const [a,b] = QUESTIONS[Math.floor(Math.random()*QUESTIONS.length)];
    await message.reply({ embeds: [new EmbedBuilder().setColor('#a855f7').setTitle('🤔 Would You Rather…')
      .addFields({ name:'🔵 Option A', value:a, inline:true }, { name:'🔴 Option B', value:b, inline:true })
      .setFooter({ text:'Reply with A or B!' }).setTimestamp()] });
  }
};
