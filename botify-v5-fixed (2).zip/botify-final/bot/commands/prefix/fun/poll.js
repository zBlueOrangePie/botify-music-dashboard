module.exports = {
  name: 'poll', category: 'fun',
  description: 'Create a quick Yes/No poll', usage: '!poll [question]',
  async execute(message, args) {
    const question = args.join(' ');
    if (!question) return message.reply('❌ Provide a question. Usage: `!poll Should we add more bots?`');
    const msg = await message.channel.send(`📊 **${question}**\n*Poll by ${message.author.tag}*`);
    await msg.react('👍');
    await msg.react('👎');
    await message.delete().catch(()=>{});
  }
};
