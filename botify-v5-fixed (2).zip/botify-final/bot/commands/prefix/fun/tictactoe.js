const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const TicTacToe = require('../../models/TicTacToe');

function makeBoard() { return Array(9).fill(null); }
function makeRows(board, disabled) {
  const rows = [];
  for (let r = 0; r < 3; r++) {
    rows.push(new ActionRowBuilder().addComponents(
      [0,1,2].map(c => {
        const i = r*3+c;
        return new ButtonBuilder()
          .setCustomId(`pttt_${i}`)
          .setLabel(board[i]==='X'?'❌':board[i]==='O'?'⭕':'⬜')
          .setStyle(board[i]==='X'?ButtonStyle.Danger:board[i]==='O'?ButtonStyle.Primary:ButtonStyle.Secondary)
          .setDisabled(disabled||board[i]!==null);
      })
    ));
  }
  return rows;
}
function checkWin(b,p){ return [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].some(w=>w.every(i=>b[i]===p)); }
function bestMove(b){
  for(const p of['O','X']){ for(let i=0;i<9;i++){ if(!b[i]){b[i]=p;if(checkWin(b,p)){b[i]=null;if(p==='O')return i;else break;}b[i]=null;} } }
  if(!b[4])return 4;
  const c=[0,2,6,8].filter(i=>!b[i]);if(c.length)return c[Math.floor(Math.random()*c.length)];
  const e=b.reduce((a,v,i)=>v?a:[...a,i],[]);return e[Math.floor(Math.random()*e.length)];
}
async function saveStats(userId,username,avatar,result,ms){
  try{
    let r=await TicTacToe.findOne({userId});
    if(!r)r=new TicTacToe({userId});
    r.username=username;r.avatar=avatar;r.totalGames++;r.totalTime+=ms;r.lastPlayed=new Date();
    if(result==='win'){r.wins++;if(r.fastestWin===null||ms<r.fastestWin)r.fastestWin=ms;}
    else if(result==='loss')r.losses++;else r.draws++;
    await r.save();
  }catch{}
}

module.exports = {
  name: 'tictactoe', aliases: ['ttt'],
  category: 'fun', usage: '!tictactoe [easy|hard]', description: 'Play Tic-Tac-Toe vs the bot (stats tracked!)',
  async execute(message, args) {
    const difficulty = args[0]?.toLowerCase() === 'easy' ? 'easy' : 'hard';
    const board = makeBoard();
    const player = message.author;
    const startTime = Date.now();

    const embed = () => new EmbedBuilder().setColor('#5865f2').setTitle('❌ Tic-Tac-Toe')
      .setDescription(`You are ❌ · Bot is ⭕\n**Your turn!** (${difficulty} mode)`)
      .setFooter({ text: 'Game expires in 2 minutes' });

    const msg = await message.reply({ embeds: [embed()], components: makeRows(board) });
    const collector = msg.createMessageComponentCollector({ time: 120000 });

    collector.on('collect', async btn => {
      if (btn.user.id !== player.id)
        return btn.reply({ content: '❌ Not your game!', ephemeral: true });

      const i = parseInt(btn.customId.replace('pttt_',''));
      if (board[i]) return btn.reply({ content: '❌ Already taken!', ephemeral: true });

      board[i] = 'X';
      const dur = Date.now() - startTime;

      if (checkWin(board,'X')) {
        collector.stop('done');
        await saveStats(player.id, player.username, player.displayAvatarURL(), 'win', dur);
        const s=Math.floor(dur/1000); const t=s<60?`${s}s`:`${Math.floor(s/60)}m ${s%60}s`;
        return btn.update({ embeds:[new EmbedBuilder().setColor('#3ba55d').setTitle('🎉 You Win!')
          .setDescription(`You beat the bot in **${t}**!`)
          .addFields({name:'⏱️ Time',value:t,inline:true},{name:'🎮 Difficulty',value:difficulty,inline:true})]
          , components:makeRows(board,true)});
      }
      if (board.every(Boolean)) {
        collector.stop('done');
        await saveStats(player.id,player.username,player.displayAvatarURL(),'draw',dur);
        return btn.update({embeds:[new EmbedBuilder().setColor('#faa61a').setTitle("🤝 Draw!")],components:makeRows(board,true)});
      }

      let botIdx;
      if(difficulty==='easy'){const e=board.reduce((a,v,idx)=>v?a:[...a,idx],[]);botIdx=e[Math.floor(Math.random()*e.length)];}
      else botIdx=bestMove([...board]);
      if(botIdx!==undefined&&botIdx!==null)board[botIdx]='O';

      if(checkWin(board,'O')){
        collector.stop('done');
        await saveStats(player.id,player.username,player.displayAvatarURL(),'loss',Date.now()-startTime);
        return btn.update({embeds:[new EmbedBuilder().setColor('#ed4245').setTitle('🤖 Bot Wins!')],components:makeRows(board,true)});
      }
      if(board.every(Boolean)){
        collector.stop('done');
        await saveStats(player.id,player.username,player.displayAvatarURL(),'draw',Date.now()-startTime);
        return btn.update({embeds:[new EmbedBuilder().setColor('#faa61a').setTitle("🤝 Draw!")],components:makeRows(board,true)});
      }
      await btn.update({embeds:[embed()],components:makeRows(board)});
    });

    collector.on('end',(_,reason)=>{ if(reason!=='done') msg.edit({components:makeRows(board,true)}).catch(()=>{}); });
  }
};
