const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'gayrate', aliases: ['gr'], category: 'fun',
  description: 'Fun gay rate meter', usage: '!gayrate [@user]',
  async execute(message) {
    const target = message.mentions.users.first() || message.author;
    const rate = Math.floor(Math.random()*101);
    const bar  = '🟣'.repeat(Math.floor(rate/10))+'⬛'.repeat(10-Math.floor(rate/10));
    await message.reply({ embeds: [new EmbedBuilder().setColor('#ff69b4').setTitle('🌈 Gay Rate')
      .setDescription(`**${target.username}** is **${rate}%** gay!`)
      .addFields({ name:'Meter', value:`${bar} **${rate}%**` }).setThumbnail(target.displayAvatarURL())
      .setFooter({ text:'Just for fun 😄' }).setTimestamp()] });
  }
};
