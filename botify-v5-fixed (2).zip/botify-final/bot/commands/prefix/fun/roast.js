const { EmbedBuilder } = require('discord.js');
const ROASTS = [
  "I'd roast you, but my mom said I can't burn trash.",
  "You're the reason they put instructions on shampoo.",
  "If laughter is the best medicine, your face must be curing diseases.",
  "I'd explain it to you, but I left my crayons at home.",
  "Light travels faster than sound, which is why you seemed bright before you spoke.",
  "You're like a cloud — when you disappear it's a beautiful day.",
  "I'd call you a tool, but tools are actually useful.",
];
module.exports = {
  name: 'roast', aliases: ['burn'], category: 'fun',
  description: 'Roast a member (for fun)', usage: '!roast @user',
  async execute(message, args, client) {
    const target = message.mentions.users.first();
    if (!target) return message.reply('❌ Mention someone to roast!');
    if (target.id === client.user.id) return message.reply("Nice try, but I don't roast myself 😎");
    const roast = ROASTS[Math.floor(Math.random()*ROASTS.length)];
    await message.reply({ embeds: [new EmbedBuilder().setColor('#ff4500').setTitle(`🔥 Roasting ${target.username}`)
      .setDescription(`${target}, **${roast}**`).setFooter({ text:'🤣 Just for fun!' }).setTimestamp()] });
  }
};
