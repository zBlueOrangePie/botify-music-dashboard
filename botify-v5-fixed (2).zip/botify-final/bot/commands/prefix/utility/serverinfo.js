const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'serverinfo', aliases: ['server', 'si'],
  category: 'utility', usage: '!serverinfo', description: 'View server information',
  async execute(message) {
    const g = message.guild;
    await g.members.fetch().catch(() => {});
    const humans = g.members.cache.filter(m => !m.user.bot).size;
    const bots   = g.members.cache.filter(m => m.user.bot).size;
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`📊 ${g.name}`)
      .setThumbnail(g.iconURL({ dynamic: true }))
      .addFields(
        { name: '👑 Owner',    value: `<@${g.ownerId}>`, inline: true },
        { name: '👥 Members',  value: `${humans} humans · ${bots} bots`, inline: true },
        { name: '💬 Channels', value: `${g.channels.cache.size}`, inline: true },
        { name: '🎭 Roles',    value: `${g.roles.cache.size}`, inline: true },
        { name: '📅 Created',  value: `<t:${Math.floor(g.createdTimestamp/1000)}:R>`, inline: true },
        { name: '🌍 Region',   value: g.preferredLocale || 'N/A', inline: true }
      ).setFooter({ text: `ID: ${g.id}` }).setTimestamp()] });
  }
};
