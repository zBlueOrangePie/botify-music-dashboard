const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'userinfo', aliases: ['user', 'ui', 'whois'],
  category: 'utility', usage: '!userinfo [@user]', description: 'View user information',
  async execute(message, args) {
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null) || message.member;
    const user = target.user;
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`👤 ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🆔 User ID',   value: user.id, inline: true },
        { name: '🤖 Bot',       value: user.bot ? 'Yes' : 'No', inline: true },
        { name: '📅 Joined',    value: `<t:${Math.floor(target.joinedTimestamp/1000)}:R>`, inline: true },
        { name: '📅 Created',   value: `<t:${Math.floor(user.createdTimestamp/1000)}:R>`, inline: true },
        { name: '🎭 Top Role',  value: target.roles.highest.toString(), inline: true },
        { name: '🎨 Roles',     value: `${target.roles.cache.size - 1}`, inline: true }
      ).setFooter({ text: `Requested by ${message.author.tag}` }).setTimestamp()] });
  }
};
