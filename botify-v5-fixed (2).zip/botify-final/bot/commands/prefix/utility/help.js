const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'help', aliases: ['h', 'commands'],
  category: 'utility', usage: '!help [category]', description: 'Show all prefix commands',
  async execute(message, args) {
    const filter = args[0]?.toLowerCase();
    const prefix = message.client.prefix || '!';
    const ICONS = { moderation:'🛡️', utility:'🔧', fun:'🎮', music:'🎵', leveling:'📈' };
    const categories = {};
    message.client.prefixCommands.forEach(cmd => {
      const cat = cmd.category || 'utility';
      if (filter && cat !== filter) return;
      if (!categories[cat]) categories[cat] = [];
      if (!categories[cat].some(c => c.name === cmd.name)) categories[cat].push(cmd);
    });
    const total = message.client.prefixCommands.size;
    const embed = new EmbedBuilder().setColor('#5865f2')
      .setTitle(filter ? `${ICONS[filter]||'📦'} ${filter.charAt(0).toUpperCase()+filter.slice(1)} Commands` : '📖 Botify — Prefix Commands')
      .setDescription(`Prefix: \`${prefix}\` · Use \`${prefix}help [category]\` to filter.\n**${total} commands** loaded.`)
      .setThumbnail(message.client.user.displayAvatarURL())
      .setFooter({ text: `Tip: Slash commands work too! Use /help for slash version.` })
      .setTimestamp();
    for (const [cat, cmds] of Object.entries(categories)) {
      embed.addFields({
        name:  `${ICONS[cat]||'📦'} ${cat.charAt(0).toUpperCase()+cat.slice(1)} (${cmds.length})`,
        value: cmds.map(c => `\`${prefix}${c.name}\` — ${c.description}`).join('\n')
      });
    }
    if (!Object.keys(categories).length) return message.reply(`❌ No commands found for category \`${filter}\`.`);
    await message.reply({ embeds: [embed] });
  }
};
