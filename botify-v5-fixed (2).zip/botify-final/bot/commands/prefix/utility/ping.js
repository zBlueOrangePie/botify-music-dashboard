const { EmbedBuilder } = require('discord.js');
module.exports = {
  name: 'ping', category: 'utility', usage: '!ping', description: 'Check bot latency',
  async execute(message) {
    const sent = await message.reply('🏓 Pinging...');
    const latency = sent.createdTimestamp - message.createdTimestamp;
    await sent.edit({ content: null, embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('🏓 Pong!')
      .addFields(
        { name: '⏱️ Bot Latency', value: `${latency}ms`, inline: true },
        { name: '💙 API Latency', value: `${Math.round(message.client.ws.ping)}ms`, inline: true }
      ).setTimestamp()] });
  }
};
