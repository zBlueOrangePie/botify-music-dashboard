const { EmbedBuilder } = require('discord.js');
const Leveling = require('../../../models/Leveling');
module.exports = {
  name: 'leaderboard', aliases: ['lb', 'top'], category: 'leveling',
  description: 'View the XP leaderboard', usage: '!leaderboard',
  async execute(message) {
    let top;
    try { top = await Leveling.find({ guildId: message.guild.id }).sort({ totalXp:-1 }).limit(10).lean(); }
    catch { return message.reply('❌ Could not fetch leaderboard data.'); }
    if (!top.length) return message.reply('❌ No one has earned XP in this server yet!');
    const medals = ['🥇','🥈','🥉'];
    const lines = top.map((d,i) => {
      const medal = medals[i] || `\`${i+1}.\``;
      return `${medal} <@${d.userId}> — Level **${d.level}** · **${d.totalXp.toLocaleString()}** XP`;
    });
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`🏆 ${message.guild.name} Leaderboard`)
      .setDescription(lines.join('\n')).setTimestamp()] });
  }
};
