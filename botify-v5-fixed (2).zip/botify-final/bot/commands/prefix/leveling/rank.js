const { EmbedBuilder } = require('discord.js');
const Leveling = require('../../../models/Leveling');
module.exports = {
  name: 'rank', aliases: ['level', 'xp'], category: 'leveling',
  description: 'View your XP rank', usage: '!rank [@user]',
  async execute(message, args) {
    const target = message.mentions.users.first() || message.author;
    let data;
    try { data = await Leveling.findOne({ guildId: message.guild.id, userId: target.id }); }
    catch { return message.reply('❌ Could not fetch leveling data.'); }
    if (!data) return message.reply(`${target.id===message.author.id?'You have':`**${target.username}** has`} no XP yet. Start chatting!`);
    let rank=1;
    try { rank = await Leveling.countDocuments({ guildId: message.guild.id, totalXp: { $gt: data.totalXp } }) + 1; } catch {}
    const needed = 5*Math.pow(data.level,2)+50*data.level+100;
    const progress = Math.min(20,Math.floor((data.xp/needed)*20));
    const bar = '█'.repeat(progress)+'░'.repeat(20-progress);
    const pct = Math.floor((data.xp/needed)*100);
    await message.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`📊 ${target.username}'s Rank`)
      .setThumbnail(target.displayAvatarURL({ dynamic:true }))
      .addFields(
        { name:'🏆 Rank', value:`**#${rank}**`, inline:true },
        { name:'⭐ Level', value:`**${data.level}**`, inline:true },
        { name:'✨ Total XP', value:`**${data.totalXp.toLocaleString()}**`, inline:true },
        { name:'💬 Messages', value:`**${(data.messages||0).toLocaleString()}**`, inline:true },
        { name:'📈 Progress', value:`\`${bar}\` **${pct}%**\n${data.xp.toLocaleString()} / ${needed.toLocaleString()} XP` }
      ).setFooter({ text:message.guild.name }).setTimestamp()] });
  }
};
