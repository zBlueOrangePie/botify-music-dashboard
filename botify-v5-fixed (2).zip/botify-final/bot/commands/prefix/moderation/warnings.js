const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Warning = require('../../models/Warning');
module.exports = {
  name: 'warnings',
  aliases: ['warns'],
  category: 'moderation',
  usage: '!warnings @user | !warnings clear @user',
  description: 'View or clear warnings for a member',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers))
      return message.reply('❌ You need **Moderate Members** permission.');
    const isClear = args[0]?.toLowerCase() === 'clear';
    const target = isClear ? message.mentions.users.first() : (message.mentions.users.first() || await message.client.users.fetch(args[0]).catch(() => null));
    if (!target) return message.reply(`❌ Mention a user.\n**Usage:** \`${isClear ? '!warnings clear @user' : '!warnings @user'}\``);
    if (isClear) {
      const res = await Warning.deleteMany({ guildId: message.guild.id, userId: target.id }).catch(() => null);
      return message.reply(`✅ Cleared **${res?.deletedCount || 0}** warning(s) for **${target.tag}**.`);
    }
    const warns = await Warning.find({ guildId: message.guild.id, userId: target.id }).sort({ timestamp: -1 }).lean().catch(() => []);
    if (!warns.length) return message.reply(`✅ **${target.tag}** has no warnings.`);
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a').setTitle(`⚠️ Warnings for ${target.tag}`)
      .setDescription(warns.slice(0, 10).map((w, i) =>
        `**#${i+1}** — ${w.reason}\n> <@${w.moderatorId}> · <t:${Math.floor(new Date(w.timestamp).getTime()/1000)}:R>`
      ).join('\n\n'))
      .setFooter({ text: `${warns.length} total warning(s)` }).setTimestamp()
    ]});
  }
};
