const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'role',
  category: 'moderation',
  usage: '!role add @user @role | !role remove @user @role',
  description: 'Add or remove a role from a member',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageRoles))
      return message.reply('❌ You need **Manage Roles** permission.');
    const sub = args[0]?.toLowerCase();
    if (!['add','remove'].includes(sub))
      return message.reply('❌ Usage: `!role add @user @role` or `!role remove @user @role`');
    const target = message.mentions.members.first();
    const role   = message.mentions.roles.first();
    if (!target || !role) return message.reply('❌ Mention a member AND a role.');
    if (role.managed) return message.reply('❌ That role is managed by an integration.');
    if (role.position >= message.guild.members.me.roles.highest.position)
      return message.reply('❌ That role is higher than or equal to my highest role.');
    if (sub === 'add') {
      if (target.roles.cache.has(role.id)) return message.reply(`❌ ${target.user.tag} already has that role.`);
      await target.roles.add(role);
    } else {
      if (!target.roles.cache.has(role.id)) return message.reply(`❌ ${target.user.tag} doesn't have that role.`);
      await target.roles.remove(role);
    }
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor(sub === 'add' ? '#3ba55d' : '#ed4245')
      .setTitle(sub === 'add' ? '✅ Role Added' : '❌ Role Removed')
      .addFields(
        { name: 'User', value: target.user.tag, inline: true },
        { name: 'Role', value: role.name, inline: true }
      ).setTimestamp()
    ]});
  }
};
