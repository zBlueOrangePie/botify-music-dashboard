const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Warning = require('../../models/Warning');
module.exports = {
  name: 'warn',
  category: 'moderation',
  usage: '!warn @user <reason>',
  description: 'Issue a warning to a member',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers))
      return message.reply('❌ You need **Moderate Members** permission.');
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mention a user.\n**Usage:** `!warn @user <reason>`');
    const reason = args.slice(1).join(' ');
    if (!reason) return message.reply('❌ Please provide a reason.\n**Usage:** `!warn @user <reason>`');
    let count = 1;
    try {
      await new Warning({ guildId: message.guild.id, userId: target.id, moderatorId: message.author.id, reason }).save();
      count = await Warning.countDocuments({ guildId: message.guild.id, userId: target.id });
    } catch {}
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a').setTitle('⚠️ Warning Issued')
      .addFields(
        { name: 'User',    value: target.user.tag, inline: true },
        { name: 'Count',   value: `#${count}`, inline: true },
        { name: 'Reason',  value: reason }
      ).setTimestamp()
    ]});
    target.user.send({ embeds: [new EmbedBuilder().setColor('#faa61a')
      .setTitle(`⚠️ You were warned in ${message.guild.name}`)
      .addFields({ name: 'Reason', value: reason }, { name: 'Warning #', value: String(count) }).setTimestamp()]
    }).catch(() => {});
  }
};
