const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'unmute',
  category: 'moderation',
  usage: '!unmute @user [reason]',
  description: 'Remove a timeout from a member',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers))
      return message.reply('❌ You need **Moderate Members** permission.');
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply('❌ Mention a user.\n**Usage:** `!unmute @user [reason]`');
    if (!target.isCommunicationDisabled()) return message.reply('❌ That user is not muted.');
    const reason = args.slice(1).join(' ') || 'No reason provided';
    await target.timeout(null, `[${message.author.tag}] ${reason}`);
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#3ba55d').setTitle('🔊 Member Unmuted')
      .addFields(
        { name: 'User',   value: target.user.tag, inline: true },
        { name: 'Reason', value: reason }
      ).setTimestamp()
    ]});
  }
};
