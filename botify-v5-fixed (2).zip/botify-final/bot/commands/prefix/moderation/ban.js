const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'ban',
  aliases: ['b'],
  category: 'moderation',
  usage: '!ban @user [days] [reason]',
  description: 'Ban a member from the server',
  permissions: [PermissionFlagsBits.BanMembers],
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.BanMembers))
      return message.reply('❌ You need **Ban Members** permission.');
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply('❌ Please mention a user or provide their ID.\n**Usage:** `!ban @user [days] [reason]`');
    if (!target.bannable) return message.reply('❌ I cannot ban this user.');
    if (target.id === message.author.id) return message.reply('❌ You cannot ban yourself.');
    if (target.id === message.guild.ownerId) return message.reply('❌ Cannot ban the server owner.');
    const days = parseInt(args[1]) || 0;
    const reason = args.slice(isNaN(args[1]) ? 1 : 2).join(' ') || 'No reason provided';
    await target.ban({ deleteMessageSeconds: Math.min(7, Math.max(0, days)) * 86400, reason: `[${message.author.tag}] ${reason}` });
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#ed4245').setTitle('🔨 Member Banned')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',     value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Mod',      value: message.author.tag, inline: true },
        { name: 'Reason',   value: reason },
        { name: 'Msgs Del', value: days > 0 ? `Last ${days}d` : 'None', inline: true }
      ).setTimestamp()
    ]});
  }
};
