const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'softban',
  category: 'moderation',
  usage: '!softban @user [days] [reason]',
  description: 'Ban + immediately unban to delete messages',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.BanMembers))
      return message.reply('❌ You need **Ban Members** permission.');
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mention a user.\n**Usage:** `!softban @user [days] [reason]`');
    if (!target.bannable) return message.reply('❌ I cannot ban this user.');
    const days   = parseInt(args[1]) || 1;
    const reason = args.slice(isNaN(args[1]) ? 1 : 2).join(' ') || 'No reason provided';
    const id     = target.id;
    await target.ban({ deleteMessageSeconds: Math.min(7, days) * 86400, reason: `[Softban] [${message.author.tag}] ${reason}` });
    await message.guild.members.unban(id, 'Softban unban').catch(() => {});
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a').setTitle('🧹 Member Softbanned')
      .addFields(
        { name: 'User',   value: target.user.tag, inline: true },
        { name: 'Days',   value: String(days), inline: true },
        { name: 'Reason', value: reason }
      ).setTimestamp()
    ]});
  }
};
