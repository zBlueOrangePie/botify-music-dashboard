const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'unban',
  category: 'moderation',
  usage: '!unban <userID> [reason]',
  description: 'Unban a user by their Discord ID',
  permissions: [PermissionFlagsBits.BanMembers],
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.BanMembers))
      return message.reply('❌ You need **Ban Members** permission.');
    if (!args[0]) return message.reply('❌ Provide a user ID.\n**Usage:** `!unban <userID> [reason]`');
    const userId = args[0];
    const reason = args.slice(1).join(' ') || 'No reason provided';
    if (!/^\d{17,19}$/.test(userId)) return message.reply('❌ Invalid user ID.');
    let banned;
    try { banned = await message.guild.bans.fetch(userId); } catch { return message.reply('❌ That user is not banned.'); }
    await message.guild.members.unban(userId, `[${message.author.tag}] ${reason}`);
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#3ba55d').setTitle('✅ User Unbanned')
      .addFields(
        { name: 'User',   value: `${banned.user.tag}\n\`${userId}\``, inline: true },
        { name: 'Mod',    value: message.author.tag, inline: true },
        { name: 'Reason', value: reason }
      ).setTimestamp()
    ]});
  }
};
