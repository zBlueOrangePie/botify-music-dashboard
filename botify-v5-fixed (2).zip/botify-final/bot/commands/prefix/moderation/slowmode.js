const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'slowmode',
  category: 'moderation',
  usage: '!slowmode <seconds> (0 = off)',
  description: 'Set slowmode delay for this channel',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels))
      return message.reply('❌ You need **Manage Channels** permission.');
    const seconds = parseInt(args[0]);
    if (isNaN(seconds) || seconds < 0 || seconds > 21600)
      return message.reply('❌ Provide a number 0–21600.\n**Usage:** `!slowmode <seconds>`');
    await message.channel.setRateLimitPerUser(seconds);
    const label = seconds === 0 ? 'disabled' : `${seconds}s`;
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2').setTitle('⏱️ Slowmode Updated')
      .setDescription(seconds === 0 ? '🟢 Slowmode disabled.' : `🐢 Slowmode set to **${label}** per message.`)
      .setTimestamp()
    ]});
  }
};
