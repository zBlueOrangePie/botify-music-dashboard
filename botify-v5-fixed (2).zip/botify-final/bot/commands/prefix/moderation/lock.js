const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'lock',
  category: 'moderation',
  usage: '!lock | !lock unlock',
  description: 'Lock or unlock this channel',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageChannels))
      return message.reply('❌ You need **Manage Channels** permission.');
    const unlock = args[0]?.toLowerCase() === 'unlock';
    await message.channel.permissionOverwrites.edit(message.guild.roles.everyone, { SendMessages: unlock ? null : false });
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor(unlock ? '#3ba55d' : '#ed4245')
      .setTitle(unlock ? '🔓 Channel Unlocked' : '🔒 Channel Locked')
      .setDescription(unlock ? 'Everyone can now send messages.' : 'Only moderators can send messages.')
      .setTimestamp()
    ]});
  }
};
