const { PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'purge',
  aliases: ['clear', 'delete'],
  category: 'moderation',
  usage: '!purge <amount> [@user]',
  description: 'Bulk-delete messages (1–100)',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages))
      return message.reply('❌ You need **Manage Messages** permission.');
    const amount = parseInt(args[0]);
    if (!amount || amount < 1 || amount > 100)
      return message.reply('❌ Provide a number between 1 and 100.\n**Usage:** `!purge <amount> [@user]`');
    const filterUser = message.mentions.members.first();
    await message.delete().catch(() => {});
    const messages = await message.channel.messages.fetch({ limit: 100 });
    const now = Date.now();
    let toDelete = messages.filter(m => now - m.createdTimestamp < 14 * 24 * 60 * 60 * 1000);
    if (filterUser) toDelete = toDelete.filter(m => m.author.id === filterUser.id);
    toDelete = [...toDelete.values()].slice(0, amount);
    if (!toDelete.length) return message.channel.send('❌ No deletable messages found.').then(m => setTimeout(() => m.delete().catch(() => {}), 4000));
    const deleted = await message.channel.bulkDelete(toDelete, true).catch(() => null);
    const count = deleted?.size || toDelete.length;
    const notice = await message.channel.send(`✅ Deleted **${count}** message(s)${filterUser ? ` from ${filterUser.user.tag}` : ''}.`);
    setTimeout(() => notice.delete().catch(() => {}), 4000);
  }
};
