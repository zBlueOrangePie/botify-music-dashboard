const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'tempban',
  category: 'moderation',
  usage: '!tempban @user <hours> [reason]',
  description: 'Temporarily ban a member for X hours',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.BanMembers))
      return message.reply('❌ You need **Ban Members** permission.');
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mention a user.\n**Usage:** `!tempban @user <hours> [reason]`');
    const hours = parseInt(args[1]);
    if (!hours || hours < 1) return message.reply('❌ Provide duration in hours.\n**Usage:** `!tempban @user <hours> [reason]`');
    const reason  = args.slice(2).join(' ') || 'No reason provided';
    const friendly = hours >= 24 ? `${Math.floor(hours/24)}d ${hours%24}h` : `${hours}h`;
    const unbanAt  = new Date(Date.now() + hours * 3600000);
    await target.ban({ reason: `[Tempban ${friendly}] [${message.author.tag}] ${reason}` });
    setTimeout(() => message.guild.members.unban(target.id, 'Tempban expired').catch(() => {}), hours * 3600000);
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#ed4245').setTitle('⏳ Member Temp-Banned')
      .addFields(
        { name: 'User',     value: target.user.tag, inline: true },
        { name: 'Duration', value: friendly, inline: true },
        { name: 'Expires',  value: `<t:${Math.floor(unbanAt.getTime()/1000)}:R>`, inline: true },
        { name: 'Reason',   value: reason }
      ).setTimestamp()
    ]});
  }
};
