const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'nick',
  category: 'moderation',
  usage: '!nick @user [new nickname] (blank = reset)',
  description: "Change or reset a member's nickname",
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageNicknames))
      return message.reply('❌ You need **Manage Nicknames** permission.');
    const target = message.mentions.members.first();
    if (!target) return message.reply('❌ Mention a user.\n**Usage:** `!nick @user [nickname]`');
    if (!target.manageable) return message.reply('❌ I cannot change this user\'s nickname.');
    const old = target.nickname || target.user.username;
    const nickname = args.slice(1).join(' ') || null;
    await target.setNickname(nickname);
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2').setTitle('✏️ Nickname Changed')
      .addFields(
        { name: 'User',     value: target.user.tag, inline: true },
        { name: 'Old Nick', value: old, inline: true },
        { name: 'New Nick', value: nickname || '*(reset)*', inline: true }
      ).setTimestamp()
    ]});
  }
};
