const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'announce',
  category: 'moderation',
  usage: '!announce <#channel> <title> | <message>',
  description: 'Send a formatted announcement (use | to split title and body)',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages))
      return message.reply('❌ You need **Manage Messages** permission.');
    const channel = message.mentions.channels.first() || message.channel;
    const text    = args.filter(a => !a.startsWith('<#')).join(' ');
    const parts   = text.split('|');
    const title   = parts[0]?.trim() || 'Announcement';
    const body    = parts[1]?.trim() || parts[0]?.trim() || '...';
    await channel.send({ embeds: [new EmbedBuilder()
      .setColor('#5865f2').setTitle(`📢 ${title}`).setDescription(body)
      .setFooter({ text: `By ${message.author.tag}`, iconURL: message.author.displayAvatarURL() }).setTimestamp()
    ]});
    if (channel.id !== message.channel.id) await message.reply(`✅ Announcement sent to ${channel}.`);
  }
};
