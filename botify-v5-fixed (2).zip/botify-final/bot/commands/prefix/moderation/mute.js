const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'mute',
  aliases: ['timeout'],
  category: 'moderation',
  usage: '!mute @user <minutes> [reason]',
  description: 'Timeout a member for X minutes',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.ModerateMembers))
      return message.reply('❌ You need **Moderate Members** permission.');
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply('❌ Mention a user.\n**Usage:** `!mute @user <minutes> [reason]`');
    if (!target.moderatable) return message.reply('❌ I cannot mute this user.');
    const minutes = parseInt(args[1]);
    if (!minutes || minutes < 1) return message.reply('❌ Provide duration in minutes.\n**Usage:** `!mute @user <minutes> [reason]`');
    const reason = args.slice(2).join(' ') || 'No reason provided';
    await target.timeout(minutes * 60000, `[${message.author.tag}] ${reason}`);
    const friendly = minutes >= 60 ? `${Math.floor(minutes/60)}h ${minutes%60}m` : `${minutes}m`;
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a').setTitle('🔇 Member Muted')
      .addFields(
        { name: 'User',     value: target.user.tag, inline: true },
        { name: 'Duration', value: friendly, inline: true },
        { name: 'Reason',   value: reason }
      ).setTimestamp()
    ]});
    target.user.send({ embeds: [new EmbedBuilder().setColor('#faa61a')
      .setTitle(`🔇 You were muted in ${message.guild.name}`)
      .addFields({ name: 'Duration', value: friendly }, { name: 'Reason', value: reason }).setTimestamp()]
    }).catch(() => {});
  }
};
