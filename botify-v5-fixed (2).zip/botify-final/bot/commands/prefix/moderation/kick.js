const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  name: 'kick',
  category: 'moderation',
  usage: '!kick @user [reason]',
  description: 'Kick a member from the server',
  async execute(message, args) {
    if (!message.member.permissions.has(PermissionFlagsBits.KickMembers))
      return message.reply('❌ You need **Kick Members** permission.');
    const target = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
    if (!target) return message.reply('❌ Mention a user or provide their ID.\n**Usage:** `!kick @user [reason]`');
    if (!target.kickable) return message.reply('❌ I cannot kick this user.');
    if (target.id === message.author.id) return message.reply('❌ You cannot kick yourself.');
    const reason = args.slice(1).join(' ') || 'No reason provided';
    await target.kick(`[${message.author.tag}] ${reason}`);
    await message.reply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a').setTitle('👢 Member Kicked')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',   value: `${target.user.tag}`, inline: true },
        { name: 'Mod',    value: message.author.tag, inline: true },
        { name: 'Reason', value: reason }
      ).setTimestamp()
    ]});
  }
};
