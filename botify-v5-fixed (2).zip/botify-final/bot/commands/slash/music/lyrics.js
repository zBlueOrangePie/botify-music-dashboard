const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('lyrics')
    .setDescription('Fetch lyrics for the current song or a specific song')
    .addStringOption(o => o.setName('song').setDescription('Song name to search (default: current song)')),
  async execute(interaction) {
    await interaction.deferReply();
    const queue   = useQueue(interaction.guild.id);
    const query   = interaction.options.getString('song') || queue?.currentTrack?.title;
    if (!query) return interaction.editReply('❌ No song is playing and no song was provided.');
    try {
      // Use genius API via lyricsSearcher or built-in player lyrics
      const { lyricsExtractor } = require('@discord-player/extractor');
      const genius = lyricsExtractor();
      const result = await genius.search(query);
      if (!result) return interaction.editReply(`❌ No lyrics found for **${query}**.`);
      const lyrics = result.lyrics.length > 3900
        ? result.lyrics.substring(0, 3900) + '...\n*(lyrics truncated)*'
        : result.lyrics;
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#5865f2')
        .setTitle(`🎵 ${result.title}`)
        .setDescription(lyrics)
        .setThumbnail(result.thumbnail)
        .setFooter({ text: `Artist: ${result.artist.name}` })
        .setTimestamp()
      ]});
    } catch {
      // Fallback if extractor doesn't support lyrics
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#faa61a')
        .setTitle(`🎵 Lyrics: ${query}`)
        .setDescription('Lyrics are not available for this track or lyrics search is not configured.\n\nYou can find lyrics at [Genius](https://genius.com).')
        .setTimestamp()
      ]});
    }
  }
};
