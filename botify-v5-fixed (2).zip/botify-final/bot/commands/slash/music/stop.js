const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('stop').setDescription('Stop music and clear the queue'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    queue.delete();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('⏹️ Stopped').setDescription('Music stopped and queue cleared.').setTimestamp()] });
  }
};
