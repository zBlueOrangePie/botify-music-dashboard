const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('queue').setDescription('View the music queue'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    const current = queue.currentTrack;
    const tracks  = queue.tracks.toArray().slice(0, 10);
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('📋 Music Queue')
      .addFields(
        { name: '▶️ Now Playing', value: current ? `[${current.title}](${current.url}) by ${current.author}` : 'Nothing' },
        { name: `📜 Up Next (${tracks.length})`, value: tracks.length ? tracks.map((t,i) => `\`${i+1}.\` ${t.title}`).join('\n') : 'Queue is empty' }
      )
      .setThumbnail(current?.thumbnail)
      .setFooter({ text: `${tracks.length} track(s) in queue` })
      .setTimestamp()
    ]});
  }
};
