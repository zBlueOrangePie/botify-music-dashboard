const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Remove a song from the queue by its position')
    .addIntegerOption(o => o.setName('position').setDescription('Position in queue (use /queue to see positions)').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const pos    = interaction.options.getInteger('position') - 1;
    const tracks = queue.tracks.toArray();
    if (pos < 0 || pos >= tracks.length) return interaction.reply({ content: `❌ Invalid position. Queue has **${tracks.length}** track(s).`, ephemeral: true });
    const removed = tracks[pos];
    queue.node.remove(pos);
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#ed4245')
      .setTitle('🗑️ Track Removed')
      .setDescription(`Removed **${removed.title}** by **${removed.author}** from the queue.`)
      .setTimestamp()
    ]});
  }
};
