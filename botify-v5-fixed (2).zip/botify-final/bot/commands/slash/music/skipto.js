const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('skipto')
    .setDescription('Skip directly to a specific track in the queue')
    .addIntegerOption(o => o.setName('position').setDescription('Position of the track to jump to').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const pos    = interaction.options.getInteger('position') - 1;
    const tracks = queue.tracks.toArray();
    if (pos < 0 || pos >= tracks.length)
      return interaction.reply({ content: `❌ Invalid position. Queue has **${tracks.length}** tracks.`, ephemeral: true });
    const target = tracks[pos];
    // Remove all tracks before the target
    for (let i = 0; i < pos; i++) queue.node.remove(0);
    queue.node.skip();
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('⏭️ Skipped To Track')
      .setDescription(`Now playing **${target.title}** by **${target.author}**`)
      .setThumbnail(target.thumbnail)
      .setTimestamp()
    ]});
  }
};
