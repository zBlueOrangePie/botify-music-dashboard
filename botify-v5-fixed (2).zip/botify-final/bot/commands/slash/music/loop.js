const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue, QueueRepeatMode } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set loop mode for the queue')
    .addStringOption(o => o.setName('mode').setDescription('Loop mode').setRequired(true).addChoices(
      { name: '🚫 Off',       value: 'off' },
      { name: '🔂 Track',     value: 'track' },
      { name: '🔁 Queue',     value: 'queue' },
      { name: '🔃 Autoplay',  value: 'autoplay' }
    )),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const modeMap = {
      off:      QueueRepeatMode.OFF,
      track:    QueueRepeatMode.TRACK,
      queue:    QueueRepeatMode.QUEUE,
      autoplay: QueueRepeatMode.AUTOPLAY,
    };
    const labels = { off: '🚫 Off', track: '🔂 Track', queue: '🔁 Queue', autoplay: '🔃 Autoplay' };
    const mode = interaction.options.getString('mode');
    queue.setRepeatMode(modeMap[mode]);
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('🔁 Loop Mode Updated')
      .setDescription(`Loop mode set to **${labels[mode]}**`)
      .setTimestamp()
    ]});
  }
};
