const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set the music volume')
    .addIntegerOption(o => o.setName('level').setDescription('Volume level (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const level = interaction.options.getInteger('level');
    queue.node.setVolume(level);
    await interaction.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle(`🔊 Volume: ${level}%`).setDescription(`Volume has been set to **${level}%**`).setTimestamp()] });
  }
};
