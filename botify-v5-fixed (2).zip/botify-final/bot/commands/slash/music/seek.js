const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('seek')
    .setDescription('Seek to a position in the current track')
    .addStringOption(o => o.setName('position').setDescription('Time to seek to (e.g. 1:30 or 90)').setRequired(true)),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const input = interaction.options.getString('position');
    let ms;
    if (input.includes(':')) {
      const parts = input.split(':').map(Number);
      if (parts.length === 2) ms = (parts[0] * 60 + parts[1]) * 1000;
      else if (parts.length === 3) ms = (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000;
    } else {
      ms = parseInt(input) * 1000;
    }
    if (isNaN(ms) || ms < 0) return interaction.reply({ content: '❌ Invalid time format. Use `1:30` or `90` (seconds).', ephemeral: true });
    try {
      await queue.node.seek(ms);
      const label = input.includes(':') ? input : `${Math.floor(ms / 60000)}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')}`;
      await interaction.reply({ embeds: [new EmbedBuilder()
        .setColor('#5865f2')
        .setTitle('⏩ Seeked')
        .setDescription(`Jumped to **${label}** in **${queue.currentTrack.title}**`)
        .setTimestamp()
      ]});
    } catch {
      await interaction.reply({ content: '❌ Could not seek. The track may not support seeking.', ephemeral: true });
    }
  }
};
