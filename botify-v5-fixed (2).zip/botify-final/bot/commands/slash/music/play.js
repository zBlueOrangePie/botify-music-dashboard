const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song or playlist from YouTube/Spotify/SoundCloud')
    .addStringOption(o => o.setName('query').setDescription('Song name or URL').setRequired(true)),
  async execute(interaction) {
    await interaction.deferReply();
    if (!interaction.member.voice.channel)
      return interaction.editReply('❌ You must be in a voice channel to play music!');
    const perms = interaction.member.voice.channel.permissionsFor(interaction.client.user);
    if (!perms.has('Connect') || !perms.has('Speak'))
      return interaction.editReply('❌ I need **Connect** and **Speak** permissions in your voice channel!');
    const player = interaction.client.player;
    if (!player)
      return interaction.editReply('❌ Music player is not initialized. Contact an administrator.');
    try {
      const query  = interaction.options.getString('query');
      const result = await player.search(query, { requestedBy: interaction.user });
      if (!result?.tracks?.length)
        return interaction.editReply('❌ No results found for that query!');
      const { track } = await player.play(interaction.member.voice.channel, result, {
        nodeOptions: {
          metadata: { channel: interaction.channel, requestedBy: interaction.user },
          volume: 80, selfDeaf: true,
          leaveOnEmpty: true, leaveOnEmptyCooldown: 60000,
          leaveOnEnd: true, leaveOnEndCooldown: 30000
        }
      });
      const embed = new EmbedBuilder()
        .setColor('#3ba55d')
        .setTitle(result.playlist ? '📋 Playlist Added to Queue' : '🎵 Added to Queue')
        .setDescription(result.playlist ? `**${result.playlist.title}** — ${result.tracks.length} tracks` : `**${track.title}** by ${track.author}`)
        .setThumbnail(track.thumbnail)
        .addFields({ name: '⏱️ Duration', value: track.duration || 'Live', inline: true })
        .setFooter({ text: `Requested by ${interaction.user.tag}` });
      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[Music Play]', err);
      await interaction.editReply(`❌ Error: ${err.message}`);
    }
  }
};
