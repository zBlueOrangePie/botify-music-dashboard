const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('search')
    .setDescription('Search for a song and pick from results')
    .addStringOption(o => o.setName('query').setDescription('Song name to search for').setRequired(true)),
  async execute(interaction) {
    await interaction.deferReply();
    if (!interaction.member.voice.channel)
      return interaction.editReply('❌ You must be in a voice channel!');
    const player = interaction.client.player;
    if (!player) return interaction.editReply('❌ Music player not initialized.');
    const query   = interaction.options.getString('query');
    const results = await player.search(query, { requestedBy: interaction.user }).catch(() => null);
    if (!results?.tracks?.length)
      return interaction.editReply(`❌ No results found for **${query}**.`);
    const tracks = results.tracks.slice(0, 10);
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`search_select_${interaction.user.id}`)
      .setPlaceholder('Choose a song to play...')
      .addOptions(tracks.map((t, i) => ({
        label: t.title.slice(0, 100),
        description: `${t.author} · ${t.duration}`.slice(0, 100),
        value: String(i),
        emoji: '🎵',
      })));
    const embed = new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle(`🔍 Search: ${query}`)
      .setDescription(tracks.map((t, i) => `\`${i + 1}.\` **${t.title}** by ${t.author} · \`${t.duration}\``).join('\n'))
      .setFooter({ text: 'Select a song below — expires in 30s' })
      .setTimestamp();
    const msg = await interaction.editReply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] });
    const collector = msg.createMessageComponentCollector({ time: 30000 });
    collector.on('collect', async sel => {
      if (!sel.customId.startsWith('search_select_')) return;
      if (sel.user.id !== interaction.user.id) return sel.reply({ content: '❌ This is not your search!', ephemeral: true });
      const idx   = parseInt(sel.values[0]);
      const track = tracks[idx];
      try {
        await player.play(interaction.member.voice.channel, track, {
          nodeOptions: { metadata: { channel: interaction.channel, requestedBy: interaction.user }, volume: 80, selfDeaf: true }
        });
        await sel.update({ embeds: [new EmbedBuilder()
          .setColor('#3ba55d').setTitle('🎵 Added to Queue')
          .setDescription(`**${track.title}** by **${track.author}**`)
          .setThumbnail(track.thumbnail)
          .addFields({ name: '⏱️ Duration', value: track.duration || 'Live', inline: true })
          .setTimestamp()
        ], components: [] });
      } catch (err) {
        await sel.update({ content: `❌ Could not play track: ${err.message}`, components: [] });
      }
      collector.stop();
    });
    collector.on('end', (_, reason) => {
      if (reason === 'time') interaction.editReply({ components: [] }).catch(() => {});
    });
  }
};
