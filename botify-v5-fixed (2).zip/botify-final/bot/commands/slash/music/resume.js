const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('resume').setDescription('Resume paused music'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing in queue!', ephemeral: true });
    if (!queue.node.isPaused()) return interaction.reply({ content: 'ℹ️ Music is not paused.', ephemeral: true });
    queue.node.resume();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor('#3ba55d').setTitle('▶️ Resumed').setDescription('Music resumed!').setTimestamp()] });
  }
};
