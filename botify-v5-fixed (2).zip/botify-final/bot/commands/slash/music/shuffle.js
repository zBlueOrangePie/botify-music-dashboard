const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('shuffle').setDescription('Shuffle the music queue'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    if (queue.tracks.size < 2) return interaction.reply({ content: '❌ Need at least 2 songs in queue to shuffle.', ephemeral: true });
    queue.tracks.shuffle();
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('🔀 Queue Shuffled')
      .setDescription(`Shuffled **${queue.tracks.size}** tracks in the queue!`)
      .setTimestamp()
    ]});
  }
};
