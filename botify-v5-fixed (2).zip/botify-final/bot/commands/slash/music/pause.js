const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('pause').setDescription('Pause or resume the current song'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const paused = queue.node.isPaused();
    paused ? queue.node.resume() : queue.node.pause();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle(paused ? '▶️ Resumed' : '⏸️ Paused').setDescription(paused ? 'Music has been resumed.' : 'Music has been paused.').setTimestamp()] });
  }
};
