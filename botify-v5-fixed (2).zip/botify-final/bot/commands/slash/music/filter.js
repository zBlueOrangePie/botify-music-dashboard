const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
const FILTERS = {
  bassboost:   { label: '🔊 Bass Boost',    eq: { bass: 3 } },
  nightcore:   { label: '🌙 Nightcore',     eq: { tempo: 1.3, pitch: 1.3 } },
  vaporwave:   { label: '🌊 Vaporwave',     eq: { tempo: 0.8, pitch: 0.8 } },
  '8d':        { label: '🎧 8D Audio',      eq: {} },
  karaoke:     { label: '🎤 Karaoke',       eq: {} },
  vibrato:     { label: '〰️ Vibrato',       eq: {} },
  tremolo:     { label: '🔉 Tremolo',       eq: {} },
};
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('filter')
    .setDescription('Apply an audio filter to the music')
    .addStringOption(o => o.setName('effect').setDescription('Filter to apply').setRequired(true).addChoices(
      { name: '🔊 Bass Boost',   value: 'bassboost' },
      { name: '🌙 Nightcore',    value: 'nightcore' },
      { name: '🌊 Vaporwave',    value: 'vaporwave' },
      { name: '🎧 8D Audio',     value: '8d' },
      { name: '🎤 Karaoke',      value: 'karaoke' },
      { name: '〰️ Vibrato',     value: 'vibrato' },
      { name: '🔉 Tremolo',      value: 'tremolo' },
      { name: '❌ Clear Filters', value: 'clear' },
    )),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const effect = interaction.options.getString('effect');
    try {
      if (effect === 'clear') {
        await queue.filters.ffmpeg.setInputAudioFilters([]);
        return interaction.reply({ embeds: [new EmbedBuilder()
          .setColor('#5865f2').setTitle('🎵 Filters Cleared')
          .setDescription('All audio filters have been removed.').setTimestamp()
        ]});
      }
      const filterMap = {
        bassboost: 'bass=g=15',
        nightcore: 'asetrate=44100*1.3,aresample=44100',
        vaporwave: 'asetrate=44100*0.8,aresample=44100',
        '8d':      'apulsator=hz=0.08',
        karaoke:   'pan=stereo|c0=c0|c1=c1,volume=2,stereotools=mlev=0.1',
        vibrato:   'vibrato=f=7:d=0.5',
        tremolo:   'tremolo=f=5:d=0.5',
      };
      await queue.filters.ffmpeg.setInputAudioFilters([filterMap[effect]]);
      const info = FILTERS[effect];
      await interaction.reply({ embeds: [new EmbedBuilder()
        .setColor('#5865f2').setTitle(`${info.label} Applied`)
        .setDescription(`Audio filter **${info.label}** is now active.`)
        .setFooter({ text: 'Use /filter clear to remove all filters' })
        .setTimestamp()
      ]});
    } catch {
      await interaction.reply({ content: '❌ Could not apply filter. This track may not support audio filters.', ephemeral: true });
    }
  }
};
