const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('skip').setDescription('Skip the current song'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const track = queue.currentTrack;
    queue.node.skip();
    await interaction.reply({ embeds: [new EmbedBuilder().setColor('#5865f2').setTitle('⏭️ Skipped').setDescription(`Skipped **${track?.title || 'current track'}**`).setTimestamp()] });
  }
};
