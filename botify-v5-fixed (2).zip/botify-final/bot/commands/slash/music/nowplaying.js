const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder().setName('nowplaying').setDescription('Show the currently playing song'),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    const t = queue.currentTrack;
    if (!t) return interaction.reply({ content: '❌ No track info available.', ephemeral: true });
    const progress = queue.node.getTimestamp();
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('🎵 Now Playing')
      .setDescription(`**[${t.title}](${t.url})**`)
      .setThumbnail(t.thumbnail)
      .addFields(
        { name: '🎤 Artist', value: t.author || 'Unknown', inline: true },
        { name: '⏱️ Duration', value: t.duration || 'Live', inline: true },
        { name: '📍 Progress', value: progress ? `${progress.current.label} / ${progress.total.label}` : '—', inline: true },
        { name: '👤 Requested By', value: t.requestedBy?.tag || 'Unknown', inline: true }
      )
      .setTimestamp()
    ]});
  }
};
