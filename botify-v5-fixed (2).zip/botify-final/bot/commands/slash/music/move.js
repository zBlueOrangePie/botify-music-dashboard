const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('move')
    .setDescription('Move a track from one position to another in the queue')
    .addIntegerOption(o => o.setName('from').setDescription('Current position of the track').setRequired(true).setMinValue(1))
    .addIntegerOption(o => o.setName('to').setDescription('New position for the track').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const queue = useQueue(interaction.guild.id);
    if (!queue?.isPlaying()) return interaction.reply({ content: '❌ Nothing is playing!', ephemeral: true });
    if (!interaction.member.voice.channel) return interaction.reply({ content: '❌ Join a voice channel first!', ephemeral: true });
    const from   = interaction.options.getInteger('from') - 1;
    const to     = interaction.options.getInteger('to') - 1;
    const tracks = queue.tracks.toArray();
    if (from >= tracks.length || from < 0) return interaction.reply({ content: `❌ Invalid "from" position. Queue has **${tracks.length}** tracks.`, ephemeral: true });
    if (to >= tracks.length || to < 0) return interaction.reply({ content: `❌ Invalid "to" position. Queue has **${tracks.length}** tracks.`, ephemeral: true });
    if (from === to) return interaction.reply({ content: '❌ "From" and "to" positions are the same.', ephemeral: true });
    const [moved] = tracks.splice(from, 1);
    tracks.splice(to, 0, moved);
    // Rebuild the queue
    queue.tracks.clear();
    for (const t of tracks) queue.tracks.push(t);
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('↕️ Track Moved')
      .setDescription(`**${moved.title}** moved from position **${from + 1}** to **${to + 1}**.`)
      .setTimestamp()
    ]});
  }
};
