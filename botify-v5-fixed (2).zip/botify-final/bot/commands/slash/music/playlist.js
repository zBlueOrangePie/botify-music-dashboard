const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'music',
  data: new SlashCommandBuilder()
    .setName('playlist')
    .setDescription('Play a public playlist by URL')
    .addStringOption(o => o.setName('url').setDescription('Playlist URL (YouTube, Spotify, SoundCloud)').setRequired(true)),
  async execute(interaction) {
    await interaction.deferReply();
    if (!interaction.member.voice.channel)
      return interaction.editReply('❌ You must be in a voice channel!');
    const player = interaction.client.player;
    if (!player) return interaction.editReply('❌ Music player not initialized.');
    const url = interaction.options.getString('url');
    try {
      const result = await player.search(url, { requestedBy: interaction.user });
      if (!result?.tracks?.length)
        return interaction.editReply('❌ No tracks found at that URL. Make sure the playlist is public.');
      if (!result.playlist)
        return interaction.editReply('❌ That doesn\'t appear to be a playlist URL. Try `/play` for individual songs.');
      const { track: firstTrack } = await player.play(interaction.member.voice.channel, result, {
        nodeOptions: {
          metadata: { channel: interaction.channel, requestedBy: interaction.user },
          volume: 80, selfDeaf: true,
          leaveOnEmpty: true, leaveOnEnd: true,
        }
      });
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#3ba55d')
        .setTitle('📋 Playlist Loaded')
        .setDescription(`**${result.playlist.title}**`)
        .setThumbnail(firstTrack.thumbnail)
        .addFields(
          { name: '🎵 Tracks',    value: String(result.tracks.length), inline: true },
          { name: '▶️ Starting', value: firstTrack.title, inline: true }
        )
        .setFooter({ text: `Requested by ${interaction.user.tag}` })
        .setTimestamp()
      ]});
    } catch (err) {
      await interaction.editReply(`❌ Failed to load playlist: ${err.message}`);
    }
  }
};
