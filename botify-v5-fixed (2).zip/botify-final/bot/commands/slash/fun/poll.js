const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll with up to 4 options')
    .addStringOption(o => o.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(o => o.setName('option1').setDescription('First option').setRequired(true))
    .addStringOption(o => o.setName('option2').setDescription('Second option').setRequired(true))
    .addStringOption(o => o.setName('option3').setDescription('Third option (optional)'))
    .addStringOption(o => o.setName('option4').setDescription('Fourth option (optional)')),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const options  = [
      interaction.options.getString('option1'),
      interaction.options.getString('option2'),
      interaction.options.getString('option3'),
      interaction.options.getString('option4'),
    ].filter(Boolean);
    const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
    const embed = new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle(`📊 ${question}`)
      .setDescription(options.map((opt, i) => `${emojis[i]} **${opt}**`).join('\n\n'))
      .setFooter({ text: `Poll by ${interaction.user.tag} · React to vote!` })
      .setTimestamp();
    const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
    for (let i = 0; i < options.length; i++) {
      await msg.react(emojis[i]).catch(() => {});
    }
  }
};
