const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const ANSWERS = [
  { text: 'It is certain.', type: 'positive' },
  { text: 'Without a doubt.', type: 'positive' },
  { text: 'Yes, definitely!', type: 'positive' },
  { text: 'Most likely.', type: 'positive' },
  { text: 'Yes.', type: 'positive' },
  { text: 'Signs point to yes.', type: 'positive' },
  { text: 'Reply hazy, try again.', type: 'neutral' },
  { text: 'Ask again later.', type: 'neutral' },
  { text: "I can't predict that now.", type: 'neutral' },
  { text: "Don't count on it.", type: 'negative' },
  { text: 'Very doubtful.', type: 'negative' },
  { text: 'My sources say no.', type: 'negative' },
  { text: 'Outlook not so good.', type: 'negative' },
  { text: 'No.', type: 'negative' },
];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Ask the magic 8-ball a yes/no question')
    .addStringOption(o => o.setName('question').setDescription('Your yes/no question').setRequired(true)),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const answer   = ANSWERS[Math.floor(Math.random() * ANSWERS.length)];
    const colors   = { positive: '#3ba55d', neutral: '#faa61a', negative: '#ed4245' };
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(colors[answer.type])
        .setTitle('🎱 Magic 8-Ball')
        .addFields(
          { name: '❓ Question', value: question },
          { name: '🎱 Answer', value: `**${answer.text}**` }
        )
        .setFooter({ text: `Asked by ${interaction.user.tag}` })
        .setTimestamp()
      ]
    });
  }
};
