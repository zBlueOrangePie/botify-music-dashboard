const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('gayrate')
    .setDescription('Rate how gay someone is 🌈 (just for fun!)')
    .addUserOption(o => o.setName('user').setDescription('User to rate (default: you)')),
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const rate   = Math.floor(Math.random() * 101);
    const bar    = '🟣'.repeat(Math.floor(rate / 10)) + '⬛'.repeat(10 - Math.floor(rate / 10));
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#ff69b4')
      .setTitle('🌈 Gay Rate')
      .setDescription(`**${target.username}** is **${rate}%** gay!`)
      .addFields({ name: 'Meter', value: `${bar} **${rate}%**` })
      .setThumbnail(target.displayAvatarURL())
      .setFooter({ text: 'This is just for fun and not accurate at all 😄' })
      .setTimestamp()
    ]});
  }
};
