const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const https = require('https');
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Botify/5.0' } }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch { reject(new Error('Parse error')); } });
    }).on('error', reject);
  });
}
const SUBREDDITS = ['memes', 'dankmemes', 'me_irl', 'wholesomememes', 'programmerhumor'];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('meme')
    .setDescription('Get a random meme from Reddit')
    .addStringOption(o => o.setName('category').setDescription('Meme category').addChoices(
      { name: '😂 Memes',             value: 'memes' },
      { name: '🔥 Dank Memes',        value: 'dankmemes' },
      { name: '🪞 Me IRL',            value: 'me_irl' },
      { name: '🤗 Wholesome',         value: 'wholesomememes' },
      { name: '💻 Programmer Humor',  value: 'programmerhumor' },
    )),
  async execute(interaction) {
    await interaction.deferReply();
    const sub = interaction.options.getString('category') || SUBREDDITS[Math.floor(Math.random() * SUBREDDITS.length)];
    try {
      const data = await fetchJson(`https://www.reddit.com/r/${sub}/random.json?limit=1`);
      const post = data?.[0]?.data?.children?.[0]?.data;
      if (!post || post.over_18) {
        return interaction.editReply('❌ Could not fetch a meme right now. Try again!');
      }
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#ff4500')
        .setTitle(post.title.length > 250 ? post.title.substring(0, 247) + '...' : post.title)
        .setURL(`https://reddit.com${post.permalink}`)
        .setImage(post.url)
        .setFooter({ text: `👍 ${post.ups.toLocaleString()} upvotes · r/${sub}` })
        .setTimestamp()
      ]});
    } catch {
      await interaction.editReply('❌ Could not reach Reddit right now. Try again in a moment.');
    }
  }
};
