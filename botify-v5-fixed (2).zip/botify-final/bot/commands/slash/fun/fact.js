const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const https = require('https');
const FALLBACK_FACTS = [
  "A group of flamingos is called a flamboyance.",
  "Honey never expires — archaeologists have found 3000-year-old honey in Egyptian tombs that was still edible.",
  "Octopuses have three hearts and blue blood.",
  "A day on Venus is longer than a year on Venus.",
  "Cleopatra lived closer in time to the Moon landing than to the construction of the Great Pyramid.",
  "The Eiffel Tower can be 15cm taller in summer due to thermal expansion.",
  "Wombat poop is cube-shaped — the only animal known to produce cube-shaped feces.",
  "There are more possible iterations of a game of chess than there are atoms in the known universe.",
  "Bananas are technically berries, but strawberries are not.",
  "A bolt of lightning is five times hotter than the surface of the sun.",
];
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Botify/5.0' } }, res => {
      let d = ''; res.on('data', c => d += c);
      res.on('end', () => { try { resolve(JSON.parse(d)); } catch { reject(); } });
    }).on('error', reject);
  });
}
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('fact')
    .setDescription('Get a random interesting fact'),
  async execute(interaction) {
    await interaction.deferReply();
    try {
      const data = await fetchJson('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en');
      const fact = data?.text || FALLBACK_FACTS[Math.floor(Math.random() * FALLBACK_FACTS.length)];
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#00d9b0')
        .setTitle('🤓 Random Fact')
        .setDescription(`**${fact}**`)
        .setFooter({ text: 'The more you know! 🌟' })
        .setTimestamp()
      ]});
    } catch {
      const fact = FALLBACK_FACTS[Math.floor(Math.random() * FALLBACK_FACTS.length)];
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#00d9b0')
        .setTitle('🤓 Random Fact')
        .setDescription(`**${fact}**`)
        .setTimestamp()
      ]});
    }
  }
};
