const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Make the bot say something (Mods only)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(o => o.setName('message').setDescription('Message to send').setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Channel to send in (default: current)')),
  async execute(interaction) {
    const text    = interaction.options.getString('message');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    await channel.send(text).catch(() => {});
    await interaction.reply({ content: `✅ Message sent to ${channel}.`, ephemeral: true });
  }
};
