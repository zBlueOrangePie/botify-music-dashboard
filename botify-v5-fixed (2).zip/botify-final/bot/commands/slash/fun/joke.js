const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const JOKES = [
  { setup: "Why don't scientists trust atoms?",                         punchline: "Because they make up everything!" },
  { setup: "Why did the JavaScript developer go broke?",               punchline: "Because he used up all his cache!" },
  { setup: "Why do programmers prefer dark mode?",                     punchline: "Because light attracts bugs!" },
  { setup: "A SQL query walks into a bar, walks up to two tables...",  punchline: "...and asks: 'Can I join you?'" },
  { setup: "Why was the JavaScript developer sad?",                    punchline: "Because he didn't Node how to Express himself!" },
  { setup: "Why did the developer go broke?",                          punchline: "Because he kept losing interest!" },
  { setup: "What do you call a sleeping dinosaur?",                    punchline: "A dino-snore!" },
  { setup: "Why can't you trust an atom?",                             punchline: "They make up literally everything." },
  { setup: "I told my wife she was drawing her eyebrows too high.",    punchline: "She looked surprised." },
  { setup: "Why did the scarecrow win an award?",                      punchline: "Because he was outstanding in his field!" },
  { setup: "What did the ocean say to the beach?",                     punchline: "Nothing, it just waved." },
  { setup: "Why did the bicycle fall over?",                           punchline: "Because it was two-tired!" },
  { setup: "What do you call cheese that isn't yours?",                punchline: "Nacho cheese!" },
  { setup: "Why don't eggs tell jokes?",                               punchline: "They'd crack each other up." },
  { setup: "I used to hate facial hair...",                            punchline: "...but then it grew on me." },
];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('joke')
    .setDescription('Get a random joke'),
  async execute(interaction) {
    const joke = JOKES[Math.floor(Math.random() * JOKES.length)];
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a')
      .setTitle('😂 Random Joke')
      .addFields(
        { name: '❓ Setup',    value: joke.setup },
        { name: '💬 Punchline', value: `||${joke.punchline}||` }
      )
      .setFooter({ text: 'Click the spoiler to reveal the punchline!' })
      .setTimestamp()
    ]});
  }
};
