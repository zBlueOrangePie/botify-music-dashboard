const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const TicTacToe = require('../../../models/TicTacToe');

function makeBoard() { return Array(9).fill(null); }

function makeRows(board, disabled) {
  const rows = [];
  for (let r = 0; r < 3; r++) {
    rows.push(new ActionRowBuilder().addComponents(
      [0,1,2].map(c => {
        const i = r * 3 + c;
        return new ButtonBuilder()
          .setCustomId(`ttt_${i}`)
          .setLabel(board[i] === 'X' ? '❌' : board[i] === 'O' ? '⭕' : '⬜')
          .setStyle(board[i] === 'X' ? ButtonStyle.Danger : board[i] === 'O' ? ButtonStyle.Primary : ButtonStyle.Secondary)
          .setDisabled(disabled || board[i] !== null);
      })
    ));
  }
  return rows;
}

function checkWin(b, p) {
  return [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].some(w => w.every(i => b[i] === p));
}

function bestMove(b) {
  for (const p of ['O','X']) {
    for (let i = 0; i < 9; i++) {
      if (!b[i]) { b[i] = p; if (checkWin(b, p)) { b[i] = null; if (p === 'O') return i; else break; } b[i] = null; }
    }
  }
  if (!b[4]) return 4;
  const corners = [0,2,6,8].filter(i => !b[i]);
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  const empty = b.reduce((a, v, i) => v ? a : [...a, i], []);
  return empty[Math.floor(Math.random() * empty.length)];
}

async function saveStats(userId, username, avatar, result, durationMs) {
  try {
    let record = await TicTacToe.findOne({ userId });
    if (!record) record = new TicTacToe({ userId });
    record.username = username;
    record.avatar   = avatar;
    record.totalGames++;
    record.totalTime += durationMs;
    record.lastPlayed = new Date();
    if (result === 'win') {
      record.wins++;
      if (record.fastestWin === null || durationMs < record.fastestWin) record.fastestWin = durationMs;
    } else if (result === 'loss') {
      record.losses++;
    } else {
      record.draws++;
    }
    await record.save();
  } catch {}
}

module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('tictactoe')
    .setDescription('Play Tic-Tac-Toe against the bot! Your stats are tracked.')
    .addStringOption(o => o.setName('difficulty').setDescription('Bot difficulty').addChoices(
      { name: '🟢 Easy', value: 'easy' },
      { name: '🔴 Hard', value: 'hard' },
    )),

  async execute(interaction) {
    const difficulty = interaction.options.getString('difficulty') || 'hard';
    const board  = makeBoard();
    const player = interaction.user;
    const startTime = Date.now();

    const embed = () => new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('❌ Tic-Tac-Toe')
      .setDescription(`You are ❌ · Bot is ⭕\n**Your turn!**`)
      .setFooter({ text: `Difficulty: ${difficulty} · vs ${player.username}` });

    const msg = await interaction.reply({ embeds: [embed()], components: makeRows(board), fetchReply: true });
    const collector = msg.createMessageComponentCollector({ time: 120000 });

    collector.on('collect', async btn => {
      if (btn.user.id !== player.id)
        return btn.reply({ content: '❌ This is not your game!', ephemeral: true });

      const i = parseInt(btn.customId.replace('ttt_', ''));
      if (board[i]) return btn.reply({ content: '❌ Already taken!', ephemeral: true });

      board[i] = 'X';
      const duration = Date.now() - startTime;

      if (checkWin(board, 'X')) {
        collector.stop('done');
        await saveStats(player.id, player.username, player.displayAvatarURL(), 'win', duration);
        const ms = duration; const s = Math.floor(ms/1000); const timeStr = s < 60 ? `${s}s` : `${Math.floor(s/60)}m ${s%60}s`;
        return btn.update({ embeds: [new EmbedBuilder().setColor('#3ba55d').setTitle('🎉 You Win!')
          .setDescription(`You beat the bot in **${timeStr}**! That's a new record track.`)
          .addFields({ name: '⏱️ Game Duration', value: timeStr, inline: true },
                     { name: '🎮 Difficulty',    value: difficulty, inline: true })], components: makeRows(board, true) });
      }
      if (board.every(Boolean)) {
        collector.stop('done');
        await saveStats(player.id, player.username, player.displayAvatarURL(), 'draw', duration);
        return btn.update({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle("🤝 Draw!")], components: makeRows(board, true) });
      }

      // Bot move
      let botIdx;
      if (difficulty === 'easy') {
        const empty = board.reduce((a, v, idx) => v ? a : [...a, idx], []);
        botIdx = empty[Math.floor(Math.random() * empty.length)];
      } else {
        botIdx = bestMove([...board]);
      }
      if (botIdx !== undefined && botIdx !== null) board[botIdx] = 'O';

      if (checkWin(board, 'O')) {
        collector.stop('done');
        await saveStats(player.id, player.username, player.displayAvatarURL(), 'loss', Date.now() - startTime);
        return btn.update({ embeds: [new EmbedBuilder().setColor('#ed4245').setTitle('🤖 Bot Wins!')
          .setDescription("Better luck next time!")], components: makeRows(board, true) });
      }
      if (board.every(Boolean)) {
        collector.stop('done');
        await saveStats(player.id, player.username, player.displayAvatarURL(), 'draw', Date.now() - startTime);
        return btn.update({ embeds: [new EmbedBuilder().setColor('#faa61a').setTitle("🤝 Draw!")], components: makeRows(board, true) });
      }

      await btn.update({ embeds: [embed()], components: makeRows(board) });
    });

    collector.on('end', (_, reason) => {
      if (reason !== 'done') interaction.editReply({ components: makeRows(board, true) }).catch(() => {});
    });
  }
};
