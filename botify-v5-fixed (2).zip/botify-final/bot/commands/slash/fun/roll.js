const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('roll')
    .setDescription('Roll a dice')
    .addIntegerOption(o => o.setName('sides').setDescription('Number of sides (default: 6)').setMinValue(2).setMaxValue(1000))
    .addIntegerOption(o => o.setName('count').setDescription('How many dice to roll (default: 1)').setMinValue(1).setMaxValue(10)),
  async execute(interaction) {
    const sides = interaction.options.getInteger('sides') || 6;
    const count = interaction.options.getInteger('count') || 1;
    const rolls = Array.from({ length: count }, () => Math.ceil(Math.random() * sides));
    const total = rolls.reduce((a, b) => a + b, 0);
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#5865f2')
        .setTitle(`🎲 Dice Roll (d${sides})`)
        .addFields(
          { name: '🎲 Rolls', value: rolls.map(r => `\`${r}\``).join(' + '), inline: true },
          { name: '💯 Total', value: `**${total}**`, inline: true }
        )
        .setTimestamp()
      ]
    });
  }
};
