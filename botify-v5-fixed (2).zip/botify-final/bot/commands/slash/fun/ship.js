const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('ship')
    .setDescription('Ship two users together ❤️')
    .addUserOption(o => o.setName('user1').setDescription('First user').setRequired(true))
    .addUserOption(o => o.setName('user2').setDescription('Second user').setRequired(true)),
  async execute(interaction) {
    const u1   = interaction.options.getUser('user1');
    const u2   = interaction.options.getUser('user2');
    const rate  = Math.floor(Math.random() * 101);
    const bar   = '❤️'.repeat(Math.floor(rate / 10)) + '🖤'.repeat(10 - Math.floor(rate / 10));
    const name  = u1.username.slice(0, Math.ceil(u1.username.length / 2)) + u2.username.slice(Math.floor(u2.username.length / 2));
    const msg = rate >= 80 ? '💞 A perfect match!' : rate >= 50 ? '💕 There's potential!' : rate >= 25 ? '💛 Just friends... for now.' : '💔 Not meant to be.';
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#ff69b4')
      .setTitle('💘 Shipping!')
      .setDescription(`**${u1.username}** + **${u2.username}** = **${name}**`)
      .addFields(
        { name: '❤️ Compatibility', value: `${bar} **${rate}%**` },
        { name: '💬 Verdict',       value: msg }
      )
      .setTimestamp()
    ]});
  }
};
