const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const ROASTS = [
  "I'd roast you, but my mom said I can't burn trash.",
  "You're the reason they put instructions on shampoo.",
  "If laughter is the best medicine, your face must be curing diseases.",
  "I'd explain it to you, but I left my crayons at home.",
  "You're proof that even evolution can have a bad day.",
  "You're not stupid; you just have bad luck thinking.",
  "Your wifi password must be 1234 because that's how predictable you are.",
  "Scientists say the universe is made of protons, neutrons, and electrons. They forgot morons.",
  "I'm not saying you're dumb, but your GPS recalculates to avoid your brain.",
  "You're like a participation trophy — technically acknowledged, but nobody is really proud.",
  "If ignorance is bliss, you must be the happiest person alive.",
  "Light travels faster than sound, which is why you seemed bright before you spoke.",
  "You're like a cloud — when you disappear it's a beautiful day.",
  "Don't worry about what people think of you. They rarely do.",
  "I'd call you a tool, but tools are actually useful.",
];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('roast')
    .setDescription('Roast a member (all in good fun! 🔥)')
    .addUserOption(o => o.setName('user').setDescription('Who to roast').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    if (target.id === interaction.client.user.id)
      return interaction.reply({ content: "Nice try, but I don't roast myself 😎", ephemeral: true });
    const roast = ROASTS[Math.floor(Math.random() * ROASTS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#ff4500')
      .setTitle(`🔥 Roasting ${target.username}`)
      .setDescription(`${target}, **${roast}**`)
      .setThumbnail(target.displayAvatarURL())
      .setFooter({ text: '🤣 This is just for fun!' })
      .setTimestamp()
    ]});
  }
};
