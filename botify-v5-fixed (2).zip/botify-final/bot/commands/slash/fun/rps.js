const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const CHOICES = ['rock', 'paper', 'scissors'];
const EMOJIS  = { rock: '🪨', paper: '📄', scissors: '✂️' };
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('rps')
    .setDescription('Play Rock, Paper, Scissors against the bot')
    .addStringOption(o => o.setName('choice').setDescription('Your choice').setRequired(true)
      .addChoices(
        { name: '🪨 Rock',      value: 'rock' },
        { name: '📄 Paper',     value: 'paper' },
        { name: '✂️ Scissors', value: 'scissors' }
      )),
  async execute(interaction) {
    const player = interaction.options.getString('choice');
    const bot    = CHOICES[Math.floor(Math.random() * 3)];
    let result, color;
    if (player === bot) { result = "It's a tie! 🤝"; color = '#faa61a'; }
    else if (
      (player === 'rock' && bot === 'scissors') ||
      (player === 'paper' && bot === 'rock') ||
      (player === 'scissors' && bot === 'paper')
    ) { result = 'You win! 🎉'; color = '#3ba55d'; }
    else { result = 'Bot wins! 🤖'; color = '#ed4245'; }
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor(color)
        .setTitle('Rock, Paper, Scissors!')
        .addFields(
          { name: 'Your Choice', value: `${EMOJIS[player]} ${player}`, inline: true },
          { name: "Bot's Choice", value: `${EMOJIS[bot]} ${bot}`, inline: true },
          { name: 'Result', value: `**${result}**` }
        )
        .setTimestamp()
      ]
    });
  }
};
