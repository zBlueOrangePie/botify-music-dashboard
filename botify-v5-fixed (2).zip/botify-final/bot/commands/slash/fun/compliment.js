const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const COMPLIMENTS = [
  "You light up every room you walk into ✨",
  "Your kindness is like a superpower 💙",
  "You have an incredible ability to make people smile 😄",
  "The world is genuinely a better place with you in it 🌍",
  "Your creativity knows absolutely no bounds 🎨",
  "You're stronger than you think, and braver than you believe 💪",
  "You have the best laugh — it's truly contagious 😂",
  "You make the people around you feel so valued and heard 🫂",
  "Your dedication and hard work never goes unnoticed 🏆",
  "You're the kind of person everyone hopes to meet 🌟",
  "Your perspective on things is so uniquely refreshing 🔮",
  "You radiate good energy and it's absolutely beautiful ⚡",
  "You handle tough situations with so much grace 🦋",
  "You're one of those rare people who truly make a difference 🎯",
  "Whoever has you in their life is really lucky 🍀",
];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('compliment')
    .setDescription('Send a wholesome compliment to someone 💙')
    .addUserOption(o => o.setName('user').setDescription('Who to compliment').setRequired(true)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const line   = COMPLIMENTS[Math.floor(Math.random() * COMPLIMENTS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#ff69b4')
      .setTitle('💙 A Compliment For You!')
      .setDescription(`${target}, **${line}**`)
      .setThumbnail(target.displayAvatarURL())
      .setFooter({ text: `Sent with ❤️ by ${interaction.user.tag}` })
      .setTimestamp()
    ]});
  }
};
