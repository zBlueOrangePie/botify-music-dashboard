const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const https = require('https');
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Botify/5.0' } }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch { reject(new Error('Parse error')); } });
    }).on('error', reject);
  });
}
function unescape(str) {
  return str.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#039;/g, "'");
}
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('trivia')
    .setDescription('Answer a random trivia question')
    .addStringOption(o => o.setName('difficulty').setDescription('Difficulty level').addChoices(
      { name: '🟢 Easy',   value: 'easy' },
      { name: '🟡 Medium', value: 'medium' },
      { name: '🔴 Hard',   value: 'hard' }
    )),
  async execute(interaction) {
    await interaction.deferReply();
    const difficulty = interaction.options.getString('difficulty') || 'medium';
    try {
      const data = await fetchJson(`https://opentdb.com/api.php?amount=1&type=multiple&difficulty=${difficulty}`);
      const q    = data.results?.[0];
      if (!q) return interaction.editReply('❌ Could not fetch a trivia question. Try again!');
      const question  = unescape(q.question);
      const correct   = unescape(q.correct_answer);
      const incorrect = q.incorrect_answers.map(unescape);
      const all       = [...incorrect, correct].sort(() => Math.random() - 0.5);
      const letters   = ['🇦', '🇧', '🇨', '🇩'];
      const correctIdx = all.indexOf(correct);
      const embed = new EmbedBuilder()
        .setColor(difficulty === 'easy' ? '#3ba55d' : difficulty === 'medium' ? '#faa61a' : '#ed4245')
        .setTitle(`🧠 ${unescape(q.category)} Trivia`)
        .setDescription(`**${question}**`)
        .addFields(all.map((ans, i) => ({ name: `${letters[i]} Option ${i + 1}`, value: ans, inline: true })))
        .setFooter({ text: `Difficulty: ${difficulty} · You have 30 seconds!` })
        .setTimestamp();
      const row = new ActionRowBuilder().addComponents(
        all.map((ans, i) => new ButtonBuilder()
          .setCustomId(`trivia_${i}_${correctIdx}_${interaction.user.id}`)
          .setLabel(`${['A', 'B', 'C', 'D'][i]}`)
          .setStyle(ButtonStyle.Primary)
        )
      );
      const msg = await interaction.editReply({ embeds: [embed], components: [row] });
      const collector = msg.createMessageComponentCollector({ time: 30000 });
      collector.on('collect', async btn => {
        if (!btn.customId.startsWith('trivia_')) return;
        const [, chosenIdx, correctI, userId] = btn.customId.split('_');
        if (btn.user.id !== userId) {
          return btn.reply({ content: '❌ This is not your trivia question!', ephemeral: true });
        }
        const won = parseInt(chosenIdx) === parseInt(correctI);
        await btn.update({
          embeds: [new EmbedBuilder()
            .setColor(won ? '#3ba55d' : '#ed4245')
            .setTitle(won ? '✅ Correct!' : '❌ Wrong!')
            .setDescription(`**${question}**\n\nThe correct answer was: **${correct}**`)
            .setFooter({ text: `${won ? '🎉 Great job!' : '😔 Better luck next time!'}` })
            .setTimestamp()
          ],
          components: []
        });
        collector.stop();
      });
      collector.on('end', (_, reason) => {
        if (reason === 'time') {
          interaction.editReply({ components: [] }).catch(() => {});
        }
      });
    } catch {
      await interaction.editReply('❌ Could not fetch trivia. Try again in a moment.');
    }
  }
};
