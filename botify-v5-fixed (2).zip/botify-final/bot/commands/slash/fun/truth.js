const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const TRUTHS = [
  "What's the most embarrassing thing you've ever done?",
  "Have you ever lied to get out of trouble?",
  "What is your biggest secret?",
  "Have you ever ghosted someone?",
  "What's the weirdest thing you've Googled?",
  "Have you ever cheated on a test?",
  "What's a bad habit you have that nobody knows about?",
  "Have you ever talked behind someone's back?",
  "What's the biggest lie you've told?",
  "Have you ever pretended to like a gift you hated?",
  "What's something you're embarrassed to admit you like?",
  "Have you ever accidentally liked an old post while stalking someone?",
  "What's the most childish thing you still do?",
  "Have you ever cried watching a movie or TV show?",
  "What's the strangest dream you've ever had?",
];
const DARES = [
  "Send a voice message of you singing a random song.",
  "Change your nickname to whatever the next person says for an hour.",
  "Write a poem about the last person who messaged you.",
  "Type everything in this server using only caps for the next 10 minutes.",
  "Send your current location emoji (city only).",
  "React to the last 5 messages with the weirdest emoji you can find.",
  "Send a 'good morning' message to your most recent DM.",
  "Change your profile picture to whatever the next person says for an hour.",
  "Speak only in questions for the next 5 minutes.",
  "Give an honest compliment to everyone in this chat.",
  "Send a tongue twister and record yourself trying to say it.",
  "Tell the group your most-used emoji and what it says about you.",
  "Write a 2-sentence horror story right now.",
  "Send the 5th photo in your camera roll (no skipping!).",
  "Let the next person who messages you change your status.",
];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('truth')
    .setDescription('Truth or Dare — get a random truth or dare')
    .addStringOption(o => o.setName('type').setDescription('Truth or Dare?').setRequired(true).addChoices(
      { name: '😇 Truth', value: 'truth' },
      { name: '😈 Dare',  value: 'dare' },
    )),
  async execute(interaction) {
    const type = interaction.options.getString('type');
    const list = type === 'truth' ? TRUTHS : DARES;
    const pick = list[Math.floor(Math.random() * list.length)];
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor(type === 'truth' ? '#5865f2' : '#ed4245')
      .setTitle(type === 'truth' ? '😇 TRUTH' : '😈 DARE')
      .setDescription(`**${pick}**`)
      .setFooter({ text: `Drawn for ${interaction.user.tag}` })
      .setTimestamp()
    ]});
  }
};
