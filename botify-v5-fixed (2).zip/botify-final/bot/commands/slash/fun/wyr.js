const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const QUESTIONS = [
  ["be able to fly", "be invisible"],
  ["never use social media again", "never watch another movie/TV show again"],
  ["always have to say what you're thinking", "never be able to talk again"],
  ["eat your least favourite food every day", "never eat your favourite food again"],
  ["be the funniest person in the room", "be the smartest person in the room"],
  ["have no WiFi for a month", "have no music for a year"],
  ["be famous but broke", "be rich but anonymous"],
  ["know when you'll die", "know how you'll die"],
  ["always be 10 minutes late", "always be 20 minutes early"],
  ["live in a world without colours", "live in a world without music"],
  ["have unlimited money", "have unlimited time"],
  ["be able to speak every language", "be able to play every instrument"],
  ["fight 100 duck-sized horses", "fight 1 horse-sized duck"],
  ["never feel cold", "never feel hot"],
  ["go back in time 10 years", "jump forward 10 years"],
];
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('wyr')
    .setDescription('Would You Rather — get a fun dilemma!'),
  async execute(interaction) {
    const [a, b] = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder()
      .setColor('#a855f7')
      .setTitle('🤔 Would You Rather…')
      .addFields(
        { name: '🔵 Option A', value: a, inline: true },
        { name: '🔴 Option B', value: b, inline: true },
      )
      .setFooter({ text: 'Reply with A or B to share your answer!' })
      .setTimestamp()
    ]});
  }
};
