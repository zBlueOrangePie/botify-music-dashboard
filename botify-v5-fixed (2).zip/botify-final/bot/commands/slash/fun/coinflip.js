const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'fun',
  data: new SlashCommandBuilder()
    .setName('coinflip')
    .setDescription('Flip a coin — heads or tails?'),
  async execute(interaction) {
    const result = Math.random() > 0.5 ? 'Heads' : 'Tails';
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setColor('#faa61a')
        .setTitle(`🪙 ${result}!`)
        .setDescription(`The coin landed on **${result}**!`)
        .setFooter({ text: `Flipped by ${interaction.user.tag}` })
        .setTimestamp()
      ]
    });
  }
};
