const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Delete multiple messages from this channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user')),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const amount = interaction.options.getInteger('amount');
    const target = interaction.options.getUser('user');
    const messages = await interaction.channel.messages.fetch({ limit: amount });
    const toDelete = target ? messages.filter(m => m.author.id === target.id) : messages;
    
    // Discord only allows bulk-delete of messages < 14 days old
    const now    = Date.now();
    const recent = toDelete.filter(m => now - m.createdTimestamp < 14 * 24 * 60 * 60 * 1000);
    if (!recent.size) {
      return interaction.editReply('❌ No messages found to delete (messages must be under 14 days old).');
    }
    const deleted = await interaction.channel.bulkDelete(recent, true);
    await interaction.editReply(`✅ Deleted **${deleted.size}** message(s)${target ? ` from ${target.tag}` : ''}.`);
  }
};
