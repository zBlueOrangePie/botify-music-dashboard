const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('softban')
    .setDescription('Ban then immediately unban a member to delete their messages')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to softban').setRequired(true))
    .addIntegerOption(o => o.setName('days').setDescription('Days of messages to delete (1-7)').setMinValue(1).setMaxValue(7))
    .addStringOption(o => o.setName('reason').setDescription('Reason')),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getMember('user');
    const days   = interaction.options.getInteger('days') ?? 1;
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!target) return interaction.editReply('❌ User not found.');
    if (!target.bannable) return interaction.editReply('❌ I cannot ban this user.');
    if (target.id === interaction.user.id) return interaction.editReply('❌ You cannot softban yourself.');
    const tag = target.user.tag;
    const id  = target.id;
    await target.ban({ deleteMessageSeconds: days * 86400, reason: `[Softban] [${interaction.user.tag}] ${reason}` });
    await interaction.guild.members.unban(id, 'Softban unban').catch(() => {});
    await interaction.editReply({ embeds: [new EmbedBuilder()
      .setColor('#faa61a')
      .setTitle('🧹 Member Softbanned')
      .setDescription(`**${tag}** was softbanned — messages deleted, then immediately unbanned.`)
      .addFields(
        { name: 'User',              value: `${tag}\n\`${id}\``, inline: true },
        { name: 'Moderator',         value: interaction.user.tag, inline: true },
        { name: 'Messages Deleted',  value: `Last ${days} day(s)`, inline: true },
        { name: 'Reason',            value: reason }
      )
      .setTimestamp()
    ]});
  }
};
