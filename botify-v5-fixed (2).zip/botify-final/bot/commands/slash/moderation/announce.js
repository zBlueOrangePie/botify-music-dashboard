const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Send a formatted announcement embed to a channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(o => o.setName('title').setDescription('Announcement title').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Announcement body').setRequired(true))
    .addChannelOption(o => o.setName('channel').setDescription('Target channel (default: current)'))
    .addStringOption(o => o.setName('color').setDescription('Embed color hex (e.g. #5865f2)'))
    .addBooleanOption(o => o.setName('ping').setDescription('Ping @everyone with announcement?')),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const title   = interaction.options.getString('title');
    const message = interaction.options.getString('message');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const color   = interaction.options.getString('color') || '#5865f2';
    const ping    = interaction.options.getBoolean('ping') ?? false;
    const validColor = /^#[0-9a-fA-F]{6}$/.test(color) ? color : '#5865f2';
    const embed = new EmbedBuilder()
      .setColor(validColor)
      .setTitle(`📢 ${title}`)
      .setDescription(message)
      .setFooter({ text: `Announced by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();
    await channel.send({ content: ping ? '@everyone' : null, embeds: [embed] });
    await interaction.editReply(`✅ Announcement sent to ${channel}.`);
  }
};
