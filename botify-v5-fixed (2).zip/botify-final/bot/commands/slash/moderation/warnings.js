const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Warning = require('../../../models/Warning');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('View or clear warnings for a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(s => s.setName('list').setDescription('List all warnings for a user')
      .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(true)))
    .addSubcommand(s => s.setName('clear').setDescription('Clear all warnings for a user')
      .addUserOption(o => o.setName('user').setDescription('User to clear warnings for').setRequired(true))),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub    = interaction.options.getSubcommand();
    const target = interaction.options.getUser('user');
    if (sub === 'list') {
      const warns = await Warning.find({ guildId: interaction.guildId, userId: target.id }).sort({ timestamp: -1 }).lean().catch(() => []);
      if (!warns.length) return interaction.editReply(`✅ **${target.tag}** has no warnings in this server.`);
      const embed = new EmbedBuilder()
        .setColor('#faa61a')
        .setTitle(`⚠️ Warnings for ${target.tag}`)
        .setThumbnail(target.displayAvatarURL())
        .setDescription(warns.slice(0, 10).map((w, i) =>
          `**#${i + 1}** — ${w.reason}\n> <@${w.moderatorId}> · <t:${Math.floor(new Date(w.timestamp).getTime() / 1000)}:R>`
        ).join('\n\n'))
        .setFooter({ text: `${warns.length} total warning(s)` })
        .setTimestamp();
      await interaction.editReply({ embeds: [embed] });
    }
    if (sub === 'clear') {
      const result = await Warning.deleteMany({ guildId: interaction.guildId, userId: target.id }).catch(() => null);
      await interaction.editReply(`✅ Cleared **${result?.deletedCount || 0}** warning(s) for **${target.tag}**.`);
    }
  }
};
