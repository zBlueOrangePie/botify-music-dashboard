const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set slowmode for the current channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addIntegerOption(o => o.setName('seconds').setDescription('Slowmode delay in seconds (0 = off)').setRequired(true).setMinValue(0).setMaxValue(21600)),
  async execute(interaction) {
    await interaction.deferReply();
    const seconds = interaction.options.getInteger('seconds');
    await interaction.channel.setRateLimitPerUser(seconds, `[${interaction.user.tag}] Slowmode command`);
    const friendly = seconds === 0 ? '**disabled**' : seconds >= 60
      ? `**${Math.floor(seconds / 60)}m ${seconds % 60}s**`
      : `**${seconds}s**`;
    await interaction.editReply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('⏱️ Slowmode Updated')
      .setDescription(seconds === 0 ? '🟢 Slowmode has been turned off.' : `🐢 Slowmode set to ${friendly} per message.`)
      .addFields({ name: 'Channel', value: `${interaction.channel}`, inline: true })
      .setTimestamp()
    ]});
  }
};
