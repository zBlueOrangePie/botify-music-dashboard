const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('nick')
    .setDescription('Change or reset a member\'s nickname')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames)
    .addUserOption(o => o.setName('user').setDescription('Member to rename').setRequired(true))
    .addStringOption(o => o.setName('nickname').setDescription('New nickname (leave blank to reset)')),
  async execute(interaction) {
    await interaction.deferReply();
    const target   = interaction.options.getMember('user');
    const nickname = interaction.options.getString('nickname') || null;
    if (!target) return interaction.editReply('❌ User not found.');
    if (!target.manageable) return interaction.editReply('❌ I cannot change this user\'s nickname.');
    const old = target.nickname || target.user.username;
    await target.setNickname(nickname, `[${interaction.user.tag}] Nick command`);
    await interaction.editReply({ embeds: [new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle('✏️ Nickname Changed')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',     value: target.user.tag, inline: true },
        { name: 'Old Nick', value: old, inline: true },
        { name: 'New Nick', value: nickname || `*(reset to ${target.user.username})*`, inline: true }
      )
      .setTimestamp()
    ]});
  }
};
