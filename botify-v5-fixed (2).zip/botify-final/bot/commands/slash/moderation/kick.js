const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for kick')),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!target) return interaction.editReply('❌ User not found in this server.');
    if (!target.kickable) return interaction.editReply('❌ I cannot kick this user. Check my role permissions.');
    if (target.id === interaction.user.id) return interaction.editReply('❌ You cannot kick yourself.');
    await target.kick(`[${interaction.user.tag}] ${reason}`);
    const embed = new EmbedBuilder()
      .setColor('#faa61a')
      .setTitle('👢 Member Kicked')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User', value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Moderator', value: interaction.user.tag, inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
