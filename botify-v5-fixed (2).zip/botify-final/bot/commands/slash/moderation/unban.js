const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user from the server by their ID')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(o => o.setName('userid').setDescription('Discord user ID to unban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for unban')),
  async execute(interaction) {
    await interaction.deferReply();
    const userId = interaction.options.getString('userid');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!/^\d{17,19}$/.test(userId)) return interaction.editReply('❌ That doesn\'t look like a valid Discord user ID.');
    let bannedUser;
    try {
      const banEntry = await interaction.guild.bans.fetch(userId);
      bannedUser = banEntry.user;
    } catch {
      return interaction.editReply('❌ That user is not banned from this server.');
    }
    await interaction.guild.members.unban(userId, `[${interaction.user.tag}] ${reason}`);
    await interaction.editReply({ embeds: [new EmbedBuilder()
      .setColor('#3ba55d')
      .setTitle('✅ User Unbanned')
      .setThumbnail(bannedUser.displayAvatarURL())
      .addFields(
        { name: 'User',      value: `${bannedUser.tag}\n\`${bannedUser.id}\``, inline: true },
        { name: 'Moderator', value: interaction.user.tag, inline: true },
        { name: 'Reason',    value: reason }
      )
      .setTimestamp()
    ]});
  }
};
