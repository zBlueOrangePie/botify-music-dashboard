const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('unmute')
    .setDescription('Remove a timeout (mute) from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to unmute').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for unmute')),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    if (!target) return interaction.editReply('❌ User not found in this server.');
    if (!target.isCommunicationDisabled()) return interaction.editReply('❌ This member is not currently muted.');
    await target.timeout(null, `[${interaction.user.tag}] ${reason}`);
    await interaction.editReply({ embeds: [new EmbedBuilder()
      .setColor('#3ba55d')
      .setTitle('🔊 Member Unmuted')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',      value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Moderator', value: interaction.user.tag, inline: true },
        { name: 'Reason',    value: reason }
      )
      .setTimestamp()
    ]});
  }
};
