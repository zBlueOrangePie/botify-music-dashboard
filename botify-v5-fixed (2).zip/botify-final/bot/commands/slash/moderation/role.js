const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('Add or remove a role from a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(s => s.setName('add').setDescription('Add a role to a member')
      .addUserOption(o => o.setName('user').setDescription('Member').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role to add').setRequired(true)))
    .addSubcommand(s => s.setName('remove').setDescription('Remove a role from a member')
      .addUserOption(o => o.setName('user').setDescription('Member').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Role to remove').setRequired(true))),
  async execute(interaction) {
    await interaction.deferReply();
    const sub    = interaction.options.getSubcommand();
    const target = interaction.options.getMember('user');
    const role   = interaction.options.getRole('role');
    if (!target) return interaction.editReply('❌ User not found.');
    if (role.managed) return interaction.editReply('❌ That role is managed by an integration and cannot be assigned manually.');
    if (role.position >= interaction.guild.members.me.roles.highest.position)
      return interaction.editReply('❌ That role is higher than or equal to my highest role.');
    if (sub === 'add') {
      if (target.roles.cache.has(role.id)) return interaction.editReply(`❌ ${target.user.tag} already has that role.`);
      await target.roles.add(role, `[${interaction.user.tag}] Role command`);
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#3ba55d').setTitle('✅ Role Added')
        .addFields(
          { name: 'User', value: target.user.tag, inline: true },
          { name: 'Role', value: role.toString(), inline: true }
        ).setTimestamp()
      ]});
    } else {
      if (!target.roles.cache.has(role.id)) return interaction.editReply(`❌ ${target.user.tag} doesn't have that role.`);
      await target.roles.remove(role, `[${interaction.user.tag}] Role command`);
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#ed4245').setTitle('❌ Role Removed')
        .addFields(
          { name: 'User', value: target.user.tag, inline: true },
          { name: 'Role', value: role.toString(), inline: true }
        ).setTimestamp()
      ]});
    }
  }
};
