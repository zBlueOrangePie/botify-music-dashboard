const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('tempban')
    .setDescription('Temporarily ban a member for a set duration')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to tempban').setRequired(true))
    .addIntegerOption(o => o.setName('duration').setDescription('Duration in hours').setRequired(true).setMinValue(1).setMaxValue(8760))
    .addStringOption(o => o.setName('reason').setDescription('Reason')),
  async execute(interaction) {
    await interaction.deferReply();
    const target   = interaction.options.getMember('user');
    const hours    = interaction.options.getInteger('duration');
    const reason   = interaction.options.getString('reason') || 'No reason provided';
    if (!target) return interaction.editReply('❌ User not found.');
    if (!target.bannable) return interaction.editReply('❌ I cannot ban this user.');
    if (target.id === interaction.user.id) return interaction.editReply('❌ You cannot tempban yourself.');
    const unbanAt = new Date(Date.now() + hours * 3600 * 1000);
    const friendly = hours >= 24 ? `${Math.floor(hours / 24)}d ${hours % 24}h` : `${hours}h`;
    await target.ban({ reason: `[Tempban ${friendly}] [${interaction.user.tag}] ${reason}` });
    // Schedule unban
    setTimeout(async () => {
      await interaction.guild.members.unban(target.id, `Tempban expired (${friendly})`).catch(() => {});
    }, hours * 3600 * 1000);
    await interaction.editReply({ embeds: [new EmbedBuilder()
      .setColor('#ed4245')
      .setTitle('⏳ Member Temp-Banned')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',      value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Moderator', value: interaction.user.tag, inline: true },
        { name: 'Duration',  value: friendly, inline: true },
        { name: 'Expires',   value: `<t:${Math.floor(unbanAt.getTime() / 1000)}:R>`, inline: true },
        { name: 'Reason',    value: reason }
      )
      .setTimestamp()
    ]});
    target.user.send({ embeds: [new EmbedBuilder()
      .setColor('#ed4245')
      .setTitle(`⏳ You were temp-banned from ${interaction.guild.name}`)
      .addFields(
        { name: 'Duration', value: friendly },
        { name: 'Expires',  value: `<t:${Math.floor(unbanAt.getTime() / 1000)}:R>` },
        { name: 'Reason',   value: reason }
      ).setTimestamp()
    ]}).catch(() => {});
  }
};
