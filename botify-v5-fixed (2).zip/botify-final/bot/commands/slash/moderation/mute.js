const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a member for a set duration')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('Member to mute').setRequired(true))
    .addIntegerOption(o => o.setName('duration').setDescription('Duration in minutes').setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(o => o.setName('reason').setDescription('Reason for mute')),
  async execute(interaction) {
    await interaction.deferReply();
    const target   = interaction.options.getMember('user');
    const duration = interaction.options.getInteger('duration');
    const reason   = interaction.options.getString('reason') || 'No reason provided';
    if (!target) return interaction.editReply('❌ User not found in this server.');
    if (target.id === interaction.user.id) return interaction.editReply('❌ You cannot mute yourself.');
    if (target.id === interaction.guild.ownerId) return interaction.editReply('❌ Cannot mute the server owner.');
    if (!target.moderatable) return interaction.editReply('❌ I cannot mute this user. Check my role permissions.');
    const ms = duration * 60 * 1000;
    await target.timeout(ms, `[${interaction.user.tag}] ${reason}`);
    const friendly = duration >= 60
      ? `${Math.floor(duration / 60)}h ${duration % 60}m`
      : `${duration}m`;
    const embed = new EmbedBuilder()
      .setColor('#faa61a')
      .setTitle('🔇 Member Muted')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User',      value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Moderator', value: interaction.user.tag, inline: true },
        { name: 'Duration',  value: friendly, inline: true },
        { name: 'Reason',    value: reason }
      )
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
    target.user.send({
      embeds: [new EmbedBuilder()
        .setColor('#faa61a')
        .setTitle(`🔇 You were muted in ${interaction.guild.name}`)
        .addFields(
          { name: 'Duration', value: friendly },
          { name: 'Reason',   value: reason }
        ).setTimestamp()]
    }).catch(() => {});
  }
};
