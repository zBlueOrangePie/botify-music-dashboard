const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock or unlock a channel so only mods can speak')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand(s => s.setName('channel').setDescription('Lock this channel'))
    .addSubcommand(s => s.setName('unlock').setDescription('Unlock this channel')),
  async execute(interaction) {
    await interaction.deferReply();
    const sub      = interaction.options.getSubcommand();
    const everyone = interaction.guild.roles.everyone;
    const channel  = interaction.channel;
    if (sub === 'channel') {
      await channel.permissionOverwrites.edit(everyone, { SendMessages: false });
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#ed4245').setTitle('🔒 Channel Locked')
        .setDescription(`${channel} has been **locked**. Only moderators can send messages.`)
        .setTimestamp()
      ]});
    } else {
      await channel.permissionOverwrites.edit(everyone, { SendMessages: null });
      await interaction.editReply({ embeds: [new EmbedBuilder()
        .setColor('#3ba55d').setTitle('🔓 Channel Unlocked')
        .setDescription(`${channel} has been **unlocked**. Everyone can send messages again.`)
        .setTimestamp()
      ]});
    }
  }
};
