const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for ban').setRequired(false))
    .addIntegerOption(o => o.setName('days').setDescription('Delete messages from past X days (0-7)').setMinValue(0).setMaxValue(7)),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const days   = interaction.options.getInteger('days') ?? 0;
    if (!target) return interaction.editReply({ content: '❌ User not found in this server.' });
    if (!target.bannable) return interaction.editReply({ content: '❌ I cannot ban this user. They may have a higher role than me.' });
    if (target.id === interaction.user.id) return interaction.editReply({ content: '❌ You cannot ban yourself.' });
    if (target.id === interaction.guild.ownerId) return interaction.editReply({ content: '❌ Cannot ban the server owner.' });
    await target.ban({ deleteMessageSeconds: days * 86400, reason: `[${interaction.user.tag}] ${reason}` });
    const embed = new EmbedBuilder()
      .setColor('#ed4245')
      .setTitle('🔨 Member Banned')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User', value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
        { name: 'Reason', value: reason },
        { name: 'Messages Deleted', value: days > 0 ? `Last ${days} day(s)` : 'None' , inline: true }
      )
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
