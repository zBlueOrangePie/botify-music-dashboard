const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Warning = require('../../../models/Warning');
module.exports = {
  category: 'moderation',
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Issue a warning to a member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for warning').setRequired(true)),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    if (!target) return interaction.editReply('❌ User not found.');
    if (target.user.bot) return interaction.editReply('❌ Cannot warn bots.');
    let count = 1;
    try {
      const warn = new Warning({
        guildId: interaction.guildId,
        userId:  target.id,
        moderatorId: interaction.user.id,
        reason
      });
      await warn.save();
      count = await Warning.countDocuments({ guildId: interaction.guildId, userId: target.id });
    } catch (e) {
      console.error('Warning DB error:', e.message);
    }
    const embed = new EmbedBuilder()
      .setColor('#faa61a')
      .setTitle('⚠️ Warning Issued')
      .setThumbnail(target.user.displayAvatarURL())
      .addFields(
        { name: 'User', value: `${target.user.tag}\n\`${target.id}\``, inline: true },
        { name: 'Moderator', value: interaction.user.tag, inline: true },
        { name: 'Warning #', value: String(count), inline: true },
        { name: 'Reason', value: reason }
      )
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
    // DM the warned user
    target.user.send({
      embeds: [new EmbedBuilder()
        .setColor('#faa61a')
        .setTitle(`⚠️ You were warned in ${interaction.guild.name}`)
        .addFields({ name: 'Reason', value: reason }, { name: 'Warning Count', value: String(count) })
        .setTimestamp()
      ]
    }).catch(() => {}); // silently fail if DMs are closed
  }
};
