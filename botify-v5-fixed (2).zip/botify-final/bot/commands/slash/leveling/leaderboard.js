const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Leveling = require('../../../models/Leveling');
module.exports = {
  category: 'leveling',
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the server XP leaderboard')
    .addIntegerOption(o => o.setName('page').setDescription('Page number').setMinValue(1)),
  async execute(interaction) {
    await interaction.deferReply();
    const page = (interaction.options.getInteger('page') || 1) - 1;
    const per  = 10;
    let top;
    try {
      top = await Leveling.find({ guildId: interaction.guildId })
        .sort({ totalXp: -1 })
        .skip(page * per)
        .limit(per)
        .lean();
    } catch {
      return interaction.editReply('❌ Could not fetch leaderboard. Is the database connected?');
    }
    if (!top.length) return interaction.editReply('No leaderboard data yet. Start chatting to earn XP!');
    const medals   = ['🥇', '🥈', '🥉'];
    const lines    = top.map((entry, i) => {
      const pos    = page * per + i + 1;
      const medal  = medals[i] || `**${pos}.**`;
      return `${medal} <@${entry.userId}> — Level **${entry.level}** · **${entry.totalXp.toLocaleString()}** XP`;
    });
    const total = await Leveling.countDocuments({ guildId: interaction.guildId }).catch(() => 0);
    const pages = Math.ceil(total / per);
    const embed = new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle(`🏆 ${interaction.guild.name} Leaderboard`)
      .setDescription(lines.join('\n'))
      .setFooter({ text: `Page ${page + 1}/${pages} · ${total} ranked members` })
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
