const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Leveling = require('../../../models/Leveling');
module.exports = {
  category: 'leveling',
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('View your XP rank or another member\'s rank')
    .addUserOption(o => o.setName('user').setDescription('User to check rank for')),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getUser('user') || interaction.user;
    let data;
    try {
      data = await Leveling.findOne({ guildId: interaction.guildId, userId: target.id });
    } catch {
      return interaction.editReply('❌ Could not fetch leveling data. Is the database connected?');
    }
    if (!data) {
      return interaction.editReply(`${target.id === interaction.user.id ? 'You have' : `**${target.username}** has`} no XP in this server yet. Start chatting!`);
    }
    // Calculate rank
    let rank = 1;
    try {
      rank = await Leveling.countDocuments({ guildId: interaction.guildId, totalXp: { $gt: data.totalXp } }) + 1;
    } catch {}
    const needed   = 5 * Math.pow(data.level, 2) + 50 * data.level + 100;
    const progress = Math.min(20, Math.floor((data.xp / needed) * 20));
    const bar      = '█'.repeat(progress) + '░'.repeat(20 - progress);
    const pct      = Math.floor((data.xp / needed) * 100);
    const embed = new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle(`📊 ${target.username}'s Rank`)
      .setThumbnail(target.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '🏆 Server Rank',  value: `**#${rank}**`, inline: true },
        { name: '⭐ Level',        value: `**${data.level}**`, inline: true },
        { name: '✨ Total XP',     value: `**${data.totalXp.toLocaleString()}**`, inline: true },
        { name: '💬 Messages',     value: `**${data.messages.toLocaleString()}**`, inline: true },
        { name: '📈 Progress',     value: `\`${bar}\` **${pct}%**\n${data.xp.toLocaleString()} / ${needed.toLocaleString()} XP` }
      )
      .setFooter({ text: `Server: ${interaction.guild.name}` })
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
