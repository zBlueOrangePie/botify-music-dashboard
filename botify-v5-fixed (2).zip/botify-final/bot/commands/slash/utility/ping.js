const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'utility',
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check the bot latency and API response time'),
  async execute(interaction) {
    const start = Date.now();
    await interaction.deferReply();
    const elapsed = Date.now() - start;
    const ws = Math.round(interaction.client.ws.ping);
    const embed = new EmbedBuilder()
      .setColor(ws < 100 ? '#3ba55d' : ws < 200 ? '#faa61a' : '#ed4245')
      .setTitle('🏓 Pong!')
      .addFields(
        { name: '⏱️ Bot Latency', value: `\`${elapsed}ms\``, inline: true },
        { name: '📡 WebSocket Ping', value: `\`${ws}ms\``, inline: true },
        { name: '⚙️ Status', value: ws < 100 ? '🟢 Excellent' : ws < 200 ? '🟡 Good' : '🔴 High', inline: true }
      )
      .setFooter({ text: `Serving ${interaction.client.guilds.cache.size} guilds` })
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
