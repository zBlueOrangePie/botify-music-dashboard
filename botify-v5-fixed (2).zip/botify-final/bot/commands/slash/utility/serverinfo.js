const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
module.exports = {
  category: 'utility',
  data: new SlashCommandBuilder()
    .setName('serverinfo')
    .setDescription('Display detailed information about this server'),
  async execute(interaction) {
    await interaction.deferReply();
    const g = interaction.guild;
    await g.fetch();
    const textChannels  = g.channels.cache.filter(c => c.type === ChannelType.GuildText).size;
    const voiceChannels = g.channels.cache.filter(c => c.type === ChannelType.GuildVoice).size;
    const categories    = g.channels.cache.filter(c => c.type === ChannelType.GuildCategory).size;
    const bots          = g.members.cache.filter(m => m.user.bot).size;
    const boosters      = g.premiumSubscriptionCount || 0;
    const embed = new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle(g.name)
      .setThumbnail(g.iconURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '👑 Owner',        value: `<@${g.ownerId}>`, inline: true },
        { name: '🌍 Region',       value: g.preferredLocale || 'Unknown', inline: true },
        { name: '📅 Created',      value: `<t:${Math.floor(g.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '👥 Members',      value: `${g.memberCount} (${bots} bots)`, inline: true },
        { name: '💬 Channels',     value: `${textChannels} text · ${voiceChannels} voice · ${categories} categories`, inline: true },
        { name: '🎭 Roles',        value: String(g.roles.cache.size), inline: true },
        { name: '✨ Boost Level',  value: `Level ${g.premiumTier} (${boosters} boosts)`, inline: true },
        { name: '🔒 Verification', value: g.verificationLevel.toString(), inline: true },
        { name: '🆔 Server ID',    value: `\`${g.id}\``, inline: true }
      )
      .setImage(g.bannerURL({ size: 1024 }) || null)
      .setFooter({ text: `ID: ${g.id}` })
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
