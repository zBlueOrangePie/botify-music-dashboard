const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const COMMAND_INFO = {
  moderation: [
    { name: 'ban',       desc: 'Ban a member from the server' },
    { name: 'unban',     desc: 'Unban a user by their Discord ID' },
    { name: 'softban',   desc: 'Ban + immediately unban to delete messages' },
    { name: 'tempban',   desc: 'Temporarily ban a member for a set duration' },
    { name: 'kick',      desc: 'Kick a member from the server' },
    { name: 'mute',      desc: 'Timeout (mute) a member for a set duration' },
    { name: 'unmute',    desc: 'Remove a timeout from a member' },
    { name: 'warn',      desc: 'Issue a warning to a member' },
    { name: 'warnings',  desc: 'View or clear all warnings for a member' },
    { name: 'purge',     desc: 'Bulk-delete messages from a channel' },
    { name: 'slowmode',  desc: 'Set slowmode delay for this channel' },
    { name: 'lock',      desc: 'Lock or unlock a channel' },
    { name: 'nick',      desc: "Change or reset a member's nickname" },
    { name: 'role',      desc: 'Add or remove a role from a member' },
    { name: 'announce',  desc: 'Send a formatted announcement embed to a channel' },
  ],
  utility: [
    { name: 'help',       desc: 'Show this help menu' },
    { name: 'ping',       desc: 'Check bot latency and API ping' },
    { name: 'serverinfo', desc: 'View detailed server information' },
    { name: 'userinfo',   desc: 'View info about a user' },
  ],
  fun: [
    { name: '8ball',     desc: 'Ask the magic 8-ball a yes/no question' },
    { name: 'coinflip',  desc: 'Flip a coin — heads or tails?' },
    { name: 'roll',      desc: 'Roll one or more dice' },
    { name: 'rps',       desc: 'Play Rock, Paper, Scissors vs the bot' },
    { name: 'tictactoe', desc: 'Play Tic-Tac-Toe against the bot' },
    { name: 'trivia',    desc: 'Answer a random trivia question (with timer)' },
    { name: 'truth',     desc: 'Get a random Truth or Dare prompt' },
    { name: 'wyr',       desc: 'Get a Would You Rather dilemma' },
    { name: 'meme',      desc: 'Get a random meme from Reddit' },
    { name: 'joke',      desc: 'Get a random joke' },
    { name: 'fact',      desc: 'Get a random interesting fact' },
    { name: 'poll',      desc: 'Create a reaction poll with up to 4 options' },
    { name: 'roast',     desc: 'Roast a member (all in good fun)' },
    { name: 'compliment',desc: 'Send a wholesome compliment to someone' },
    { name: 'ship',      desc: 'Ship two users together ❤️' },
    { name: 'gayrate',   desc: 'Fun gay rate meter 🌈' },
    { name: 'say',       desc: 'Make the bot say something (Mods only)' },
  ],
  music: [
    { name: 'play',       desc: 'Play a song or playlist from YouTube/Spotify/SoundCloud' },
    { name: 'search',     desc: 'Search for a song and pick from results' },
    { name: 'playlist',   desc: 'Load and play a full playlist by URL' },
    { name: 'skip',       desc: 'Skip the current song' },
    { name: 'skipto',     desc: 'Jump directly to a specific position in the queue' },
    { name: 'stop',       desc: 'Stop playback and clear the queue' },
    { name: 'pause',      desc: 'Pause the current song' },
    { name: 'resume',     desc: 'Resume paused playback' },
    { name: 'queue',      desc: 'View the current music queue' },
    { name: 'nowplaying', desc: "Show what's currently playing with progress" },
    { name: 'volume',     desc: 'Set the playback volume (1–100)' },
    { name: 'shuffle',    desc: 'Shuffle all tracks in the queue' },
    { name: 'loop',       desc: 'Set loop mode (off / track / queue / autoplay)' },
    { name: 'seek',       desc: 'Jump to a specific timestamp in the track' },
    { name: 'remove',     desc: 'Remove a track from the queue by position' },
    { name: 'move',       desc: 'Move a track from one queue position to another' },
    { name: 'filter',     desc: 'Apply an audio filter (bass boost, nightcore, 8D, etc.)' },
    { name: 'lyrics',     desc: 'Get lyrics for the current or a specific song' },
  ],
  leveling: [
    { name: 'rank',        desc: 'View your XP rank card in this server' },
    { name: 'leaderboard', desc: 'View the top XP earners in this server' },
  ],
};
const ICONS = {
  moderation: '🛡️',
  utility:    '🔧',
  fun:        '🎮',
  music:      '🎵',
  leveling:   '📈',
};
module.exports = {
  category: 'utility',
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available Botify commands')
    .addStringOption(o => o.setName('category').setDescription('Filter by category').addChoices(
      { name: '🛡️ Moderation (15)', value: 'moderation' },
      { name: '🔧 Utility    (4)',  value: 'utility'    },
      { name: '🎮 Fun        (17)', value: 'fun'        },
      { name: '🎵 Music      (18)', value: 'music'      },
      { name: '📈 Leveling   (2)',  value: 'leveling'   },
    )),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const filter = interaction.options.getString('category');
    // Pick up any extra dynamically loaded commands not listed above
    const extra = {};
    interaction.client.commands.forEach(cmd => {
      const cat = cmd.category || 'utility';
      if (!COMMAND_INFO[cat]) return;
      if (!COMMAND_INFO[cat].some(c => c.name === cmd.data.name)) {
        (extra[cat] = extra[cat] || []).push({ name: cmd.data.name, desc: cmd.data.description });
      }
    });
    const total      = Object.values(COMMAND_INFO).reduce((a, b) => a + b.length, 0);
    const toShow     = filter ? { [filter]: COMMAND_INFO[filter] } : COMMAND_INFO;
    const embed = new EmbedBuilder()
      .setColor('#5865f2')
      .setTitle(filter
        ? `${ICONS[filter] || '📦'} ${filter.charAt(0).toUpperCase() + filter.slice(1)} Commands`
        : '📖 Botify — All Commands'
      )
      .setDescription(
        `Use \`/help [category]\` to filter.\n` +
        `**${total} commands** across **${Object.keys(COMMAND_INFO).length} categories**.\n` +
        `Type \`/\` in Discord to see full command details.`
      )
      .setThumbnail(interaction.client.user.displayAvatarURL())
      .setFooter({ text: `Requested by ${interaction.user.tag} · Botify v5`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();
    for (const [cat, cmds] of Object.entries(toShow)) {
      if (!cmds?.length) continue;
      const all = [...cmds, ...(extra[cat] || [])];
      embed.addFields({
        name:  `${ICONS[cat] || '📦'} ${cat.charAt(0).toUpperCase() + cat.slice(1)} (${all.length})`,
        value: all.map(c => `\`/${c.name}\` — ${c.desc}`).join('\n'),
      });
    }
    await interaction.editReply({ embeds: [embed] });
  }
};
