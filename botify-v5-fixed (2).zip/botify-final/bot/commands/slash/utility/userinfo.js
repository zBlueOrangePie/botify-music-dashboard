const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
module.exports = {
  category: 'utility',
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Display information about a user')
    .addUserOption(o => o.setName('user').setDescription('User to look up (defaults to you)')),
  async execute(interaction) {
    await interaction.deferReply();
    const target = interaction.options.getMember('user') || interaction.member;
    const user   = target.user;
    const roles = target.roles.cache
      .filter(r => r.id !== interaction.guildId)
      .sort((a, b) => b.position - a.position)
      .map(r => r.toString())
      .slice(0, 10);
    const embed = new EmbedBuilder()
      .setColor(target.displayHexColor || '#5865f2')
      .setTitle(`${user.username}${user.discriminator !== '0' ? '#' + user.discriminator : ''}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '🆔 User ID',       value: `\`${user.id}\``, inline: true },
        { name: '🤖 Bot',           value: user.bot ? 'Yes' : 'No', inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
        { name: '📥 Joined Server',  value: `<t:${Math.floor(target.joinedTimestamp / 1000)}:D>`, inline: true },
        { name: '🎨 Display Color',  value: target.displayHexColor || '#5865f2', inline: true },
        { name: '✨ Boosting Since', value: target.premiumSince ? `<t:${Math.floor(target.premiumSinceTimestamp / 1000)}:D>` : 'Not boosting', inline: true },
        { name: `🎭 Roles (${roles.length})`, value: roles.length ? roles.join(', ') : 'No roles' }
      )
      .setFooter({ text: `Requested by ${interaction.user.tag}` })
      .setTimestamp();
    await interaction.editReply({ embeds: [embed] });
  }
};
