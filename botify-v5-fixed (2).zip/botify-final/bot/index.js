require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const { initializeMusicPlayer } = require('./utils/music');
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
console.log(`
╔═══════════════════════════════════════════════╗
║         🤖 BOTIFY BOT v4.0 STARTING          ║
║           Powered by Node.js v24             ║
╚═══════════════════════════════════════════════╝
`);
// Create Client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates
  ],
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.Reaction,
    Partials.User,
    Partials.GuildMember
  ]
});
// Collections
client.commands = new Collection(); // Slash commands
client.prefixCommands = new Collection(); // Prefix commands
client.prefix = process.env.PREFIX || '!';
client.developers = process.env.DEVELOPER_IDS ? process.env.DEVELOPER_IDS.split(',') : [];
// Initialize Music Player (discord-player)
try {
  initializeMusicPlayer(client);
} catch (error) {
  console.error('⚠️  Music player initialization failed:', error.message);
  console.log('   Music commands will not work');
}
// Load Slash Commands
console.log('📂 Loading slash commands...');
const slashCommandsPath = path.join(__dirname, 'commands', 'slash');
if (fs.existsSync(slashCommandsPath)) {
  const slashCategories = fs.readdirSync(slashCommandsPath);
  let slashCount = 0;
  for (const category of slashCategories) {
    const categoryPath = path.join(slashCommandsPath, category);
    
    if (!fs.statSync(categoryPath).isDirectory()) continue;
    
    const commandFiles = fs.readdirSync(categoryPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
      const filePath = path.join(categoryPath, file);
      
      try {
        // Clear cache
        delete require.cache[require.resolve(filePath)];
        const command = require(filePath);
        
        if ('data' in command && 'execute' in command) {
          client.commands.set(command.data.name, command);
          slashCount++;
          console.log(`   ✅ ${category}/${command.data.name}`);
        } else {
          console.log(`   ⚠️  ${file} - missing data or execute`);
        }
      } catch (error) {
        console.error(`   ❌ ${file}:`, error.message);
      }
    }
  }
  console.log(`\n✅ Loaded ${slashCount} slash commands`);
} else {
  console.log('⚠️  Slash commands directory not found');
}
// Load Prefix Commands
console.log('\n📂 Loading prefix commands...');
const prefixCommandsPath = path.join(__dirname, 'commands', 'prefix');
if (fs.existsSync(prefixCommandsPath)) {
  const prefixCategories = fs.readdirSync(prefixCommandsPath);
  let prefixCount = 0;
  for (const category of prefixCategories) {
    const categoryPath = path.join(prefixCommandsPath, category);
    
    if (!fs.statSync(categoryPath).isDirectory()) continue;
    
    const commandFiles = fs.readdirSync(categoryPath).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
      const filePath = path.join(categoryPath, file);
      
      try {
        // Clear cache
        delete require.cache[require.resolve(filePath)];
        const command = require(filePath);
        
        if ('name' in command && 'execute' in command) {
          client.prefixCommands.set(command.name, command);
          
          // Register aliases
          if (command.aliases && Array.isArray(command.aliases)) {
            command.aliases.forEach(alias => {
              client.prefixCommands.set(alias, command);
            });
          }
          
          prefixCount++;
          console.log(`   ✅ ${category}/${command.name}${command.aliases ? ` (${command.aliases.join(', ')})` : ''}`);
        } else {
          console.log(`   ⚠️  ${file} - missing name or execute`);
        }
      } catch (error) {
        console.error(`   ❌ ${file}:`, error.message);
      }
    }
  }
  console.log(`\n✅ Loaded ${prefixCount} prefix commands`);
} else {
  console.log('⚠️  Prefix commands directory not found');
}
// Load Events
console.log('\n📂 Loading events...');
const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
  let eventCount = 0;
  for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    
    try {
      // Clear cache
      delete require.cache[require.resolve(filePath)];
      const event = require(filePath);
      
      if ('name' in event && 'execute' in event) {
        if (event.once) {
          client.once(event.name, (...args) => event.execute(...args, client));
        } else {
          client.on(event.name, (...args) => event.execute(...args, client));
        }
        eventCount++;
        console.log(`   ✅ ${event.name}${event.once ? ' (once)' : ''}`);
      } else {
        console.log(`   ⚠️  ${file} - missing name or execute`);
      }
    } catch (error) {
      console.error(`   ❌ ${file}:`, error.message);
    }
  }
  console.log(`\n✅ Loaded ${eventCount} events`);
} else {
  console.log('⚠️  Events directory not found');
}
// MongoDB Connection
console.log('\n🔌 Connecting to MongoDB...');
if (process.env.MONGODB_URI) {
  mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
    .then(() => {
      console.log('✅ MongoDB connected successfully');
    })
    .catch(err => {
      console.error('❌ MongoDB connection error:', err);
      console.log('⚠️  Bot will continue without database features');
    });
} else {
  console.log('⚠️  MONGODB_URI not set - skipping database connection');
}
// Error Handlers
process.on('unhandledRejection', error => {
  console.error('❌ Unhandled promise rejection:', error);
});
process.on('uncaughtException', error => {
  console.error('❌ Uncaught exception:', error);
});
client.on('error', error => {
  console.error('❌ Discord client error:', error);
});
// Login
console.log('\n🤖 Logging in to Discord...');
if (!process.env.BOT_TOKEN) {
  console.error('❌ BOT_TOKEN not found in environment variables!');
  process.exit(1);
}
client.login(process.env.BOT_TOKEN)
  .then(() => {
    console.log('✅ Bot logged in successfully\n');
    
    // Set global bot client for web dashboard access
    global.botClient = client;
    console.log('✅ Bot client set globally (accessible by dashboard)\n');
  })
  .catch(error => {
    console.error('❌ Failed to login:', error);
    console.log('\nPossible causes:');
    console.log('  - Invalid BOT_TOKEN');
    console.log('  - No internet connection');
    console.log('  - Discord API issues');
    process.exit(1);
  });
// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n⏹️  Shutting down gracefully...');
  client.destroy();
  process.exit(0);
});
process.on('SIGTERM', () => {
  console.log('\n⏹️  Shutting down gracefully...');
  client.destroy();
  process.exit(0);
});
module.exports = client;
