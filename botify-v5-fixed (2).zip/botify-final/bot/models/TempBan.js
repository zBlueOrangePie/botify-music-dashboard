const mongoose = require('mongoose');
const tempBanSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true
  },
  userId: {
    type: String,
    required: true
  },
  moderatorId: {
    type: String,
    required: true
  },
  reason: {
    type: String,
    required: true
  },
  bannedAt: {
    type: Date,
    default: Date.now
  },
  expiresAt: {
    type: Date,
    required: true
  },
  active: {
    type: Boolean,
    default: true
  }
});
tempBanSchema.index({ guildId: 1, userId: 1 });
tempBanSchema.index({ expiresAt: 1 });
module.exports = mongoose.model('TempBan', tempBanSchema);
