const mongoose = require('mongoose');
const reactionRoleSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true
  },
  channelId: {
    type: String,
    required: true
  },
  messageId: {
    type: String,
    required: true
  },
  title: {
    type: String,
    default: 'React to get roles!'
  },
  description: {
    type: String,
    default: 'Click the reactions below to get your roles.'
  },
  color: {
    type: String,
    default: '#5865f2'
  },
  roles: [{
    emoji: String,
    roleId: String,
    roleName: String
  }],
  createdBy: {
    type: String,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
module.exports = mongoose.model('ReactionRole', reactionRoleSchema);
