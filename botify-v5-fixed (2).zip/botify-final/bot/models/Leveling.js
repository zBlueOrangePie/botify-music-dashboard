const mongoose = require('mongoose');
const levelingSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    index: true
  },
  userId: {
    type: String,
    required: true,
    index: true
  },
  xp: {
    type: Number,
    default: 0
  },
  level: {
    type: Number,
    default: 0
  },
  totalXp: {
    type: Number,
    default: 0
  },
  messages: {
    type: Number,
    default: 0
  },
  lastXpGain: {
    type: Date,
    default: null
  }
});
// Compound index for faster queries
levelingSchema.index({ guildId: 1, userId: 1 }, { unique: true });
levelingSchema.index({ guildId: 1, level: -1, xp: -1 });
module.exports = mongoose.model('Leveling', levelingSchema);
