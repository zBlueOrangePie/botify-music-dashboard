const mongoose = require('mongoose');
const guildSettingsSchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true,
    unique: true
  },
  prefix: {
    type: String,
    default: '!'
  },
  language: {
    type: String,
    default: 'en'
  },
  timezone: {
    type: String,
    default: 'UTC'
  },
  // Welcome System
  welcomeEnabled: {
    type: Boolean,
    default: false
  },
  welcomeChannel: {
    type: String,
    default: null
  },
  welcomeMessage: {
    type: String,
    default: 'Welcome {mention} to **{server}**! You are member #{memberCount}!'
  },
  welcomeUseEmbed: {
    type: Boolean,
    default: true
  },
  welcomeEmbedColor: {
    type: String,
    default: '#00ff00'
  },
  welcomeEmbedTitle: {
    type: String,
    default: '👋 Welcome!'
  },
  welcomeEmbedImage: {
    type: String,
    default: null
  },
  welcomeEmbedThumbnail: {
    type: String,
    default: 'user'
  },
  welcomeEmbedFooter: {
    type: String,
    default: 'Welcome to {server}'
  },
  welcomeRoles: [{
    type: String
  }],
  welcomeDM: {
    type: Boolean,
    default: false
  },
  welcomeDMMessage: {
    type: String,
    default: 'Welcome to {server}!'
  },
  // Leave System
  leaveEnabled: {
    type: Boolean,
    default: false
  },
  leaveChannel: {
    type: String,
    default: null
  },
  leaveMessage: {
    type: String,
    default: 'Goodbye {user}! We now have {memberCount} members.'
  },
  leaveUseEmbed: {
    type: Boolean,
    default: true
  },
  leaveEmbedColor: {
    type: String,
    default: '#ff0000'
  },
  leaveEmbedTitle: {
    type: String,
    default: '👋 Goodbye!'
  },
  leaveEmbedImage: {
    type: String,
    default: null
  },
  leaveEmbedThumbnail: {
    type: String,
    default: 'user'
  },
  leaveEmbedFooter: {
    type: String,
    default: 'We hope to see you again!'
  },
  // Logging System
  loggingEnabled: {
    type: Boolean,
    default: false
  },
  logChannel: {
    type: String,
    default: null
  },
  logEvents: {
    messageDelete: { type: Boolean, default: true },
    messageUpdate: { type: Boolean, default: true },
    memberJoin: { type: Boolean, default: true },
    memberLeave: { type: Boolean, default: true },
    memberBan: { type: Boolean, default: true },
    memberUnban: { type: Boolean, default: true },
    roleCreate: { type: Boolean, default: true },
    roleDelete: { type: Boolean, default: true },
    channelCreate: { type: Boolean, default: true },
    channelDelete: { type: Boolean, default: true }
  },
  // Moderation
  moderationRole: {
    type: String,
    default: null
  },
  // AutoMod System
  autoModEnabled: {
    type: Boolean,
    default: false
  },
  autoModSpam: {
    enabled: { type: Boolean, default: true },
    maxMessages: { type: Number, default: 5 },
    timeWindow: { type: Number, default: 5000 },
    action: { type: String, default: 'warn' } // warn, mute, kick, ban
  },
  autoModLinks: {
    enabled: { type: Boolean, default: false },
    whitelist: [{ type: String }],
    action: { type: String, default: 'delete' }
  },
  autoModInvites: {
    enabled: { type: Boolean, default: false },
    action: { type: String, default: 'delete' }
  },
  autoModCaps: {
    enabled: { type: Boolean, default: false },
    percentage: { type: Number, default: 70 },
    minLength: { type: Number, default: 10 },
    action: { type: String, default: 'warn' }
  },
  autoModBadWords: {
    enabled: { type: Boolean, default: false },
    words: [{ type: String }],
    action: { type: String, default: 'delete' }
  },
  autoModMentions: {
    enabled: { type: Boolean, default: false },
    maxMentions: { type: Number, default: 5 },
    action: { type: String, default: 'warn' }
  },
  autoModChannel: {
    type: String,
    default: null
  },
  // Verification System
  verificationEnabled: {
    type: Boolean,
    default: false
  },
  verificationChannel: {
    type: String,
    default: null
  },
  verificationRole: {
    type: String,
    default: null
  },
  verificationMessage: {
    type: String,
    default: 'Click the button below to verify!'
  },
  verificationUseEmbed: {
    type: Boolean,
    default: true
  },
  verificationEmbedColor: {
    type: String,
    default: '#5865f2'
  },
  verificationEmbedTitle: {
    type: String,
    default: '✅ Verification'
  },
  verificationEmbedDescription: {
    type: String,
    default: 'Welcome to the server! Please verify yourself to gain access.'
  },
  verificationButtonText: {
    type: String,
    default: 'Verify'
  },
  verificationLogChannel: {
    type: String,
    default: null
  },
  // Tickets
  ticketEnabled: {
    type: Boolean,
    default: false
  },
  ticketCategory: {
    type: String,
    default: null
  },
  ticketSupportRole: {
    type: String,
    default: null
  },
  // Leveling System
  levelingEnabled: {
    type: Boolean,
    default: false
  },
  levelingChannel: {
    type: String,
    default: null
  },
  levelingMessage: {
    type: String,
    default: 'Congratulations {mention}! You reached level {level}!'
  },
  levelingXpMin: {
    type: Number,
    default: 15
  },
  levelingXpMax: {
    type: Number,
    default: 25
  },
  levelingCooldown: {
    type: Number,
    default: 60 // seconds
  },
  levelingUseEmbed: {
    type: Boolean,
    default: true
  },
  levelingEmbedColor: {
    type: String,
    default: '#5865f2'
  },
  levelingIgnoredChannels: [{
    type: String
  }],
  levelingIgnoredRoles: [{
    type: String
  }],
  levelingMultiplierRoles: [{
    roleId: String,
    multiplier: Number
  }],
  levelRoles: [{
    level: Number,
    roleId: String,
    roleName: String
  }],
  // Auto Roles
  autoRoles: [{
    type: String
  }],
  autoRoleDelay: {
    type: Number,
    default: 0 // seconds
  },
  // Verification System Extended
  verificationAutoCreateRole: {
    type: Boolean,
    default: false
  },
  verificationAutoRoleName: {
    type: String,
    default: 'Verified'
  },
  verificationAutoRoleColor: {
    type: String,
    default: '#5865f2'
  },
  // Custom Commands
  customCommands: [{
    name: String,
    response: String,
    useEmbed: { type: Boolean, default: false },
    embedColor: { type: String, default: '#5865f2' },
    embedTitle: { type: String, default: null },
    embedDescription: { type: String, default: null },
    embedImage: { type: String, default: null },
    embedThumbnail: { type: String, default: null },
    embedFooter: { type: String, default: null },
    enabled: Boolean,
    createdBy: String,
    createdAt: { type: Date, default: Date.now }
  }],
  // Disabled Global Commands
  disabledCommands: [{
    type: String
  }],
  // Command Category Toggles
  commandCategories: {
    moderation: { type: Boolean, default: true },
    fun: { type: Boolean, default: true },
    utility: { type: Boolean, default: true },
    music: { type: Boolean, default: true }
  }
}, {
  timestamps: true
});
module.exports = mongoose.model('GuildSettings', guildSettingsSchema);
