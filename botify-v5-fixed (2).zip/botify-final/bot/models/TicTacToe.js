const mongoose = require('mongoose');

const TicTacToeSchema = new mongoose.Schema({
  userId:    { type: String, required: true, index: true },
  username:  { type: String, default: 'Unknown' },
  avatar:    { type: String, default: null },
  wins:      { type: Number, default: 0 },
  losses:    { type: Number, default: 0 },
  draws:     { type: Number, default: 0 },
  totalGames:{ type: Number, default: 0 },
  fastestWin:{ type: Number, default: null },   // milliseconds
  totalTime: { type: Number, default: 0 },      // total ms played
  lastPlayed:{ type: Date,   default: Date.now },
});

TicTacToeSchema.virtual('avgTime').get(function() {
  return this.totalGames > 0 ? Math.floor(this.totalTime / this.totalGames) : 0;
});

TicTacToeSchema.index({ wins: -1 });
TicTacToeSchema.index({ fastestWin: 1 });

module.exports = mongoose.model('TicTacToe', TicTacToeSchema);
