const mongoose = require('mongoose');
const giveawaySchema = new mongoose.Schema({
  guildId: {
    type: String,
    required: true
  },
  channelId: {
    type: String,
    required: true
  },
  messageId: {
    type: String,
    default: null
  },
  prize: {
    type: String,
    required: true
  },
  winners: {
    type: Number,
    default: 1
  },
  duration: {
    type: Number,
    required: true // in milliseconds
  },
  endTime: {
    type: Date,
    required: true
  },
  hostId: {
    type: String,
    required: true
  },
  requirements: {
    minAge: { type: Number, default: 0 }, // days
    requiredRoles: [{ type: String }]
  },
  entries: [{
    userId: String,
    enteredAt: { type: Date, default: Date.now }
  }],
  winnerIds: [{
    type: String
  }],
  ended: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});
module.exports = mongoose.model('Giveaway', giveawaySchema);
