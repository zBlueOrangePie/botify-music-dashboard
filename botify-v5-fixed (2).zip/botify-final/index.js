require('dotenv').config();
const { spawn } = require('child_process');
const path = require('path');
console.log(`
╔═══════════════════════════════════════════════╗
║         🤖 BOTIFY v4.0 STARTING              ║
║         Node.js ${process.version} · Discord.js v14      ║
╚═══════════════════════════════════════════════╝
`);
function spawnProcess(name, file, onExit) {
  const proc = spawn('node', [file], { stdio: 'inherit', env: process.env });
  proc.on('error', err => console.error(`❌ ${name} error:`, err.message));
  proc.on('exit', code => {
    console.log(`\n${name} exited (code ${code})`);
    if (code !== 0 && code !== null) {
      console.log(`⚠️  Restarting ${name} in 5s…`);
      setTimeout(() => onExit && onExit(), 5000);
    }
  });
  return proc;
}
const botFile = path.join(__dirname, 'bot', 'index.js');
const webFile = path.join(__dirname, 'web', 'server.js');
let bot = spawnProcess('Bot', botFile, () => {
  bot = spawnProcess('Bot', botFile, arguments.callee);
});
// Give bot 2s head-start, then start web
setTimeout(() => {
  let web = spawnProcess('Web', webFile, () => {
    web = spawnProcess('Web', webFile, arguments.callee);
  });
  const shutdown = () => {
    console.log('\n⏹️  Shutting down…');
    bot?.kill(); web?.kill();
    setTimeout(() => process.exit(0), 800);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}, 2000);
