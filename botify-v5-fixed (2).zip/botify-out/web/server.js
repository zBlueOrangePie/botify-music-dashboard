require('dotenv').config();

const express      = require('express');
const session      = require('express-session');
const MongoStore   = require('connect-mongo');
const passport     = require('passport');
const OAuth2       = require('passport-oauth2');
const helmet       = require('helmet');
const cors         = require('cors');
const compression  = require('compression');
const rateLimit    = require('express-rate-limit');
const path         = require('path');
const bodyParser   = require('body-parser');
const cookieParser = require('cookie-parser');
const https        = require('https');   // built-in — no axios needed

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Pure Node.js HTTPS helper (replaces axios) ───────────────────────────────
function httpGet(url, headers) {
  return new Promise((resolve, reject) => {
    const opts = Object.assign(new URL(url), { headers });
    https.get(opts, (res) => {
      let raw = '';
      res.on('data', chunk => { raw += chunk; });
      res.on('end', () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(raw) }); }
        catch (e) { reject(new Error('JSON parse failed: ' + raw.slice(0, 200))); }
      });
    }).on('error', reject);
  });
}

// ─── OAuth2 — Discord strategy ────────────────────────────────────────────────
// passport-oauth2 calls verify with (accessToken, refreshToken, profile, done)
// Discord does NOT use a profileURL so profile will be {}; we fetch manually.
passport.use('discord', new OAuth2({
  authorizationURL: 'https://discord.com/api/oauth2/authorize',
  tokenURL:         'https://discord.com/api/oauth2/token',
  clientID:         process.env.CLIENT_ID     || '',
  clientSecret:     process.env.CLIENT_SECRET || '',
  callbackURL:      process.env.CALLBACK_URL  || `http://localhost:${PORT}/auth/callback`,
  scope:            ['identify', 'guilds', 'email'],
  scopeSeparator:   ' ',
}, async (accessToken, _refreshToken, _profile, done) => {
  try {
    const headers = { Authorization: `Bearer ${accessToken}` };
    const [userRes, guildsRes] = await Promise.all([
      httpGet('https://discord.com/api/v10/users/@me',        headers),
      httpGet('https://discord.com/api/v10/users/@me/guilds', headers),
    ]);

    if (userRes.status !== 200)
      return done(new Error(`Discord user fetch failed: ${userRes.status}`));

    const u = userRes.data;
    return done(null, {
      id:            u.id,
      username:      u.username,
      discriminator: u.discriminator,
      avatar:        u.avatar,
      email:         u.email,
      guilds:        guildsRes.status === 200 ? guildsRes.data : [],
      accessToken,
    });
  } catch (err) {
    console.error('[OAuth2] Discord fetch failed:', err.message);
    return done(err);
  }
}));

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj,  done) => done(null, obj));

// ─── Session ──────────────────────────────────────────────────────────────────
const sessionOpts = {
  secret:            process.env.SESSION_SECRET || 'botify-dev-secret-change-in-prod',
  resave:            false,
  saveUninitialized: false,
  rolling:           true,
  cookie: {
    maxAge:   14 * 24 * 60 * 60 * 1000,
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
  },
};

if (process.env.MONGODB_URI) {
  sessionOpts.store = MongoStore.create({
    mongoUrl:       process.env.MONGODB_URI,
    touchAfter:     24 * 3600,
    dbName:         'botify',
    collectionName: 'sessions',
  });
}

// ─── Railway / reverse-proxy compatibility ────────────────────────────────────
// Railway sits behind a proxy — trust it so req.ip, secure cookies, and
// OAuth2 redirects all work correctly with HTTPS.
app.set('trust proxy', 1);

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(cors({ origin: process.env.DOMAIN || `http://localhost:${PORT}`, credentials: true }));
app.use(compression());
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 500, standardHeaders: true, legacyHeaders: false }));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session(sessionOpts));
app.use(passport.initialize());
app.use(passport.session());

// ─── View engine ─────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─── Locals injected into every view ─────────────────────────────────────────
app.use((req, res, next) => {
  res.locals.user     = req.user || null;
  res.locals.botName  = process.env.BOT_NAME  || 'Botify';
  res.locals.clientId = process.env.CLIENT_ID || '';
  res.locals.domain   = process.env.DOMAIN    || `http://localhost:${PORT}`;
  next();
});

// ─── Auth guards ──────────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  req.session.returnTo = req.originalUrl;
  res.redirect('/login');
}
function requireDev(req, res, next) {
  if (req.session && req.session.devLoggedIn) return next();
  res.redirect('/dev/login');
}

// ─── Public pages ─────────────────────────────────────────────────────────────
app.get('/', (req, res) => res.render('index'));

app.get('/commands', (req, res) => res.render('commands'));   // static — no bot needed

app.get('/status',  (req, res) => res.render('status',  { bot: getBotStatus() }));
app.get('/docs',    (req, res) => res.render('docs'));
app.get('/tos',     (req, res) => res.render('tos'));
app.get('/privacy', (req, res) => res.render('privacy'));

// ─── Auth routes ──────────────────────────────────────────────────────────────
app.get('/login', (req, res) => {
  if (req.isAuthenticated()) return res.redirect('/dashboard');
  res.render('login');
});

// Step 1 — redirect user to Discord
app.get('/auth/discord', passport.authenticate('discord'));

// Step 2 — Discord redirects back here
app.get('/auth/callback',
  passport.authenticate('discord', {
    failureRedirect: '/login?error=1',
    keepSessionInfo: true,
  }),
  (req, res) => {
    const dest = req.session.returnTo || '/dashboard';
    delete req.session.returnTo;
    res.redirect(dest);
  }
);

app.get('/logout', (req, res) => {
  req.logout(err => {
    if (err) console.error('[logout]', err);
    req.session.destroy(() => res.redirect('/'));
  });
});

// ─── Dashboard ────────────────────────────────────────────────────────────────
app.get('/dashboard', requireAuth, (req, res) => {
  const bot = global.botClient;
  const botGuildIds = bot ? [...bot.guilds.cache.keys()] : [];
  res.render('dashboard/home', { botGuildIds });
});

app.get('/dashboard/:guildId', requireAuth, async (req, res) => {
  try {
    const GuildSettings = require('../bot/models/GuildSettings');
    const bot     = global.botClient;
    const guildId = req.params.guildId;

    const userGuild = (req.user.guilds || []).find(g => g.id === guildId);
    if (!userGuild) return res.redirect('/dashboard?error=access');

    let guildInfo = { id: guildId, name: userGuild.name, icon: userGuild.icon };
    let channels  = [];
    let roles     = [];

    if (bot) {
      const g = bot.guilds.cache.get(guildId);
      if (g) {
        guildInfo = { id: g.id, name: g.name, icon: g.icon };
        channels  = [...g.channels.cache.values()]
          .filter(c => [0, 2, 5].includes(c.type))
          .map(c => ({ id: c.id, name: c.name, type: c.type }))
          .sort((a, b) => a.name.localeCompare(b.name));
        roles = [...g.roles.cache.values()]
          .filter(r => r.id !== guildId)
          .map(r => ({ id: r.id, name: r.name, color: r.hexColor || '#99aab5' }))
          .sort((a, b) => b.rawPosition - a.rawPosition);
      }
    }

    const settings = await GuildSettings.findOne({ guildId }).lean() || {};
    res.render('dashboard/guild', { guild: guildInfo, channels, roles, settings });
  } catch (e) {
    console.error('[Dashboard Guild]', e);
    res.status(500).render('error', { message: e.message });
  }
});

// ─── Rankings ────────────────────────────────────────────────────────────────
app.get('/leaderboard', async (req, res) => {
  try {
    const bot = global.botClient;
    const servers = bot
      ? [...bot.guilds.cache.values()]
          .map(g => ({
            id:          g.id,
            name:        g.name,
            icon:        g.iconURL({ size: 64 }),
            memberCount: g.memberCount,
            addedAt:     g.joinedAt,
          }))
          .sort((a, b) => b.memberCount - a.memberCount)
          .slice(0, 50)
      : [];
    res.render('leaderboard/servers', { servers, tab: 'servers' });
  } catch (e) {
    console.error('[Rankings/servers]', e);
    res.render('leaderboard/servers', { servers: [], tab: 'servers' });
  }
});

app.get('/leaderboard/servers', (req, res) => res.redirect('/leaderboard'));

app.get('/leaderboard/economy', async (req, res) => {
  try {
    const Leveling = require('../bot/models/Leveling');
    const bot = global.botClient;
    const top = await Leveling.find({}).sort({ totalXp: -1 }).limit(50).lean().catch(() => []);
    const entries = top.map(d => {
      const guild  = bot?.guilds.cache.get(d.guildId);
      const member = guild?.members.cache.get(d.userId);
      return {
        userId:    d.userId,
        guildName: guild?.name || 'Unknown Server',
        username:  member?.user?.username || `User#${d.userId.slice(-4)}`,
        avatar:    member?.user?.displayAvatarURL({ size: 64 }) || null,
        level:     d.level     || 0,
        totalXp:   d.totalXp   || 0,
        messages:  d.messages  || 0,
        coins:     Math.floor((d.messages || 0) * 2.5 + (d.totalXp || 0) * 0.1),
      };
    });
    res.render('leaderboard/economy', { entries, tab: 'economy' });
  } catch (e) {
    console.error('[Rankings/economy]', e);
    res.render('leaderboard/economy', { entries: [], tab: 'economy' });
  }
});

app.get('/leaderboard/tictactoe', async (req, res) => {
  try {
    const TicTacToe = require('../bot/models/TicTacToe');
    const topWins    = await TicTacToe.find({ wins: { $gt: 0 } }).sort({ wins: -1 }).limit(50).lean().catch(() => []);
    const topFastest = await TicTacToe.find({ fastestWin: { $ne: null } }).sort({ fastestWin: 1 }).limit(20).lean().catch(() => []);
    res.render('leaderboard/tictactoe', { topWins, topFastest, tab: 'tictactoe' });
  } catch (e) {
    console.error('[Rankings/tictactoe]', e);
    res.render('leaderboard/tictactoe', { topWins: [], topFastest: [], tab: 'tictactoe' });
  }
});

// ─── Profile ──────────────────────────────────────────────────────────────────
app.get('/profile', requireAuth, async (req, res) => {
  try {
    const Leveling = require('../bot/models/Leveling');
    const bot = global.botClient;
    const mutualGuilds = [];

    if (bot) {
      for (const g of bot.guilds.cache.values()) {
        const m = await g.members.fetch(req.user.id).catch(() => null);
        if (m) {
          mutualGuilds.push({
            id:    g.id,
            name:  g.name,
            icon:  g.icon,
            roles: [...m.roles.cache.values()]
              .filter(r => r.id !== g.id)
              .sort((a, b) => b.rawPosition - a.rawPosition)
              .map(r => ({ name: r.name, color: r.hexColor || '#99aab5' })),
          });
        }
      }
    }

    const levels = await Leveling.find({ userId: req.user.id }).lean().catch(() => []);
    res.render('profile', { mutualGuilds, levels });
  } catch (e) {
    console.error('[Profile]', e);
    res.status(500).render('error', { message: e.message });
  }
});

// ─── Dev panel ───────────────────────────────────────────────────────────────
app.get('/dev/login', (req, res) => {
  if (req.session && req.session.devLoggedIn) return res.redirect('/dev');
  res.render('dev/login', { error: req.query.error === '1' ? 'Wrong credentials.' : null });
});

app.post('/dev/login', (req, res) => {
  const { userid, password } = req.body;

  const users = [];
  if (process.env.DEV_USERS) {
    for (const entry of process.env.DEV_USERS.split(',')) {
      const idx = entry.trim().indexOf(':');
      if (idx > 0) users.push({ id: entry.trim().slice(0, idx), password: entry.trim().slice(idx + 1) });
    }
  }
  if (process.env.DEV_USER_ID && process.env.DEV_PASSWORD)
    users.push({ id: process.env.DEV_USER_ID, password: process.env.DEV_PASSWORD });

  if (!users.length)
    return res.render('dev/login', { error: 'No dev accounts configured. Set DEV_USERS in .env' });

  if (users.find(u => u.id === userid && u.password === password)) {
    req.session.devLoggedIn = true;
    req.session.devUserId   = userid;
    return res.redirect('/dev');
  }
  res.redirect('/dev/login?error=1');
});

app.post('/dev/logout', (req, res) => {
  req.session.devLoggedIn = false;
  req.session.devUserId   = null;
  res.redirect('/dev/login');
});

app.get('/dev', requireDev, (req, res) => {
  res.render('dev/dashboard', { stats: getDevStats(), devUserId: req.session.devUserId });
});

app.get('/dev/api/live', requireDev, (req, res) => {
  const c = global.botClient;
  const m = process.memoryUsage();
  res.json({
    ping:    c ? c.ws.ping : -1,
    guilds:  c ? c.guilds.cache.size : 0,
    uptime:  c ? c.uptime : 0,
    mem:     Math.round(m.heapUsed / 1024 / 1024),
    heapPct: Math.round((m.heapUsed / m.heapTotal) * 100),
    status:  c ? 'online' : 'offline',
  });
});

// ─── API router ───────────────────────────────────────────────────────────────
app.use('/api', require('./routes/api'));

// ─── 404 / Error handlers ─────────────────────────────────────────────────────
app.use((req, res) => res.status(404).render('404'));
app.use((err, req, res, _next) => {
  console.error('[Express Error]', err);
  res.status(500).render('error', { message: err.message || 'Internal server error' });
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function getBotStatus() {
  const c = global.botClient;
  if (!c || !c.isReady()) return { online: false };
  return {
    online:   true,
    ping:     c.ws.ping,
    guilds:   c.guilds.cache.size,
    uptime:   c.uptime,
    username: c.user?.username,
    tag:      c.user?.tag,
  };
}

function getDevStats() {
  const c   = global.botClient;
  const mem = process.memoryUsage();
  return {
    online:       c ? c.isReady() : false,
    ping:         c ? c.ws.ping : -1,
    guilds:       c ? c.guilds.cache.size : 0,
    users:        c ? [...c.guilds.cache.values()].reduce((a, g) => a + g.memberCount, 0) : 0,
    uptime:       c ? c.uptime : 0,
    commandCount: c ? c.commands.size : 0,
    nodeVersion:  process.version,
    platform:     process.platform,
    memMB:        Math.round(mem.heapUsed / 1024 / 1024),
    heapPct:      Math.round((mem.heapUsed / mem.heapTotal) * 100),
  };
}

// ─── Start ────────────────────────────────────────────────────────────────────
// Railway requires binding to 0.0.0.0 — localhost won't be reachable externally
app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Web Dashboard running at ${process.env.DOMAIN || `http://localhost:${PORT}`}`);
  console.log(`🚂 Listening on 0.0.0.0:${PORT}`);
});

module.exports = app;
