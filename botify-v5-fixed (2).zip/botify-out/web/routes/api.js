const express       = require('express');
const router        = express.Router();
const GuildSettings = require('../../bot/models/GuildSettings');
const Leveling      = require('../../bot/models/Leveling');
const Warning       = require('../../bot/models/Warning');

// ── Auth guards ───────────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.status(401).json({ error: 'Not authenticated' });
}
function requireGuildAdmin(req, res, next) {
  const guildId = req.params.guildId || req.params.id;
  const guild   = (req.user?.guilds || []).find(g => g.id === guildId);
  if (!guild) return res.status(403).json({ error: 'Not a member of this guild' });
  const perms = BigInt(guild.permissions || '0');
  if ((perms & BigInt(0x20)) !== BigInt(0x20) && (perms & BigInt(0x8)) !== BigInt(0x8))
    return res.status(403).json({ error: 'Missing MANAGE_GUILD permission' });
  req.guild = guild;
  next();
}

// ── PUBLIC: Bot status (no auth — used by status page) ───────────────────────
router.get('/public/status', (req, res) => {
  const c   = global.botClient;
  const mem = process.memoryUsage();

  if (!c || !c.isReady()) {
    return res.json({
      online:       false,
      ping:         null,
      guilds:       0,
      users:        0,
      commands:     0,
      uptime:       0,
      memMB:        Math.round(mem.heapUsed / 1024 / 1024),
      nodeVersion:  process.version,
      username:     process.env.BOT_NAME || 'Botify',
    });
  }

  const guilds   = c.guilds.cache;
  const users    = guilds.reduce((a, g) => a + (g.memberCount || 0), 0);
  const commands = (c.commands?.size || 0) + (c.prefixCommands?.size || 0);
  const startMs  = global.botStartTime || Date.now();

  res.json({
    online:      true,
    ping:        c.ws.ping,
    guilds:      guilds.size,
    users,
    commands,
    uptime:      Date.now() - startMs,   // ms since bot ready
    memMB:       Math.round(mem.heapUsed / 1024 / 1024),
    nodeVersion: process.version,
    username:    c.user.username,
    tag:         c.user.tag,
  });
});

// ── Everything below requires login ──────────────────────────────────────────
router.use(requireAuth);

// ── GET /api/guilds ───────────────────────────────────────────────────────────
router.get('/guilds', (req, res) => {
  const userGuilds = (req.user.guilds || []).filter(g => {
    const p = BigInt(g.permissions || '0');
    return (p & BigInt(0x20)) === BigInt(0x20) || (p & BigInt(0x8)) === BigInt(0x8);
  });
  const bot = global.botClient;
  if (!bot) return res.json(userGuilds.map(g => ({ ...g, botPresent: false })));
  res.json(userGuilds.map(g => ({
    ...g,
    botPresent:  bot.guilds.cache.has(g.id),
    memberCount: bot.guilds.cache.get(g.id)?.memberCount ?? null,
  })));
});

// ── GET /api/guild/:id/channels ───────────────────────────────────────────────
router.get('/guild/:id/channels', requireGuildAdmin, (req, res) => {
  const g = global.botClient?.guilds.cache.get(req.params.id);
  if (!g) return res.json([]);
  res.json([...g.channels.cache.values()]
    .filter(c => [0, 2, 5, 15].includes(c.type))
    .sort((a, b) => a.position - b.position)
    .map(c => ({ id: c.id, name: c.name, type: c.type, parentId: c.parentId })));
});

// ── GET /api/guild/:id/roles ──────────────────────────────────────────────────
router.get('/guild/:id/roles', requireGuildAdmin, (req, res) => {
  const g = global.botClient?.guilds.cache.get(req.params.id);
  if (!g) return res.json([]);
  res.json([...g.roles.cache.values()]
    .filter(r => r.id !== g.id)
    .sort((a, b) => b.position - a.position)
    .map(r => ({ id: r.id, name: r.name, color: r.hexColor, position: r.position })));
});

// ── GET /api/guild/:id/stats ──────────────────────────────────────────────────
router.get('/guild/:id/stats', requireGuildAdmin, (req, res) => {
  const g = global.botClient?.guilds.cache.get(req.params.id);
  if (!g) return res.json({ members: 0, channels: 0, roles: 0, online: 0, botPresent: false });
  const online = [...g.members.cache.values()]
    .filter(m => m.presence?.status && m.presence.status !== 'offline').length;
  res.json({ members: g.memberCount, channels: g.channels.cache.size, roles: g.roles.cache.size - 1, online, botPresent: true });
});

// ── GET /api/guild/:guildId/settings ─────────────────────────────────────────
router.get('/guild/:guildId/settings', requireGuildAdmin, async (req, res) => {
  try {
    const s = await GuildSettings.findOne({ guildId: req.params.guildId }).lean() || {};
    res.json(s);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── POST /api/guild/:guildId/settings ────────────────────────────────────────
router.post('/guild/:guildId/settings', requireGuildAdmin, async (req, res) => {
  try {
    const doc = await GuildSettings.findOneAndUpdate(
      { guildId: req.params.guildId },
      { $set: { ...req.body, guildId: req.params.guildId } },
      { upsert: true, new: true, runValidators: false }
    );
    res.json({ success: true, id: doc._id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GET /api/guild/:guildId/leaderboard ──────────────────────────────────────
router.get('/guild/:guildId/leaderboard', requireGuildAdmin, async (req, res) => {
  try {
    const data = await Leveling.find({ guildId: req.params.guildId })
      .sort({ level: -1, xp: -1 }).limit(50).lean();
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GET /api/guild/:guildId/warnings ─────────────────────────────────────────
router.get('/guild/:guildId/warnings', requireGuildAdmin, async (req, res) => {
  try {
    const data = await Warning.find({ guildId: req.params.guildId })
      .sort({ createdAt: -1 }).limit(100).lean();
    res.json(data);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GET /api/user/me ──────────────────────────────────────────────────────────
router.get('/user/me', (req, res) => {
  const { id, username, discriminator, avatar, email, guilds } = req.user;
  res.json({ id, username, discriminator, avatar, email, guildsCount: guilds?.length || 0 });
});

module.exports = router;
