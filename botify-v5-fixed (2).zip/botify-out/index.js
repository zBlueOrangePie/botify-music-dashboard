require('dotenv').config();
const { spawn } = require('child_process');
const path      = require('path');

console.log(`
╔═══════════════════════════════════════════════╗
║         🤖 BOTIFY v5 STARTING                ║
║         Node.js ${process.version.padEnd(8)} · Discord.js v14    ║
╚═══════════════════════════════════════════════╝
`);

function spawnProc(name, file) {
  const proc = spawn('node', [file], { stdio: 'inherit', env: process.env });

  proc.on('error', err => {
    console.error(`❌ [${name}] spawn error:`, err.message);
  });

  proc.on('exit', (code, signal) => {
    if (signal) {
      console.log(`\n[${name}] killed by signal ${signal}`);
      return; // intentional kill — don't restart
    }
    console.log(`\n[${name}] exited with code ${code}`);
    if (code !== 0) {
      console.log(`⚠️  Restarting ${name} in 5s…`);
      setTimeout(() => spawnProc(name, file), 5000);
    }
  });

  return proc;
}

const botFile = path.join(__dirname, 'bot', 'index.js');
const webFile = path.join(__dirname, 'web', 'server.js');

// Start bot first, then web after 2s so global.botClient may already be set
const botProc = spawnProc('Bot', botFile);
setTimeout(() => {
  const webProc = spawnProc('Web', webFile);

  function shutdown() {
    console.log('\n⏹️  Shutting down…');
    botProc.kill('SIGTERM');
    webProc.kill('SIGTERM');
    setTimeout(() => process.exit(0), 1500);
  }
  process.on('SIGINT',  shutdown);
  process.on('SIGTERM', shutdown);
}, 2000);
